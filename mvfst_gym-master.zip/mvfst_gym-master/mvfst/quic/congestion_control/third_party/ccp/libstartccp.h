#include <cstdint>

extern "C" {
uint32_t ccp_run_forever(const char* args, uint32_t log_fd);
}
