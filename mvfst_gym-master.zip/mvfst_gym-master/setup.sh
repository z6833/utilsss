#!/bin/bash -eu

PREFIX=${CONDA_PREFIX:-"/usr/local"}
BASE_DIR="$PWD"
BUILD_DIR="$BASE_DIR"/_build
MVFST_DIR="$BASE_DIR"/mvfst

if [ -d "$BUILD_DIR/build" ];then
  echo -e "mvfst_gym already installed, skipping"
  #exit 0
fi
#预留
#GYM_DIR="$DEPS_DIR"/gym
#STABLE_BASELINES_DIR="$DEPS_DIR"/stable_baselines
#TENSORFLOW_DIR="$DEPS_DIR"/tensorflow

pip install gym stable-baselines[mpi] tensorflow==1.14

cd "$BASE_DIR"

function setup_mvfst(){
echo -e "Installing mvfst"
##mvfst-status:20807e41de0c523437eeba903f9911b9e3ca6cdf 2020/06/01
cd "$MVFST_DIR" && ./build_helper.sh 
cd _build/build/ && make install
echo -e "Done installing mvfst"
}

setup_mvfst

echo -e "Building mvfst_gym"
cd "$BASE_DIR" && ./build.sh
