# mvfst_gym

## Building mvfst_gym

### Ubuntu 16+

For building with training support, it's recommended to have a conda environment first:
```
conda create -n mvfst_gym python=3.7 -y && conda activate mvfst_gym
./setup.sh
```
## Training

You can run gym by commands:
```
python3 -m train.gym_beast
```
And then, start `trafic_gen` in other terminal by:
```
python3 -m train.traffic_env --mode=train
```

Or training in one terminal by follows which is recommended.
```
python3 -m train.gym_train \
  --mode=train \
  --base_logdir=/tmp/logs \
```
All args can be found in file `train/constants.py`, and you can modify it as you like.

## Evaluation

For running test via RPC for policy lookup, use `--mode=test` as follows:
```
python3 -m train.train \
  --mode=test \
```
And you can assign the `model_path` and others in function `test` in `traffic_env.py`.
