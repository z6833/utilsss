# Copyright (c) Facebook, Inc. and its affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#
import os
from os import path

# 获取mvfst_gym所在路径
SRC_DIR = path.abspath(path.join(path.dirname(__file__), os.pardir))

# 指定traffic_gen Server端IP和端口
TFG_SERVER = '192.168.33.5'
TFG_PORT = 9876

# 指定traffic_gen Client端IP及ssh用户密码
TFG_CLIENT = '192.168.33.84'
USR_SSH_TO_TFG_CLIENT = 'h3c'
PWD_SSH_TO_TFG_CLIENT = '123456'

# 指定两端网口名称
SERVER_NET = 'enp7s0f1'
CLIENT_NET = 'enp7s0f3'

ARGS = {
    'traffic_args': {

        'server': {
            'tfg_path': SRC_DIR + '/_build/build/traffic_gen/traffic_gen',
            'tfg_test_path': SRC_DIR + '/_build/build/traffic_gen_test/traffic_gen_test',
            '--mode': 'server',
            '--host': TFG_SERVER,
            '--port': TFG_PORT,
            '--cc_algo': 'rl',
            '--cc_env_mode': 'remote',
            '--cc_env_agg': 'time',
            '--cc_env_time_window_ms': 100,
            '--cc_env_fixed_window_size': 10,
            '--cc_env_use_state_summary': True,
            # '--cc_env_history_size': 2,
            '--cc_env_history_size': 5,
            '--cc_env_norm_ms': 100,
            '--cc_env_norm_bytes': 1000,
            '--cc_env_actions': '0,/2,/1.5,/1.25,/1.05,*1.05,*1.25,*2',
            # '--cc_env_actions': '0,/2,/1.25,/1.05,*1.05,*1.25,*2',
            '--cc_env_reward_throughput_factor': 0.008,
            '--cc_env_reward_delay_factor': 0.01,
            '--cc_env_reward_packet_loss_factor': 0.0,
            '--cc_env_reward_max_delay': True,
            '-v': '1',
        },
        'client': {
            'tfg_path': SRC_DIR + '/_build/build/traffic_gen/traffic_gen',
            'tfg_test_path': SRC_DIR + '/_build/build/traffic_gen_test/traffic_gen_test',
            '-mode': 'client',
            '-host': TFG_SERVER,
            '--port': TFG_PORT,
            '--cc_algo': 'cubic',
            'ssh_to_client': {  # ssh启动traffic_gen的client端
                'ipclient': TFG_CLIENT,
                'username': USR_SSH_TO_TFG_CLIENT,
                'password': PWD_SSH_TO_TFG_CLIENT,
            },
        },
        'others': {
            'duration': 30,  # 每个episode时间
        },
    },

    'gym_args': {
        # 各算法共同参数
        'common': {
            'num_actions': 8,
            # 'num_actions': 7,
            'observation_length': 149,
            # 'observation_length': 144,
            'learning_rate': 0.0001,
            'total_steps': 3000000,
            'n_steps': 1000,  # saving model every N steps
            'savedir': SRC_DIR + '/logs',
        },

        'algo_supported': {  # 当前stable_baselines支持的算法
            # 各算法特有参数
            'PPO1': {
                'batch_size': 1,
                'alpha': 0.99,
            },
            'PPO2': {
                'policy': '',
                'gamma': 0.99,              # (float) Discount factor
                'n_steps': 128,             # (int) The number of steps to run for each environment per update
                'ent_coef': 0.01,           # (float) Entropy coefficient for the loss calculation
                'learning_rate': 2.5e-4,    # The learning rate, it can be a function
                'vf_coef': 0.5,             # Value function coefficient for the loss calculation
                'max_grad_norm': 0.5,       # The maximum value for the gradient clipping
                'lam': 0.95,                # Factor for trade-off of bias vs variance for Generalized Advantage Estimator
                'nminibatches': 1,          # Number of training minibatches per update. For recurrent policies,
                'cliprange': 2,             # (float or callable) Clipping parameter
                'cliprange_vf': None,       # Clipping parameter for the value function,
                'verbose': 1,
                'tensorboard_log': SRC_DIR + '/logs/tensorboard_log',
                'full_tensorboard_log': False,
            },
            'DQN': {
                'gamma': 0.9,
                'learning_rate': 5e-4,
                'buffer_size': 50000 * 30,
                'exploration_fraction': 0.1,
                'exploration_final_eps': 0.02,
                'exploration_initial_eps': 1.0,
                'train_freq': 1,
                'batch_size': 64,
                'double_q': True,
                'learning_starts': 1000,
                'target_network_update_freq': 500,
                'prioritized_replay': True,
                'prioritized_replay_alpha': 0.6,
                'prioritized_replay_beta0': 0.4,
                'prioritized_replay_beta_iters': None,
                'prioritized_replay_eps': 1e-6,
                'param_noise': False,
                'verbose': 0,
                'tensorboard_log': SRC_DIR + '/logs/tensorboard_log',
                'full_tensorboard_log': False,
                'seed': 9527,
            },
            'A2C': {

            },
            'ACER': {

            },
            'ACKTR': {

            },
            'DDPG': {

            },
            'TRPO': {

            },
            'HER': {

            },
            'GAIL': {

            },
            'SAC': {

            },
            'TD3': {

            },
        },
    }
}

# if __name__ == "__main__":
# arg = ARGS['traffic_args'].get('cc_env_agg', None)

# args_server = ARGS['traffic_args'].get('server', None)
