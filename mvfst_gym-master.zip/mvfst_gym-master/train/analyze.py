# coding = utf-8
import pandas as pd
import matplotlib.pyplot as plt
import re

class Analysis():

    def __init__(self):
        self.file_frame = None
        self.avg_tput = []
        self.log_path = None

    def _log_plot(self):
        if self.avg_tput is not None:
            avg_tput = sum(self.avg_tput) / len(self.avg_tput) / 8

        if self.file_frame is not None:
            x_index = self.file_frame.index.to_list()
            fig, axes = plt.subplots(2, 1, figsize=(16, 16), dpi=80)

            axes[0].plot(x_index, self.file_frame['sent_rate'], )
            axes[0].plot(x_index, [avg_tput for _ in x_index], )
            axes[0].plot(x_index, [120 for _ in x_index], )
            axes[0].set_ylabel('sent_rate')
            axes[0].grid(True)
            axes[0].legend(bbox_to_anchor=(0, 1.0, 1, 0.), loc=0, ncol=3, mode="expand", labels=['sent_rate', 'real_tput', 'baselines'])

            axes[1].plot(x_index, self.file_frame['total_lost'] / 8, )
            # axes[1].plot(x_index, [avg_tput for _ in x_index], )
            # axes[1].plot(x_index, [120 for _ in x_index], )
            axes[1].set_ylabel('total_lost')
            axes[1].grid(True)
            # plt.legend(bbox_to_anchor=(0, 1.0, 1, 0.), loc=0, ncol=3, mode="expand", labels=['sent_rate', 'real_tput', 'baselines'])

            plt.savefig(self.log_path.replace('log', 'png'))
            # plt.show()

    def analysis(self, log_path):
        file_dict = {
            'avg_throughput': [],
            'sent_rate': [],
            'total_lost': [],
            # 'cwndAction': [],
            # 'throughput': [],
        }
        self.log_path = log_path
        f = open(self.log_path, 'r', encoding='utf-8')
        line_list = f.readlines()
        for line in line_list:
            if 'avg_throughput ' in line:
                try:
                    avg_throughput = re.findall('avg_throughput = (.*?) MBps', line)
                    sent_rate = re.findall('sent_rate = (.*?) MBps', line)
                    total_lost = re.findall('total_lost = (.*?) Mb', line)
                    file_dict['avg_throughput'].append(float(avg_throughput[0]))
                    file_dict['sent_rate'].append(float(sent_rate[0]))
                    file_dict['total_lost'].append(float(total_lost[0]))
                except Exception:
                    print("21598:", line)
            # elif 'cwndAction' in line:
            #     cwndAction = re.findall('cwndAction=(.*?),', line)
            #     file_dict['cwndAction'].append(int(cwndAction[0]))
            elif 'Overall throughput' in line:
                throughput = re.findall('throughput: (.*?)Mb/s', line)
                self.avg_tput.append(float(throughput[0]))

            else:
                continue
        self.file_frame = pd.DataFrame(file_dict)
        self._log_plot()


def main():
    from train.constants import SRC_DIR
    Analysis().analysis(SRC_DIR + '/test.log')


if __name__ == "__main__":
    main()