# coding='utf-8'
import tensorflow as tf
from stable_baselines.common.policies import FeedForwardPolicy, LstmPolicy, MlpLstmPolicy, MlpLnLstmPolicy
from stable_baselines.deepq.policies import MlpPolicy, LnMlpPolicy


class ComLstmPolicy(LstmPolicy):
    def __init__(self, sess, ob_space, ac_space, n_env, n_steps, n_batch, n_lstm=64, reuse=False, **_kwargs):
        super().__init__(sess,
                         ob_space,
                         ac_space,
                         n_env,
                         n_steps,
                         n_batch,
                         n_lstm,
                         reuse,
                         feature_extraction='mlp',
                         act_fun=tf.nn.relu,
                         net_arch=[8, 'lstm', dict(vf=[32, 32], pi=[32, 32])],
                         layer_norm=False,
                         **_kwargs)


class ComMlpPolicy(FeedForwardPolicy):
    def __init__(self, sess, ob_space, ac_space, n_env, n_steps, n_batch, reuse=False, **kwargs):
        super(ComMlpPolicy, self).__init__(
            sess,
            ob_space,
            ac_space,
            n_env,
            n_steps,
            n_batch,
            reuse=reuse,
            feature_extraction="mlp",
            act_fun=tf.nn.relu,
            net_arch=[32, 32],
            **kwargs)


class DQMlpPolicy(MlpPolicy):

    def __init__(self, sess, ob_space, ac_space, n_env, n_steps, n_batch, reuse=False, obs_phs=None, dueling=True, **_kwargs):
        super(MlpPolicy, self).__init__(
            sess,
            ob_space,
            ac_space,
            n_env,
            n_steps,
            n_batch,
            reuse,
            feature_extraction="mlp",
            act_fun=tf.nn.tanh,
            layers=[32, 64, 32],
            obs_phs=obs_phs,
            dueling=dueling,
            layer_norm=True,
            **_kwargs)


class DQLnMlpPolicy(LnMlpPolicy):

    def __init__(self, sess, ob_space, ac_space, n_env, n_steps, n_batch, reuse=False, obs_phs=None, dueling=True, **_kwargs):
        super(LnMlpPolicy, self).__init__(
            sess,
            ob_space,
            ac_space,
            n_env,
            n_steps,
            n_batch,
            reuse,
            feature_extraction="mlp",
            act_fun=tf.nn.relu,
            layers=[32, 32],
            obs_phs=obs_phs,
            dueling=dueling,
            layer_norm=True,
            **_kwargs,
        )