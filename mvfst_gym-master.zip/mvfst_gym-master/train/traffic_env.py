#!/usr/bin/env python3
import signal
import os
import random
import argparse
import logging

import time
import subprocess
from subprocess import Popen
from train import common
from train.constants import ARGS, SRC_DIR
from train.constants import SERVER_NET, CLIENT_NET
from train.analyze import Analysis

logging.basicConfig(level=logging.INFO)


def get_server_cmd(flags):
    args_server = ARGS['traffic_args'].get('server')
    if flags.mode == 'train':
        tfg_path = args_server.get('tfg_path', None)
    else:
        tfg_path = args_server.get('tfg_test_path', None)

    cmd = [
        tfg_path,
        '-host={}'.format(args_server.get('--host')),
        '-port={}'.format(args_server.get('--port')),
        '--cc_env_mode={}'.format(args_server.get('--cc_env_mode')),
        '--cc_env_agg={}'.format(args_server.get('--cc_env_agg', 'time')),
        '--cc_algo={}'.format(args_server.get('--cc_algo')),
        '--cc_env_history_size={}'.format(args_server.get('--cc_env_history_size', 20)),
        '--cc_env_norm_ms={}'.format(args_server.get('--cc_env_norm_ms', 100)),
        '--cc_env_norm_bytes={}'.format(args_server.get('--cc_env_norm_bytes', 1000)),
        '--cc_env_actions={}'.format(args_server.get('--cc_env_actions', '0')),
        '--cc_env_reward_max_delay={}'.format(args_server.get('--cc_env_reward_max_delay')),
        '-v={}'.format(args_server.get('-v', 1)),
    ]
    return cmd


def get_ssh_info():
    args_client = ARGS['traffic_args'].get('client')

    # ssh连接到client
    ssh_clt = args_client['ssh_to_client'].get('ipclient')
    ssh_usr = args_client['ssh_to_client'].get('username')
    ssh_pwd = args_client['ssh_to_client'].get('password')

    ssh_cmd = "sshpass -p {pwd} ssh {usr}@{clt}".format(pwd=ssh_pwd, usr=ssh_usr, clt=ssh_clt)

    return args_client, ssh_cmd


def get_client_cmd(flags):

    args_client, ssh_cmd = get_ssh_info()
    if flags.mode == 'train':
        tfg_path = args_client.get('tfg_path', None)
    else:
        tfg_path = args_client.get('tfg_test_path', None)

    tfg_cmd = [
            tfg_path,  # traffic_gen路径
            '-mode={}'.format(args_client.get('-mode')),
            '-host={}'.format(args_client.get('-host')),
            '--port={}'.format(args_client.get('--port')),
            '-cc_algo={}'.format(args_client.get('--cc_algo', 'cubic')),
        ]

    # ssh连接到client,并启动traffic_gen的client
    cmd = 'echo ' + " ".join(tfg_cmd) + ' | ' + ssh_cmd + ';'
    return cmd


def clear_client_pg():
    _, ssh_cmd = get_ssh_info()

    # 杀掉client的traffic_gen
    clr_cmd = ['pkill', '-9', 'traffic_gen*']
    final_cmd = 'echo ' + " ".join(clr_cmd) + ' | ' + ssh_cmd + ';'
    # p = Popen(final_cmd, shell=True)
    # p.wait()
    return final_cmd


def set_traffic_control():
    delay_choices = [5, 10, 15]
    # delay_choices = [20, 25, 30]
    delay = random.choice(delay_choices)
    # setting for server ...
    server_cmd = "sudo tc qdisc replace dev {ser_net} root netem delay {delay}ms".format(ser_net=SERVER_NET, delay=delay)
    result_ser = subprocess.run(
        [server_cmd], shell=True, stderr=subprocess.PIPE
    )

    # setting for client
    client_cmd = "sudo tc qdisc replace dev {cli_net} root netem delay {delay}ms".format(cli_net=CLIENT_NET, delay=delay)
    _, ssh_cmd = get_ssh_info()
    client_cmd = 'echo ' + client_cmd + ' | ' + ssh_cmd + ';'
    result_cli = subprocess.run(
        [client_cmd], shell=True, stderr=subprocess.PIPE
    )

    msg_s = result_ser.stderr.decode('utf-8')
    # logging.info("21598: msg_s = {}".format(msg_s))
    if "Error" in msg_s:
        logging.info("setting tc for server failed. msg:{}".format(msg_s))
        return 0

    msg_c = result_cli.stderr.decode('utf-8')
    # logging.info("msg_c = {}".format(msg_c))
    if "Error" in msg_c:
        logging.info("setting tc for client failed. msg:{}".format(msg_c))
        return 0

    logging.info("Changed delay to {}ms for both.".format(delay))
    return 1


def train_run(flags, ):

    episode = 0
    server_cmd = get_server_cmd(flags)
    client_cmd = get_client_cmd(flags)
    clear_cmd = clear_client_pg()
    if flags.mode == "train":
        duration = ARGS['traffic_args']['others'].get('duration', 10)
    else:
        duration = 20  # 要求略大于测试时间
    try:
        while True:

            if flags.mode == 'train' #and episode % 50 == 0:
                result = set_traffic_c ontrol()
                if result == 0:
                    break

            start_server = Popen(server_cmd, stdout=subprocess.PIPE, preexec_fn=os.setsid)
            time.sleep(3)
            start_client = Popen(client_cmd, stdin=start_server.stdout, stdout=subprocess.PIPE, preexec_fn=os.setsid, shell=True)

            time.sleep(duration)

            os.killpg(os.getpgid(start_server.pid), signal.SIGKILL)
            clear_client = Popen(clear_cmd, shell=True, stdin=start_client.stdout, preexec_fn=os.setsid)
            os.killpg(os.getpgid(start_client.pid), signal.SIGKILL)
            os.killpg(os.getpgid(clear_client.pid), signal.SIGKILL)

            episode += 1
            if flags.mode == "test" and episode >= 3:
                Analysis().analysis(log_path=SRC_DIR + '/test.log')
                break
    except KeyboardInterrupt:
        pass


def main(flags):

    train_run(flags)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="traffic Env Instances")
    common.add_args(parser)
    flags = parser.parse_args()
    main(flags)
