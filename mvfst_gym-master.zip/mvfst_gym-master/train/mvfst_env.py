import math
import gym
from gym import spaces, logger
from gym.utils import seeding
from gym.envs.registration import register
import numpy as np
import socket
import struct

from train.constants import ARGS

BUFFER_SIZE = 10240
class MvfstNetworkEnv(gym.Env):

  def __init__(self):
    args = ARGS['gym_args']

    # 算法初始参数
    self.num_actions = args['common'].get('num_actions', 8)
    # self.history_size = args['common'].get('history_size', 0)
    self.observation_length = args['common'].get('observation_length', 245)
    self.total_steps = args['common'].get('total_steps', 1000000)

    # 算法更新参数
    self.steps_taken = 0

    # socket监听
    self.addr = '0.0.0.0'
    self.port = 30000
    self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    self.sock.setblocking(1)
    self.sock.bind((self.addr, self.port))

    self.conn = None
    self.conn_addr = None

    # 环境类参数
    self.seed()
    self.viewer = None
    # 动作空间，每个动作的取值映射到0-8几个离散数
    self.action_space = spaces.Discrete(self.num_actions)
    # 状态空间，每个状态取值为float类型，设置为连续范围
    self.observation_space = spaces.Box(np.tile(np.array([0.0]), self.observation_length-4),
                                        np.tile(np.array([1e12]), self.observation_length-4), dtype=np.float32)

  def get_datas(self, action):

    if self.conn is None:
        self.sock.listen()
        self.conn, self.conn_addr = self.sock.accept()

    try:
        self.conn.sendall(str(action).encode())
        msg = self.conn.recv(BUFFER_SIZE)
        data_tuple = struct.unpack('f'*self.observation_length, msg)
    except ConnectionResetError:  # 捕获重启traffic_gen信号
        self.conn.close()
        self.conn = None
        return 0
    except BrokenPipeError as info:
        print("info:{}".format(info))
        self.conn.close()
        self.conn = None
        return 0
    except Exception as e:
        print("msg={}, e={}".format(msg, e))
        self.conn.close()
        self.conn = None
        return 0

    return data_tuple

  def seed(self, seed=None):
    self.np_random, seed = seeding.np_random(seed)
    return [seed]

  def step(self, action):

    while 1:
        data = self.get_datas(action)
        if (not data == 0) and (len(data) == self.observation_length):
            reward_ = data[-4]
            done = data[-3]
            # episode_step = data[-2]
            # episode_return = data[-1]

            state = data[:-4]
            self.steps_taken += 1
            break

    if (done == 1.0) or (self.steps_taken >= self.total_steps):
        # import logging
        # logging.info("21598: mvfst_env done = {}".format(done))
        done = True

    return np.array(state), reward_, done, {}

  def reset(self):

    init_action = 0
    while 1:
      init_data = self.get_datas(action=init_action)
      if (not init_data == 0) and (len(init_data) == self.observation_length):
        self.state = init_data[:-4]
        break

    return np.array(self.state)

  def render(self, mode='human'):

    return

  def close(self):
    if self.viewer:
      self.viewer.close()
      self.viewer = None


env_name = 'MvfstRl-v0'
if env_name in gym.envs.registry.env_specs:
  del gym.envs.registry.env_specs[env_name]

register(id=env_name, entry_point='train.mvfst_env:MvfstNetworkEnv')
