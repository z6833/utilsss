# coding=utf-8
import os
from os import path
from stable_baselines import DQN

from train.constants import ARGS
from train.utils import DQMlpPolicy

par_path = path.abspath(path.join(path.dirname(__file__), os.pardir))
model_path = path.join(par_path, 'tuning', 'DQN')


class DQNModel():

    def __init__(self):
        self.model_path = model_path + '/DQN_model_best'
        self.args = ARGS['gym_args']['algo_supported'].get('DQN')

    def origin_model(self, env):

        model = DQN(
            DQMlpPolicy,
            env=env,
            gamma=self.args.get('gamma'),
            learning_rate=self.args.get('learning_rate'),
            buffer_size=self.args.get('buffer_size'),
            exploration_fraction=self.args.get('exploration_fraction'),
            exploration_final_eps=self.args.get('exploration_final_eps'),
            exploration_initial_eps=self.args.get('exploration_initial_eps'),
            train_freq=self.args.get('train_freq'),
            batch_size=self.args.get('batch_size'),
            double_q=self.args.get('double_q', True),
            learning_starts=self.args.get('learning_starts'),
            target_network_update_freq=self.args.get('target_network_update_freq'),
            prioritized_replay=self.args.get('prioritized_replay'),
            prioritized_replay_alpha=self.args.get('prioritized_replay_alpha'),
            prioritized_replay_beta0=self.args.get('prioritized_replay_beta0'),
            prioritized_replay_beta_iters=self.args.get('prioritized_replay_beta_iters'),
            prioritized_replay_eps=self.args.get('prioritized_replay_eps'),
            param_noise=self.args.get('param_noise'),
            verbose=self.args.get('verbose'),
            tensorboard_log=self.args.get('tensorboard_log'),
            full_tensorboard_log=self.args.get('full_tensorboard_log'),
            seed=self.args.get('seed'),
        )

        return model

    def tuning_model(self, env):

        try:
            model = DQN.load(load_path=self.model_path,
                             env=env,
                             gamma=self.args.get('gamma'),
                             # learning_rate=self.args.get('learning_rate'),
                             learning_rate=2.5e-4,
                             buffer_size=self.args.get('buffer_size'),
                             exploration_fraction=self.args.get('exploration_fraction'),
                             exploration_final_eps=self.args.get('exploration_final_eps'),
                             exploration_initial_eps=self.args.get('exploration_initial_eps'),
                             train_freq=self.args.get('train_freq'),
                             batch_size=self.args.get('batch_size'),
                             double_q=self.args.get('double_q', True),
                             learning_starts=self.args.get('learning_starts'),
                             target_network_update_freq=self.args.get('target_network_update_freq'),
                             prioritized_replay=self.args.get('prioritized_replay'),
                             prioritized_replay_alpha=self.args.get('prioritized_replay_alpha'),
                             prioritized_replay_beta0=self.args.get('prioritized_replay_beta0'),
                             prioritized_replay_beta_iters=self.args.get('prioritized_replay_beta_iters'),
                             prioritized_replay_eps=self.args.get('prioritized_replay_eps'),
                             param_noise=self.args.get('param_noise'),
                             verbose=self.args.get('verbose'),
                             tensorboard_log=self.args.get('tensorboard_log'),
                             full_tensorboard_log=self.args.get('full_tensorboard_log'),
                             seed=self.args.get('seed'),
                             )
        except Exception as e:
            print(e)

        return model

    @classmethod
    def get_dqn(cls, tuning=False, env=None):

        fun = cls().tuning_model if tuning else cls().origin_model
        return fun(env)


if __name__ == "__main__":
    DQNModel()
