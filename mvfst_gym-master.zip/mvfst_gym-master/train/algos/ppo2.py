# coding=utf-8
import os
from os import path
from stable_baselines import PPO2

from train.constants import ARGS
from train.utils import ComLstmPolicy, ComMlpPolicy

par_path = path.abspath(path.join(path.dirname(__file__), os.pardir))
model_path = path.join(par_path, 'tuning', 'PPO2')


class PPO2Model():

    def __init__(self):
        self.model_path = model_path + '/PPO2_model_best'
        self.args = ARGS['gym_args']['algo_supported'].get('PPO2')

    def origin_model(self, use_lstm, env):

        policy = ComLstmPolicy if use_lstm else ComMlpPolicy
        model = PPO2(
            policy,
            env,
            gamma=self.args.get('gamma'),
            n_steps=self.args.get('n_steps'),
            ent_coef=self.args.get('ent_coef'),
            learning_rate=self.args.get('learning_rate'),
            # learning_rate=LinearSchedule(schedule_timesteps=total_timesteps, initial_p=1e-4, final_p=2.5e-4).value,
            vf_coef=self.args.get('vf_coef'),
            max_grad_norm=self.args.get('max_grad_norm'),
            lam=self.args.get('lam'),
            nminibatches=self.args.get('nminibatches'),
            cliprange=self.args.get('cliprange'),
            cliprange_vf=self.args.get('cliprange_vf'),
            verbose=self.args.get('verbose'),
            tensorboard_log=self.args.get('tensorboard_log'),
            full_tensorboard_log=self.args.get('full_tensorboard_log'),
        )

        return model

    def tuning_model(self, use_lstm=False, env=None):
        
        try:
            model = PPO2.load(load_path=self.model_path, env=env)
        except Exception as e:
            print(e)

        return model

    @classmethod
    def get_ppo(cls, tuning=False, use_lstm=False, env=None):

        fun = cls().tuning_model if tuning else cls().origin_model
        return fun(use_lstm, env)

