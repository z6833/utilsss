# Copyright (c) Facebook, Inc. and its affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#


def add_args(parser):
    parser.add_argument(
        "--mode",
        default="train",
        choices=["train", "test"],
        help="test -> remote test, test_local -> local inference.",
    )

    parser.add_argument(
        "--use_lstm",
        type=bool,
        default=False,
        help="use lstm policy or not. [only PPO supports lstm present].",
    )

    parser.add_argument(
        "--algo",
        default=None,
        choices=["PPO2", "DQN"],
        help="which alog to train the agent",
    )

    parser.add_argument(
        "--tuning",
        type=bool,
        default=False,
        help="training based on a given model",
    )


