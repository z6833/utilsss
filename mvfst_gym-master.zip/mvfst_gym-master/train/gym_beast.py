# Copyright (c) Facebook, Inc. and its affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#

#
# Run with OMP_NUM_THREADS=1.
#
import os
import argparse
import logging

import numpy as np
from stable_baselines.common.vec_env import VecNormalize, VecCheckNan
from stable_baselines.common import make_vec_env
from stable_baselines.common.schedules import LinearSchedule

import train.mvfst_env
from train import common
from train.constants import ARGS, SRC_DIR
from train.utils import ComLstmPolicy, ComMlpPolicy
from train.utils import DQMlpPolicy
from train.custom import MyCallback


logging.basicConfig(
    format=(
        "[%(levelname)s:%(process)d %(module)s:%(lineno)d %(asctime)s] " "%(message)s"
    ),
    level=0,
)


def train(flags, ):
    args = ARGS['gym_args']

    # total_timesteps = args['common'].get('total_steps', int(1e6))
    # n_steps_to_save = args['common'].get('n_steps', 5e5)
    total_timesteps = 3000
    n_steps_to_save = 500
    save_path = os.path.join(args['common'].get('savedir', SRC_DIR + '/logs/'), flags.mode, flags.algo)

    env = make_vec_env('MvfstRl-v0', monitor_dir=save_path)
    env = VecCheckNan(env, raise_exception=True)
    env = VecNormalize(env, norm_obs=False, norm_reward=True)

    assert flags.algo is not None, "Algorithm should be assigned by using --algo"

    assert flags.algo in args['algo_supported'].keys(), "%s is not supported now" % flags.algo

    if flags.algo == "PPO2":
        from train.algos.ppo2 import PPO2Model

        model = PPO2Model.get_ppo(tuning=flags.tuning,
                                 use_lstm=flags.use_lstm,
                                 env=env)

    elif flags.algo == "DQN":

        from train.algos.dqn import DQNModel
        assert not flags.use_lstm, "lstm is not support for DQN"

        model = DQNModel.get_dqn(tuning=flags.tuning, env=env)
    else:
        pass

    callback = MyCallback(check_freq=n_steps_to_save, log_dir=save_path, flags=flags)
    model.learn(total_timesteps=total_timesteps, callback=callback)


def test(flags, ):
    args = ARGS['gym_args']

    if flags is None:
        print("Please assign algos by using parms --algo")
    algo_args = args['algo_supported']
    assert flags.algo in algo_args.keys(), "%s is not supporter now" % flags.algo

    model_path = os.path.join(args['common'].get('savedir'), 'train', flags.algo)
    model_name = '%s_model_best' % flags.algo

    if flags.algo == "PPO2":
        from stable_baselines import PPO2
        model = PPO2.load(os.path.join(model_path, model_name + '.zip'))
    elif flags.algo == "DQN":
        from stable_baselines import DQN
        model = DQN.load(os.path.join(model_path, model_name + '.zip'))

    env = make_vec_env('MvfstRl-v0')
    env = VecCheckNan(env, raise_exception=True)
    env = VecNormalize.load(os.path.join(model_path, model_name + '.pkl'), env)
    env.training = False
    env.norm_reward = False

    try:
        obs = env.reset()
        while True:
            action, _states = model.predict(obs, deterministic=True)
            obs, rewards, done, info = env.step(action)
            done = done.any() if isinstance(done, np.ndarray) else done
            if done:
                obs = env.reset()
    except KeyboardInterrupt:
        pass


def main(flags, ):
    def error_fn(flags, ):
        raise RuntimeError("Unsupported mode {}".format(flags.mode))

    dispatch = {"train": train, "test": test}
    run_fn = dispatch.get(flags.mode, error_fn)
    run_fn(flags)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Scalable Agent")
    common.add_args(parser)
    flags = parser.parse_args()
    main(flags)

