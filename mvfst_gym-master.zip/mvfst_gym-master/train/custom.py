# coding=utf-8
import os

import numpy as np
from stable_baselines.results_plotter import ts2xy, load_results
from stable_baselines.common.callbacks import BaseCallback


class MyCallback(BaseCallback):
    def __init__(self, check_freq: int, log_dir: str, flags, verbose=1):
        super(MyCallback, self).__init__(verbose)

        self.flags = flags

        self.check_freq = check_freq
        self.log_dir = log_dir
        self.save_path = os.path.join(self.log_dir, 'models')
        self.best_mean_reward = -np.inf

    def _init_callback(self) -> None:
        if self.save_path is not None:
            os.makedirs(self.save_path, exist_ok=True)

    def _on_step(self) -> bool:
        if self.n_calls % self.check_freq == 0:

            x, y = ts2xy(load_results(self.log_dir), 'timesteps')
            if len(x) > 0:
                mean_reward = np.mean(y[-100:])

                if self.verbose > 0:
                    print("Num timesteps: {}".format(self.num_timesteps))
                    print(
                        "Best mean reward: {:.2f} - Last mean reward per episode: {:.2f}".format(self.best_mean_reward,
                                                                                                 mean_reward))

                if mean_reward > self.best_mean_reward:
                    self.best_mean_reward = mean_reward
                    if self.verbose > 0:
                        print("Saving new best model at steps [{}] to {}".format(self.n_calls, self.log_dir))
                    self.model.save(self.log_dir + '/{}_model_best'.format(self.flags.algo))
                    stats_path = self.log_dir + '/{}_model_best.pkl'.format(self.flags.algo)
                    self.model.get_env().save(stats_path)

                self.model.save(save_path=self.save_path + '/{}_model_{}'.format(self.flags.algo, self.n_calls))
                self.model.get_env().save(self.save_path + '/{}_model_{}.pkl'.format(self.flags.algo, self.n_calls))

        return True
