#!/usr/bin/env python3

# Copyright (c) Facebook, Inc. and its affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#

# Run as python3 -m train.train

import argparse
import logging
import multiprocessing as mp
import os
import time

from train import common, traffic_env, gym_beast, constants

logging.basicConfig(level=logging.INFO)
os.environ["OMP_NUM_THREADS"] = "1"


def get_parser():
    parser = argparse.ArgumentParser()
    common.add_args(parser)

    return parser


def init_logdirs(flags, ):
    dir = constants.ARGS['gym_args']['common'].get('savedir', './logs/mvfst-gym')
    save_dir = os.path.join(dir, flags.mode)

    os.makedirs(save_dir, exist_ok=True)

    return save_dir


def run_remote(flags, train=True):

    flags.mode = "train" if train else "test"
    save_dir = init_logdirs(flags)

    logging.info("Starting {}, logdir={}".format(flags.mode, save_dir))

    # 起套接字
    gymbeast_proc = mp.Process(target=gym_beast.main,   args=(flags,))
    # 起数据流
    traffic_proc  = mp.Process(target=traffic_env.main, args=(flags, ))

    gymbeast_proc.start()

    time.sleep(3)  # To make ensure that SocketServer is listening ...
    traffic_proc.start()

    if train:
        gymbeast_proc.join()  # 感觉顺序应该不重要
        traffic_proc.kill()
    else:
        traffic_proc.join()
        gymbeast_proc.kill()

    logging.info("Done {}".format(flags.mode))


def main(flags, ):
    mode = flags.mode
    logging.info("Mode={}".format(mode))

    if mode == "train":
        # Train,
        run_remote(flags, train=True)

    elif mode == "test":
        # Only test
        run_remote(flags, train=False)
    else:
        raise RuntimeError("Unknown mode {}".format(mode))


if __name__ == "__main__":
    parser = get_parser()
    flags = parser.parse_args()
    main(flags)
