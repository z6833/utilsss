/*
* Copyright (c) Facebook, Inc. and its affiliates.
* All rights reserved.
*
* This source code is licensed under the license found in the
* LICENSE file in the root directory of this source tree.
*
*/
#include "CongestionControlEnv.h"
#include <math.h>
#include <iostream>
#include <folly/Conv.h>
#include <quic/congestion_control/CongestionControlFunctions.h>

namespace quic {

using Field = NetworkState::Field;

static const float kBytesToMB = 1e-6;
/// CongestionControlEnv impl

CongestionControlEnv::CongestionControlEnv(const Config& cfg, Callback* cob,
                                           const QuicConnectionStateBase& conn)
    : cfg_(cfg),
      cheng_(cfg.windowDuration),
      cob_(CHECK_NOTNULL(cob)),
      conn_(conn),
      evb_(folly::EventBaseManager::get()->getEventBase()),
      observationTimeout_(this, evb_),
      cwndBytes_(conn.transportSettings.initCwndInMss * conn.udpSendPacketLen) {
  // Initialize history with no-op past actions
  History noopHistory(Action{0}, cwndBytes_ / normBytes());
  history_.resize(cfg.historySize, noopHistory);
  scheduleTime_ = std::chrono::steady_clock::now();

  if (cfg.aggregation == Config::Aggregation::TIME_WINDOW) {
    CHECK_GT(cfg.windowDuration.count(), 0);
    observationTimeout_.schedule(cfg.windowDuration);
  }
}

void CongestionControlEnv::onAction(const Action& action) {
  evb_->runImmediatelyOrRunInEventBaseThreadAndWait([this, action] {
    updateCwnd(action.cwndAction);
    cob_->onUpdate(cwndBytes_);

    // Update history
    history_.pop_front();
    history_.emplace_back(action, cwndBytes_ / normBytes());

    const auto& elapsed = std::chrono::duration<float, std::milli>(
        std::chrono::steady_clock::now() - lastObservationTime_);
    VLOG(1) << "Action updated (cwndAction=" << action.cwndAction
            << ", cwnd=" << cwndBytes_ / conn_.udpSendPacketLen
            << "), policy elapsed time = " << elapsed.count() << " ms";
  });
}

void CongestionControlEnv::onNetworkState(NetworkState&& state) {
  VLOG(3) << __func__ << ": " << state;

  states_.push_back(std::move(state));

  switch (cfg_.aggregation) {
    case Config::Aggregation::TIME_WINDOW:
      DCHECK(observationTimeout_.isScheduled());
      break;
    case Config::Aggregation::FIXED_WINDOW:
      if (states_.size() == cfg_.windowSize) {
        handleStates();
      }
      break;
    default:
      LOG(FATAL) << "Unknown aggregation type";
      break;
  }
}


void CongestionControlEnv::observationTimeoutExpired() noexcept {
  handleStates();
  //observationTimeout_.schedule(cfg_.windowDuration);
  observationTimeout_.schedule(cheng_);
}

void CongestionControlEnv::handleStates() {
  if (states_.empty()) {
    return;
  }

  // Compute reward based on original states
  const auto& reward = computeReward(states_);
  
  scheduleTime_ = std::chrono::steady_clock::now();
  Observation obs(cfg_);
  obs.length = states_[0].size();
  obs.ptResult = stateSummary(states_);
  states_.clear();
  std::copy(history_.begin(), history_.end(), std::back_inserter(obs.history));

  VLOG(2) << __func__ << ' ' << obs;

  lastObservationTime_ = std::chrono::steady_clock::now();
  onObservation(std::move(obs), reward);
}

//定义一些函数
//求和 
float CongestionControlEnv::stateSum(float *ptState, int n){
  float sum=0;
  for (int i=0; i < n; ++i){
  sum=sum+ptState[i];
  }
  return sum;
}
//求最大值 
float CongestionControlEnv::stateMax(float *ptState, int n){
  float max=ptState[0];
  for (int i=1; i < n; ++i){
      if (ptState[i]>max)
      max=ptState[i];
  }
  return max;
}
//求最小值 
float CongestionControlEnv::stateMin(float *ptState, int n){
  float min=ptState[0];
  for (int i=1; i < n; ++i){
      if (ptState[i]<min)
      min=ptState[i];
  }
  return min;
}
//求均值 
float CongestionControlEnv::stateMean(float *ptState, int n){
  float mean=stateSum(ptState,n);
  mean=mean/n;
  return mean;
}
//求方差
float CongestionControlEnv::stateVar(float *ptState, int n){
  float mean=stateMean(ptState,n);
  float var=0;
  for (int i =0; i<n;++i){
  var=var+(ptState[i]-mean)*(ptState[i]-mean);
  }
  var=var/n;
  return var;
}


float* CongestionControlEnv::stateSummary(
    const std::vector<NetworkState>& states) {
  // Bassel's correction on stddev only when defined to avoid NaNs.
  bool unbiased = (states.size() > 1);

//将vector数据获取，然后求均值等操作并将其转换为一维数组
  if (states.size() == 0 ){
    LOG(ERROR) <<"empty states";
  }

  float *ptState = new float[states.size()];//使用new创建动态数组
  float *ptResult = new float[5*states[0].size()];
  
  for (uint16_t i = 0; i < states[0].size(); ++i){
    for (uint16_t j = 0; j < states.size(); ++j){
      ptState[j] = states[j][i];
    }
    if (i < 8)
        ptResult[i] = 0;
    else
        ptResult[i] =stateSum(ptState,states.size());
    ptResult[i+states[0].size()]=stateMean(ptState,states.size());
    ptResult[i+2*states[0].size()]=stateVar(ptState,states.size());
    ptResult[i+3*states[0].size()]=stateMin(ptState,states.size());
    ptResult[i+4*states[0].size()]=stateMax(ptState,states.size());
  }
  delete [] ptState;
  return ptResult;
}

float CongestionControlEnv::computeReward(
    const std::vector<NetworkState>& states){
  // Reward function is a combinaton of throughput, delay and lost bytes.
  // For throughput and delay, it makes sense to take the average, whereas
  // for loss, we compute the total bytes lost over these states.
  float Throughput = 0.0;
  float avgDelay = 0.0;
  float maxDelay = 0.0;
  float Lost = 0.0;
  float acked = 0.0;
  float received = 0.0;
  float min_rtt = 100000.0;
  float sent = 0.0;
  float lrtt = 0.0;
  float flighting = 0.0;


  for (const auto& state : states) {
    Throughput += state[Field::THROUGHPUT];
    avgDelay += state[Field::DELAY];
    min_rtt = std::min(min_rtt,state[Field::RTT_MIN]);
    maxDelay = std::max(maxDelay, state[Field::DELAY]);
    //maxDelay = state[Field::DELAY];
    Lost += state[Field::LOST];
    acked += state[Field::ACKED];
    received += state[Field::RECEIVED];
    sent += state[Field::SENT];
    lrtt += state[Field::LRTT];
    flighting += state[Field::IN_FLIGHT];
  }
  avgDelay /= states.size();
  lrtt /=states.size();
  Throughput /=states.size();

  std::chrono::milliseconds duration = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - scheduleTime_);
  //LOG(INFO) << "W18878_TEST: duration = " << duration.count();
  // Undo normalization and convert to MB/sec for throughput and ms for
  // delay.

  float throughputMBps =
      Throughput * normBytes() / normMs() * kBytesToMB * 1000.0;
  float egressThroughput = sent * normBytes() * kBytesToMB / duration.count() * 1000;
  float avgDelayMs = avgDelay * normMs();
  float maxDelayMs = maxDelay * normMs();
  float min_rttMs = min_rtt * normMs();
  float lrttMs = lrtt * normMs();
  uint64_t  lrtt_cheng = std::round(40);
  cheng_ = std::chrono::milliseconds(lrtt_cheng);
  float delayMs = (cfg_.maxDelayInReward ? maxDelayMs : avgDelayMs);
  float lostMbits = Lost * normBytes() * kBytesToMB;
  float ackedMbits = acked * normBytes() * kBytesToMB;
  float sentMbits = sent * normBytes() * kBytesToMB;
  float sent_rate = sentMbits / duration.count() * 1000;
  float receviedMbits = received * normBytes() * kBytesToMB;
  float flightMbits = flighting * normBytes() * kBytesToMB;
  float lostThroughput = Lost * normBytes() * kBytesToMB / duration.count() * 1000;
//  float lost_rate = lostMbits / (sentMbits+1);

//  float reward = cfg_.throughputFactor * Throughput * (1.0 - delayMs/20);
  float reward = 0;
  if (delayMs < (min_rttMs * 0.2 + 2)){
      reward = (egressThroughput - 0.05 * delayMs - 1.05 * lostThroughput) / 32;
  }else{
      reward = (egressThroughput - (delayMs - (min_rttMs * 0.2 + 2)) / (min_rttMs + 10) * egressThroughput - 0.05 * delayMs - 1.05 * lostThroughput) / 32;
  }
  VLOG(1) //<< "Num states = " << states.size()
          << " avg_throughput = " << throughputMBps
          << " MBps, send_rate = " << sent_rate
          << " MBps, avg_lrtt = " << lrttMs
          << " ms, avg_DelayMs = " << avgDelayMs
          << " ms, window_duration = " << lrtt_cheng
          << " ms, min_rttMs = " << min_rttMs
          << " ms, sentMbits = " << sentMbits
          << " Mb, ackedMbits = " << ackedMbits
          << " Mb, flightMbits = " << flightMbits
          << " Mb, total_lost = " << lostMbits
          << " Mb, reward = " << reward;

  return reward;
}

void CongestionControlEnv::updateCwnd(const uint32_t actionIdx) {
  DCHECK_LT(actionIdx, cfg_.actions.size());
  const auto& op = cfg_.actions[actionIdx].first;
  const auto& val = cfg_.actions[actionIdx].second;
  const auto& valBytes = val * conn_.udpSendPacketLen;

  switch (op) {
    case Config::ActionOp::NOOP:
      break;
    case Config::ActionOp::ADD:
      cwndBytes_ += valBytes;
      break;
    case Config::ActionOp::SUB:
      cwndBytes_ = (cwndBytes_ >= valBytes) ? (cwndBytes_ - valBytes) : 0;
      break;
    case Config::ActionOp::MUL:
      cwndBytes_ = std::round(cwndBytes_ * val);
      break;
    case Config::ActionOp::DIV:
      cwndBytes_ = std::round(cwndBytes_ * 1.0 / val);
      break;
    default:
      LOG(FATAL) << "Unknown ActionOp";
      break;
  }

  cwndBytes_ = boundedCwnd(cwndBytes_, conn_.udpSendPacketLen,
                           conn_.transportSettings.maxCwndInMss,
                           conn_.transportSettings.minCwndInMss);
}

/// CongestionControlEnv::Observation impl

uint16_t CongestionControlEnv::Observation::toArray(float** array_a){

  CHECK_EQ(history.size(), cfg_.historySize);

  // Dim per history = len(one-hot actions) + 1 (cwnd).
  // Total dim = flattened state dim + history dim.
  uint32_t historyDim = cfg_.actions.size() + 1;
  uint32_t dim = 5 * length + history.size() * historyDim + 4;

  int x = 0;

  // Serialize states
  
  float* temp = (float*)malloc(dim*sizeof(float));
  memset(temp, 0, dim*sizeof(float));
  memcpy(temp, ptResult, 5*length*sizeof(float));
  x = 5*length;

  // Serialize history
  for (const auto& h : history) {
    for (size_t i = 0; i < cfg_.actions.size(); ++i) {
      temp[x++] = (h.action.cwndAction == i);

    }
    temp[x++] = h.cwnd;
  }

  *array_a = temp;

  CHECK_EQ(x, dim-4);

  delete[] ptResult;
  return dim;
}

std::ostream& operator<<(std::ostream& os,
                         const CongestionControlEnv::Observation& obs) {
  os << "Observation (" << obs.states.size() << " states, "
     << obs.history.size() << " history):" << std::endl;
  for (const auto& state : obs.states) {
    os << state << std::endl;
  }
  for (const auto& history : obs.history) {
    os << history << std::endl;
  }
  return os;
}

std::ostream& operator<<(std::ostream& os,
                         const CongestionControlEnv::History& history) {
  os << "History: action=" << history.action.cwndAction
     << " cwnd=" << history.cwnd;
  return os;
}

}  // namespace quic
