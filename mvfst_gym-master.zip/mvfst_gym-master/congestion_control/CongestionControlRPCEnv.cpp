/*
* Copyright (c) Facebook, Inc. and its affiliates.
* All rights reserved.
*
* This source code is licensed under the license found in the
* LICENSE file in the root directory of this source tree.
*
*/
#include "CongestionControlRPCEnv.h"
#include <sys/socket.h>
#include <iostream>

using namespace std;

#define MYPORT 30000
#define BUFFER_SIZE 1024

namespace quic {

namespace {
constexpr std::chrono::seconds kConnectTimeout{5};
}

CongestionControlRPCEnv::CongestionControlRPCEnv(
    const Config& cfg, Callback* cob, const QuicConnectionStateBase& conn)
    : CongestionControlEnv(cfg, cob, conn) {


  thread_ = std::make_unique<std::thread>(&CongestionControlRPCEnv::loop, this,
                                          cfg.rpcAddress);

  // Wait until connected to gRPC server
  std::unique_lock<std::mutex> lock(mutex_);
  cv_.wait(lock, [&]() -> bool { return connected_; });
}

CongestionControlRPCEnv::~CongestionControlRPCEnv() {
  shutdown_ = true;

  thread_->join();
}

void CongestionControlRPCEnv::onObservation(Observation&& obs, float reward) {
  std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
  if (!lock) {
    // If we can't acquire the mutex, then we haven't received the action
    // back for the previous observation. Although this should almost never
    // happen as model runtimes are sufficiently fast, we handle this safely
    // here by skipping this observation.
    LOG(WARNING) << __func__ << ": Still waiting for an update from "
                                "ActorPoolServer, skipping observation.";
    return;
  }
  len_ = obs.toArray(&ptArray_);
  reward_ = reward;
  observationReady_ = true;
  lock.unlock();
  cv_.notify_one();
}

void CongestionControlRPCEnv::loop(const std::string& address) {

  // Notify that we are connected
  {
    std::lock_guard<std::mutex> g(mutex_);
    connected_ = true;
  }
  cv_.notify_one();
  LOG(INFO) << "Connected to Server " ;

  Action action;
  bool done = true;
  uint32_t episode_step = 0;
  float episode_return = 0.0;
  std::unique_lock<std::mutex> lock(mutex_);

  //sockaddr_in
  struct sockaddr_in servaddr;
  memset(&servaddr, 0, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_port = htons(MYPORT);
  servaddr.sin_addr.s_addr = inet_addr(address.c_str());

   // socket
   int conn = socket(AF_INET, SOCK_STREAM, 0);
   int stats = connect(conn, (struct sockaddr *)&servaddr, sizeof(servaddr));

   //connect server
   if (stats < 0)
   {
       LOG(FATAL) << "Failed to connect to Server: " << address;
       exit(1);
   }

  char firstRecv[1024];
  int rst = recv(conn, &firstRecv, sizeof(firstRecv), 0);// 接收初始化动作
  if (rst > 0)
  {
    LOG(INFO) << "First action received successfully ...";
  }
  while (!shutdown_) {

    cv_.wait(lock, [&]() -> bool { return (observationReady_ || shutdown_); });

    done = (episode_step == 0);
    episode_return += reward_;
    episode_step++;

    observationReady_ = false;  // Back to waiting

    float arr[] = {reward_, float(done), float(episode_step), episode_return};
    char temp[len_*sizeof(float)];

    memcpy(ptArray_+len_-4,arr,4*sizeof(float));

    memset(temp, 0, sizeof(temp));
    memcpy(temp, ptArray_, len_*sizeof(float));
    send(conn, temp, len_*sizeof(float), 0);

    char recvbuf[1024];
    recv(conn, &recvbuf, sizeof(recvbuf), 0);// 接收返回值
    uint32_t action_t = int(*recvbuf) - 48;// 解析返回值（动作）

    action.cwndAction = action_t;
    onAction(action);

    if (ptArray_ != NULL)
    {
      free(ptArray_);
      ptArray_ = NULL;
    }
  }

}

}  // namespace quic
