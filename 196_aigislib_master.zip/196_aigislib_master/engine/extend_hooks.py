import glob
import json
import logging
import os

from detectron2.engine import HookBase
from detectron2.utils import comm

from enums.errno import ErrNo
from enums.model_status import ModelStatus
from enums.training_task_status import TrainingTaskStatus
from data_access.services.training_task_service import get_training_task, end_training_task, update_training_progress
# from utils.log import logger


class UserStopError(RuntimeError):
    pass


class DataBaseError(RuntimeError):
    pass


def get_envet_log(log_dir):
    logs = glob.glob(os.path.join(log_dir, "events.out.tfevents.*"))
    return sorted(logs)[-1]

#
# def set_dict(sdict, name_list):
#     if len(name_list) == 1:
#         sdict[name_list[0]] = None
#         # return sdict[name_list[0]]
#     else:
#         sdict[name_list[0]] = dict()
#         set_dict(sdict[name_list[0]],name_list[1:])


class MultiDict(dict):
    def __getitem__(self, item):
        try:
            return dict.__getitem__(self,item)
        except KeyError:
            value = self[item] = type(self)()
            return value


def get_metric_data_json(metric_file):
    """
    通过生成的metric.json文件去获取模型评估指标，以json的形式返回，
    目标检测返回结果为：
        {'iteration': 30,
         'val_100_1.0': {'bbox': {'AP': 0.38280695580856217,
           'AP50': 1.2860254598463319,
           'AP75': 0.006479705562179254,
           'APl': 0.0,
           'APm': 0.1989620579786922,
           'APs': 0.3846297315131553}},
         'val_99_1.0': {'bbox': {'AP': 0.38280695580856217,
           'AP50': 1.2860254598463319,
           'AP75': 0.006479705562179254,
           'APl': 0.0,
           'APm': 0.1989620579786922,
           'APs': 0.3846297315131553}}}
    :param metric_file: metric.json文件路径
    :return:
    """
    with open(metric_file,'r') as f:
        last_line  = ""
        for line in f:
            tmp_line  = line.strip()
            if tmp_line != "":
                last_line = tmp_line
    metric_dict = json.loads(last_line)
    ret_dict = MultiDict()
    # multi_dict = MultiDict()

    for key,val in metric_dict.items():
        val = "{0}".format(val)
        key_list = key.split('/')
        tmp_dict = dict()
        num_keys = len(key_list)
        for i,k in enumerate(key_list):
            if i == num_keys -1:
                tmp_dict[k] = val
            elif i == 0:
                tmp_dict = ret_dict[k]
            else:
                tmp_dict = tmp_dict[k]
        # if len(key_list) == 3:
        #     data_name,task_type,metric = key_list
        #     if data_name not in ret_dict:
        #         ret_dict[data_name] = dict()
        #     if task_type not in  ret_dict[data_name]:
        #         ret_dict[data_name][task_type] = dict()
        #     if metric not in  ret_dict[data_name][task_type]:
        #         ret_dict[data_name][task_type][metric] = dict()
        #     ret_dict[data_name][task_type][metric] = val
        # else:
        #     ret_dict[key] = val
    return json.dumps(ret_dict)


class TaskDBHook(HookBase):
    def __init__(self, work_dir, checkpointer, task_id):
        self.logger = logging.getLogger(__name__)
        self.logger.info("TaskDBHook")
        self.checkpointer = checkpointer
        self._task_id = task_id
        self._work_dir = work_dir

    def after_step(self):
        # logger = logging.getLogger(__name__)
        self.logger.info("after_step process")

        res = get_training_task(self._task_id)

        if res.errno == ErrNo.SUCCESS.get_code():
            task = res.data
            if task.status == TrainingTaskStatus.STOPPING.get_code() or \
                    task.status == TrainingTaskStatus.PAUSING.get_code():
                # iteration = int(self.trainer.iter)
                # additional_state = {"iteration": iteration}
                # model_file = "{}_{}_{:07d}".format("model", str(self._task_id), iteration)
                # self.checkpointer.save(model_file, **additional_state)
                # # todo 将模型存储到hdfs上，邓鹏提供接口
                # res = end_training_task(self._task_id,is_success=False)
                self.logger.info("task {} status {} has been process: {}".format(self._task_id, task.status, res.errno))
                raise UserStopError("User stop task : status {}".format(task.status))
            progress = 100*(self.trainer.iter/self.trainer.max_iter)
            res = update_training_progress(self._task_id, progress)

    def after_train(self):

        self.logger.info("after_train process")
        print("print after_train process")

        res = get_training_task(self._task_id)
        config_path = os.path.join(self._work_dir, "config.yaml")
        log_path = get_envet_log(self._work_dir)
        if res.errno == ErrNo.SUCCESS.get_code():
            task = res.data
            if task.status == TrainingTaskStatus.STOPPING.get_code() or \
                    task.status == TrainingTaskStatus.PAUSING.get_code():
                iteration = int(self.trainer.iter)
                additional_state = {"iteration": iteration}
                model_prefix = "{}_{}_{:07d}".format("model", str(self._task_id), iteration)
                self.checkpointer.save(model_prefix, **additional_state)
                # todo 将模型存储到hdfs上，邓鹏提供接口
                # create_model(task.name, task.description, task.training_set_pub_ids,
                #              task.validate_set_pub_ids, task.model_structure_id, task.init_model_id,
                #              config_path, model_file, log_path, )
                model_file = os.path.join(self.checkpointer.save_dir, model_prefix+".pth")
                model_status = 0 if task.status == TrainingTaskStatus.PAUSING.get_code() else 1
                res = end_training_task(self._task_id, config_path, model_file, log_path,
                                        model_status, is_success=False)
                self.logger.info("after_train failed")
            else:
                model_file = os.path.join(self.checkpointer.save_dir, "model_final.pth")
                # print("after train :",model_file)
                # 获取评估结果
                # print("train end latest history: ",self.trainer.storage.latest())
                metric_file = os.path.join(self._work_dir,"metrics.json")
                print("metric json path: ",self._work_dir,os.path.exists(metric_file),metric_file)
                val_result = get_metric_data_json(metric_file)
                print("val_result: ",val_result)
                # todo 将best_model 拷贝到hdfs上
                res = end_training_task(self._task_id, config_path, model_file, log_path,
                                        ModelStatus.FINISHED.get_code(), val_result, is_success=True)
                print("end training_tast_end: ",res.as_dict())
                progress = 100
                res = update_training_progress(self._task_id, progress)

                self.logger.info("after_train success")
        else:
            raise DataBaseError("Can not connect database")
        # comm.synchronize()
