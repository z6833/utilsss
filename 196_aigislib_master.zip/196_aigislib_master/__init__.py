from aigislib import modeling
from aigislib import config