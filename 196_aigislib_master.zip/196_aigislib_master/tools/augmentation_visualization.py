import cv2
import numpy as np
from aigislib.config import get_cfg
from aigislib.data.transformer.build import build_augmentation
from detectron2.engine import default_argument_parser
from detectron2.data import transforms as T


def get_augmentation(args):
    cfg = get_cfg()
    cfg.merge_from_file(args.config_file)
    cfg.merge_from_list(args.opts)
    cfg.freeze()

    augmentations = build_augmentation(cfg)
    augmentations = T.AugmentationList(augmentations)

    return augmentations


def apply_augmentations(image: np.ndarray, augmentations: T.AugmentationList):
    aug_input = T.AugInput(image)
    augmentations(aug_input)
    return aug_input.image


if __name__ == '__main__':
    '''
    数据增强可视化程序，可用于数据增强配置参数的调试
    读取配置文件中的增强处理，对单张图片img_path进行处理，增强后图片写入到dst_path中
    '''
    args = default_argument_parser().parse_args()
    args.config_file = '/code/aigislib/model_zoo/example/test_csv_mask.yaml'
    img_path = '/data/checked_road_imgs/val/sat/chengzhen_road_02clip_1.tif'
    dst_path = './test.tif'

    augmentations = get_augmentation(args)
    src_img = cv2.imread(img_path)
    img = src_img.copy() # apply_augmentation会修改传入的图片
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    aug_img = apply_augmentations(img, augmentations)
    cv2.imwrite(dst_path, cv2.cvtColor(aug_img, cv2.COLOR_RGB2BGR))
