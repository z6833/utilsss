import tensorrt as trt
import pycuda.driver as cuda
import pycuda.autoprimaryctx
import numpy as np

class TRTModel():
    def __init__(self, engine_path: str, input_names, output_names) -> None:
        TRT_LOGGER = trt.Logger(trt.Logger.WARNING)  # 输出日志 
        runtime = trt.Runtime(TRT_LOGGER)  # 初始化runtime
        with open(engine_path, "rb") as f, trt.Runtime(TRT_LOGGER) as runtime:
            self.engine = runtime.deserialize_cuda_engine(f.read())
            self.context = self.engine.create_execution_context()
        self.input_names = input_names
        self.output_names = output_names

    def __call__(self, *imgs):
        # 获取cuda流的handle
        stream = cuda.Stream()

        d_input_list = []
        d_output_list = []
        h_output_list = []
        output_ids = []
        result_trt = []
        # 遍历输入的名称，将图像传入对应的cuda显存
        for i, input_name in enumerate(self.input_names):
            # 获取名称对应的binding id
            idx = self.engine.get_binding_index(input_name)
            # 将binding的尺寸设为与输入图片一致
            self.context.set_binding_shape(idx, imgs[i].shape)
            # 根据尺寸申请内存
            h_input = cuda.pagelocked_empty(trt.volume(self.context.get_binding_shape(idx)), dtype=np.float32)
            # 将numpy数组拉直后复制到申请的内存空间上
            np.copyto(h_input, imgs[i].ravel())
            # 申请显存空间，返回一个DeviceAllocation表示线性设备内存的地址，存入list中
            d_input_list.append(cuda.mem_alloc(h_input.nbytes))
            # 将数据从显存中复制到内存
            cuda.memcpy_htod_async(d_input_list[-1], h_input, stream)

        # 遍历输出的名称，为每个输出创建空间
        for i, output_name in enumerate(self.output_names):
            idx = self.engine.get_binding_index(output_name)
            output_ids.append(idx)
            h_output_list.append(cuda.pagelocked_empty(trt.volume(self.context.get_binding_shape(idx)), dtype=np.float32))
            d_output_list.append(cuda.mem_alloc(h_output_list[-1].nbytes))

        # 将输入和输出的地址（int类型）存入list
        bindings = list(map(int, d_input_list+d_output_list))
        # 对一个batch进行异步推理
        self.context.execute_async_v2(bindings=bindings, stream_handle=stream.handle)
        # 使用列表生成式将显存上的输出复制到内存中 
        [cuda.memcpy_dtoh_async(h, d, stream) for h,d in zip(h_output_list, d_output_list)]
        # 等待cuda流上操作运行完成
        stream.synchronize()
        
        # 输出得到的数据为一维数据，根据binding中的对应尺寸进行reshape
        for id, h_output in zip(output_ids, h_output_list):
            result = h_output.reshape(self.context.get_binding_shape(id))
            result_trt.append(result)
        return result_trt


if __name__ == '__main__':
    trt_model = TRTModel('/code/test/aigislib/run/model.trt')
    a = [512,768,1024]
    for i in range(3):
        img = np.random.random((3,a[i],a[i]))
        ret = trt_model(img)
        print(ret.shape)