from typing import Tuple
from detectron2.config.config import CfgNode
from detectron2.export import TracingAdapter
from detectron2.export.flatten import flatten_to_tuple
from detectron2.modeling import GeneralizedRCNN
from detectron2.utils.file_io import PathManager
from detectron2.utils.logger import setup_logger
from detectron2.data import detection_utils as utils
from detectron2.data.catalog import DatasetCatalog
import torch.nn as nn
import torch
import cv2
import numpy as np
import os
import sys
import pathlib
cwd_path = pathlib.Path(__file__).absolute()
parent_path = cwd_path.parent.parent.parent.as_posix()
sys.path.append(parent_path)
from aigislib.data.data_parse import build_data_parse
from aigislib.data.data_mapper import build_data_mapper
from aigislib.modeling.meta_arch import SiameseChangeDetector
from aigislib.tools.triton_tools.gen_pbtxt import PbtxtGenerator


class ModelExporter():
    def __init__(
        self, 
        torch_model: nn.Module, 
        cfg: CfgNode = None, 
        tensor_size: Tuple = None,
        batch_size: int = 1
    ):
        """模型输出类，可输出torchscript、onnx及tensorrt（tensorrt需要相关环境）

        Args:
            torch_model (nn.Module): aigislib训练完成后的模型
            cfg (CfgNode, optional): aigislib的配置，为None则不使用配置文件. Defaults to None.
            tensor_size (Tuple, optional): 设定示例输入的tensor尺寸，为None则为默认尺寸. Defaults to None. 
            batch_size (int): 设定示例输入的batch size，可使模型进行批量推理，导出后无法更改输入个数. Defaults to 1.
        """
        self.logger = setup_logger(name=__name__)
        self.cfg = cfg
        # 样例输入，用于跟踪
        self.input_generator = self.get_example_input_from_cfg(
            tensor_size=tensor_size, batch_size=batch_size)
        input_dict_list = next(self.input_generator)
        # 将detectron2的字典输入输出修改为tuple输入输出，以便跟踪
        torch_model.eval()
        inputs, inference = self._get_inputs_inference(torch_model, input_dict_list)
        self.traceable_model = TracingAdapter(torch_model, inputs, inference)

    def _get_inputs_inference(self, model, input_dict_list):

        if isinstance(model, GeneralizedRCNN):
            inputs = [{'image': input_dict['image'].float()} for input_dict in input_dict_list]
            def inference(model, inputs):
                # use do_postprocess=False so it returns ROI mask
                inst = model.inference(inputs, do_postprocess=False)
                return [{"instances": inst_i} for inst_i in inst]
        
        elif isinstance(model, SiameseChangeDetector):
            inputs = [{
                    'pre_image': input_dict['pre_image'].float(), 
                    'post_image': input_dict['post_image'].float()
                } for input_dict in input_dict_list]
            inference = None

        else:
            inputs = [{'image': input_dict['image'].float()} for input_dict in input_dict_list]
            inference = None

        return inputs, inference
    
    def export_traced_torchscript(self, output_file_path: str):
        """以跟踪模式导出torchscript，不推荐有if-else等控制流的模型使用

        Args:
            output_file_path (str): 输出文件的路径
        """
        ts_model = torch.jit.trace(self.traceable_model, self.traceable_model.flattened_inputs)
        self.logger.info('Checking exported TorchScript model...')
        if self.check_model_result(ts_model, 'torchscript'):
            self.logger.info('Exported TorchScript model is good.')
            with PathManager.open(output_file_path, "wb") as f:
                torch.jit.save(ts_model, f)
                self.logger.info(
                    f'TorchScript model saved successfully in {output_file_path}')

            # 生成triton需要的config.pbtxt文件
            self.logger.info('Generating Triton pbtxt file...')
            pbtxt_path = pathlib.Path(output_file_path).parent.parent.joinpath('config.pbtxt')
            pbtxt_gen = PbtxtGenerator.from_traceable_model(
                self.traceable_model, str(pbtxt_path), self.logger.info)
            pbtxt_gen()
        else:
            self.logger.error('Export TorchScript model failed.')

    def export_onnx_model(self, output_file_path: str):
        """导出为onnx模型，使用PyTorch内置函数导出

        Args:
            output_file_path (str): 输出文件的路径
        """
        import onnx
        # 获取原模型的输入输出及名称
        out = self.traceable_model(*self.traceable_model.flattened_inputs)
        origin_input = self.traceable_model.inputs_schema(self.traceable_model.flattened_inputs)
        origin_output = self.traceable_model.outputs_schema(out)
        input_names = [name for name in sorted(origin_input[0][0].keys())]
        output_names = [name for name in sorted(origin_output[0].keys())]

        # 设置onnx动态尺寸
        dynamic_axes = dict()
        for name in input_names:
            dim = origin_input[0][0][name].ndim
            single_tensor_axes = dict()
            for i in range(dim):
                single_tensor_axes[i] = str(i)
            dynamic_axes[name] = single_tensor_axes
        for name in output_names:
            dim = origin_output[0][name].ndim
            single_tensor_axes = dict()
            for i in range(dim):
                single_tensor_axes[i] = str(i)
            dynamic_axes[name] = single_tensor_axes

        with PathManager.open(output_file_path, "wb") as f:
            torch.onnx.export(
                self.traceable_model,
                self.traceable_model.flattened_inputs,
                f,
                export_params=True,
                opset_version=11,
                do_constant_folding=True,
                input_names=input_names,
                output_names=output_names,
                dynamic_axes=dynamic_axes)
        self.onnx_input_names = input_names
        self.onnx_output_names = output_names
        self.logger.info('Checking exported ONNX model...')
        if self.check_model_result(onnx.load(output_file_path), 'onnx'):
            self.logger.info('Exported ONNX model is good.')
            self.logger.info(
                f'ONNX model saved successfully in {output_file_path}')
        else:
            self.logger.error('Export ONNX model failed.')
            os.remove(output_file_path)

    def remove_onnx_pads(self, onnx_path: str):
        """移除onnx中的Pad操作，使模型可以转为TensoRT

        Args:
            onnx_path (str): onnx模型的路径
        """
        import onnx
        from onnx.helper import make_node
        from onnxsim import simplify
        onnx_model = onnx.load(onnx_path)
        graph = onnx_model.graph
        for node in graph.node:
            if node.op_type == 'Pad':
                # 获取输入数据的name，Pad操作中input[0]为输入的图像
                input_data = node.input[0]
                # 获取输出数据的name，Pad操作只有一个输出
                output_data = node.output[0]
                for i, next_node in enumerate(graph.node):
                    # 判断节点的输入中是否有Pad操作的输出
                    if output_data in next_node.input:
                        # detectron2读取图片时Pad操作下一层为Unsqueeze
                        if next_node.op_type == 'Unsqueeze':
                            new_node = make_node(
                                op_type=next_node.op_type,
                                inputs=[input_data],
                                outputs=next_node.output,
                                name=next_node.name,
                                axes=next_node.attribute[0].ints
                            )
                            graph.node.remove(next_node)
                            graph.node.insert(i, new_node)
                        # UNet中Pad操作下一层为Concat
                        elif next_node.op_type == 'Concat':
                            new_node = make_node(
                                op_type=next_node.op_type,
                                inputs=[input_data if ip ==
                                        output_data else ip for ip in next_node.input],
                                outputs=next_node.output,
                                name=next_node.name,
                                axis=next_node.attribute[0].i
                            )
                            graph.node.remove(next_node)
                            graph.node.insert(i, new_node)
        onnx.checker.check_model(onnx_model)
        # 设定各输入的尺寸
        example_input_dict = next(self.input_generator)
        inputs, _ = self._get_inputs_inference(self.traceable_model.model, example_input_dict)
        example_img, _ = flatten_to_tuple(inputs)
        input_shapes = dict()
        for name, img in zip(self.onnx_input_names, example_img):
            input_shapes[name] = img.shape
        # 简化模型，将不需要的节点删去
        model_simp, check = simplify(
            model=onnx_model, input_shapes=input_shapes, dynamic_input_shape=True)
        self.logger.info('Checking simplified ONNX model...')
        if self.check_model_result(model_simp, 'onnx'):
            onnx.save(model_simp, onnx_path)
            self.logger.info('Simplified ONNX model is good.')
            self.logger.info(
                f'Simplified ONNX model saved successfully in {onnx_path}')
        else:
            self.logger.warning(
                'Simplified ONNX model failed. May have trouble exporting TensorRT.')

    def export_tensorrt(
        self,
        trtexec_path: str,
        output_file_path: str,
        dynamic_shape=False,
        shape='3x512x512',
        min_shape='3x512x512',
        max_shape='3x1024x1024'
    ):
        """导出为TensorRT的Engine，需要TensorRT环境

        Args:
            trtexec_path (str): TensorRT转换程序的路径
            output_file_path (str): 输出文件的路径
            dynamic_shape (bool, optional): TensorRT推理时是否使用动态尺寸. Defaults to False.
            shape (str, optional): TensorRT推理时接收输入的尺寸，若使用动态尺寸，则该参数为最佳性能尺寸. Defaults to '3x512x512'.
            min_shape (str, optional): 使用动态尺寸时需要，TensorRT推理时可接受的最小尺寸. Defaults to '3x512x512'.
            max_shape (str, optional): 使用动态尺寸时需要，TensorRT推理时可接受的最大尺寸. Defaults to '3x1024x1024'.
        """
        self.export_onnx_model(f'{output_file_path}.onnx')
        self.remove_onnx_pads(f'{output_file_path}.onnx')
        command = []
        command.append(trtexec_path)
        command.append(f'--onnx={output_file_path}.onnx')
        command.append(f'--saveEngine={output_file_path}')
        command.append('--workspace=6000')
        if dynamic_shape:
            command.append(f'--explicitBatch')
            command.append(f'--minShapes={self._get_tensorrt_shapes_str(min_shape)}')
            command.append(f'--optShapes={self._get_tensorrt_shapes_str(shape)}')
            command.append(f'--maxShapes={self._get_tensorrt_shapes_str(max_shape)}')
        else:
            command.append(f'--shapes={self._get_tensorrt_shapes_str(shape)}')
        command_str = ' '.join(command)
        ret = os.popen(command_str).read()
        for logline in ret.split('\n'):
            self.logger.info(logline)
        os.remove(f'{output_file_path}.onnx')
        if ret =='' or 'FAILED' in ret:
            self.logger.error('Export TensorRT Model failed.')
            return

        self.logger.info('Checking TensorRT model...')
        if self.check_model_result(output_file_path, 'tensorrt'):
            self.logger.info('Exported TensorRT model is good.')
        else:
            self.logger.error('Export TensorRT model failed.')

    def _get_tensorrt_shapes_str(self, shape_str):
        input_names = self.onnx_input_names
        shapes = [f'{name}:{shape_str}' for name in input_names]
        return ','.join(shapes)

    def check_model_result(
        self,
        model,
        model_type,
        check_num=3
    ):
        """检查导出的模型的输出结果与原模型是否一致

        Args:
            model (Union[ScriptModule, onnx.ModelProto, str]): TorchScript模型或ONNX模型或TRT模型路径
            model_type: 模型的类型，可选torchscript, onnx, tensorrt
            check_num (int, optional): 循环生成检查数据的数量. Defaults to 3.

        Returns:
            bool: 一致返回True，否则返回False
        """ 
        self.traceable_model.eval()  # 导出onnx时可能会造成状态改变，需要重新回到评估模式
        # 循环三次，使用配置文件中的测试集数据（如果有）
        for i in range(check_num):
            example_input_dict_list = next(self.input_generator)
            inputs, _ = self._get_inputs_inference(self.traceable_model.model, example_input_dict_list)
            example_img, _ = flatten_to_tuple(inputs)

            # 获取原始Pytorch模型的结果
            torch_result = self.traceable_model(
                *example_img)[0].detach().cpu().numpy()

            # 获取TorchScript模型结果
            if model_type == 'torchscript':
                export_model_result = model(*example_img)[
                    0].detach().cpu().numpy()

            # 获取ONNX模型结果
            elif model_type == 'onnx':
                if i == 0:
                    import onnxruntime
                    sess = onnxruntime.InferenceSession(model.SerializeToString())
                    input_names = [sess_input.name for sess_input in sess.get_inputs()]
                example_img = [img.cpu().numpy() for img in example_img]
                input_onnx_dict = dict(zip(input_names, example_img))
                export_model_result = sess.run(
                    None, input_onnx_dict)[0]
            
            # 获取TensorRT模型结果
            elif model_type == 'tensorrt':
                if i == 0:
                    from aigislib.tools.tensorrt_exec import TRTModel
                    trt_model = TRTModel(model, self.onnx_input_names, self.onnx_output_names)
                example_img = [img.cpu().numpy() for img in example_img]
                export_model_result = trt_model(*example_img)[0]

            # 判断导出模型结果与PyTorch结果是否接近
            if not np.allclose(torch_result, export_model_result, rtol=1e-4, atol=1e-5):
                difference = np.max(np.abs(torch_result - export_model_result))
                self.logger.warning(
                    f"Tensor changes after exporting, the max diff is {difference}")
                return False
        return True

    def export_from_cfg(self):
        """根据配置文件导出对应的模型
        """   
        assert self.cfg is not None, 'ModelExporter did not have cfg!'     
        if self.cfg.EXPORT.TORCHSCRIPT.ENABLE:
            self.export_traced_torchscript(self.cfg.EXPORT.TORCHSCRIPT.OUTPUT)
        if self.cfg.EXPORT.ONNX.ENABLE:
            self.export_onnx_model(self.cfg.EXPORT.ONNX.OUTPUT)
        if self.cfg.EXPORT.TENSORRT.ENABLE:
            self.export_tensorrt(
                self.cfg.EXPORT.TENSORRT.EXEC_PATH, 
                self.cfg.EXPORT.TENSORRT.OUTPUT, 
                dynamic_shape=self.cfg.EXPORT.TENSORRT.DYNAMIC_SHAPE, 
                shape=self.cfg.EXPORT.TENSORRT.SHAPE, 
                min_shape=self.cfg.EXPORT.TENSORRT.MIN_SHAPE, 
                max_shape=self.cfg.EXPORT.TENSORRT.MAX_SHAPE)

    def get_example_input_from_cfg(self, tensor_size=None, batch_size=1):
        """根据配置文件获取示例输入

        Args:
            tensor_size (Tuple, optional): 示例输入的tensor尺寸. Defaults to None.

        Yields:
            list: 示例输入，字典的列表
        """        
        if self.cfg is None:  # 无配置文件，输出随机矩阵
            while True:
                if tensor_size is None:
                    yield [{'image': torch.randn((3,512,512))} for i in range(batch_size)]
                else:
                    yield [{'image': torch.randn(tensor_size)} for i in range(batch_size)]
        
        # 使用data parser读取配置文件中第一个测试集
        dataset_name, parse_name, data_path = self.cfg.DATASETS.TEST[0]
        parser = build_data_parse(parse_name)
        mapper = build_data_mapper(self.cfg.DATASETS.DatasetMapper)(self.cfg, is_train=False)
        data_dict_list = parser(data_path, dataset_name=dataset_name)
        if dataset_name in DatasetCatalog.list():
            DatasetCatalog.remove(dataset_name)
        while True:
            input_dict_list = list()
            for index, data_dict in enumerate(data_dict_list):
                path = data_dict['file_name']
                # 指定tensor尺寸则直接读取path中的图片，并缩放至tensor尺寸
                if tensor_size is not None:
                    try:
                        origin_img = utils.read_image(path, "RGB")
                        origin_img = cv2.resize(origin_img, (tensor_size[1], tensor_size[2]))
                        image = torch.from_numpy(origin_img.transpose(2,0,1))
                        input_dict = {'image': image}
                        input_dict_list.append(input_dict)                
                    except Exception as e:
                        self.logger.warning(f'Read image {path} failed.')
                        self.logger.warning(str(e))
                        continue
                # 若无指定tensor尺寸，则通过配置文件中的mapper读取
                else:
                    input_dict = mapper(data_dict)
                    input_dict_list.append(input_dict) 
                if (index+1) % batch_size == 0:
                    # 数量达到batch_size，返回结果
                    yield input_dict_list
                    input_dict_list = list()


if __name__ == '__main__':
    import argparse
    from detectron2.checkpoint import DetectionCheckpointer
    from detectron2.modeling import build_model
    from aigislib.config import get_cfg
    parser = argparse.ArgumentParser(
        description="Export a model for deployment.")
    parser.add_argument(
        "--format",
        choices=["tensorrt", "onnx", "torchscript"],
        help="output format",
        default="torchscript",
    )
    parser.add_argument("--config-file", default="/code/aigislib/model_zoo/semantic_segmentation/deeplabv3plus.yaml",
                        metavar="FILE", help="path to config file")
    parser.add_argument("--output", default="/code/torchscript",
                        help="output directory for the converted model")
    parser.add_argument("--weights", default="/code/aigislib/output/model_final.pth",
                        help="path to model weights")
    parser.add_argument("--batch-size", default=1, type=int,
                        help="batch size of torchscript")
    args = parser.parse_args()

    PathManager.mkdirs(args.output)
    PathManager.mkdirs(os.path.join(args.output, '1'))

    cfg = get_cfg()
    cfg.merge_from_file(args.config_file)
    cfg.freeze()

    torch_model = build_model(cfg)
    DetectionCheckpointer(torch_model).resume_or_load(args.weights)
    torch_model.eval()

    exporter = ModelExporter(torch_model, cfg, batch_size=args.batch_size)
    if args.format == 'tensorrt':
        exporter.export_tensorrt(
            '/root/TensorRT-8.0.3.4/bin/trtexec', os.path.join(args.output, 'model.trt'))
    elif args.format == 'onnx':
        exporter.export_onnx_model(os.path.join(args.output, 'model.onnx'))
    elif args.format == 'torchscript':
        exporter.export_traced_torchscript(
            os.path.join(args.output, '1', 'model.pt'))
    else:
        raise NotImplementedError
