
import cv2
import torch
import numpy as np
import torch.nn.functional as F
from detectron2.modeling import build_model
from detectron2.checkpoint import DetectionCheckpointer

from aigislib.config.config import get_cfg


class BasePredictor(object):
    def __init__(self, cfg_file, model_file):
        """
        模型推理的基类，使用ai gis lib库
        :param cfg_file: 模型配置文件路径，只用于对模型结构进行配置
        :param model_file: 模型文件路径
        """
        cfg = get_cfg()                        # 获取默认配置文件中的所有配置信息
        cfg.merge_from_file(cfg_file)          # 通过配置文件对默认配置文件的对应内容进行更改
        if model_file:
            cfg.defrost()                      # 激活配置文件，使得其中的参数可更改
            cfg.MODEL.WEIGHTS = model_file     # 将配置文件路径更改为当前输入的模型文件
        self.cfg = cfg.clone()                 # 拷贝配置文件信息
        self.cfg.freeze()                      # 冻结配置文件信息
        self.model = build_model(self.cfg)     # 通过配置文件内容构建模型结构
        self.model.eval()                      # 冻结模型结构，使得模型无法进行反向传播操作
        self.image_format = self.cfg.INPUT.FORMAT
        check_pointer = DetectionCheckpointer(self.model)
        check_pointer.load(cfg.MODEL.WEIGHTS)  # 加载模型文件，此时模型都准备好了，可以传入图片进行推理工作

    def __call__(self, image_list):
        """
        模型开始推理
        :param image_list: 可以直接送入模型推理的数据类型（四维数据），可能是一个或两个（变化检测）
                           具体形状为: [n, 3, h, w]
        :return:
        """
        # 开始模型推理工作
        res = self.model(image_list)
        return res

    def read_single_data(self, data_path):
        """
        将数据打包成模型需要的格式
        :param data_path:
        :return:
        """
        image = cv2.imread(data_path)  # OpenCV在读取图片时，按BGR读取
        if self.image_format == "RGB":
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image_shape = image.shape
        if len(image_shape) != 3:
            print('目前只支持3通道图片')
            exit()
        image_dict = dict()
        image_dict['image'] = torch.tensor(image.transpose(2, 0, 1))
        image_dict['height'] = image_shape[0]
        image_dict['width'] = image_shape[1]
        return [image_dict]


class BoxPredictor(BasePredictor):
    def __init__(self, cfg_file, model_file):
        super(BoxPredictor, self).__init__(cfg_file, model_file)
        pass

    def __call__(self, image_list):
        res = super().__call__(image_list)
        # 模型推理的结果为字典形式，这里将解析成后续期望的数据形式
        if not isinstance(res, list):  # 如果处理单张图片时，该处的返回值不为列表
            res = [res]
        res_list = []
        for each_dict in res:
            if isinstance(each_dict['instances'], list):
                current_res_dict = each_dict['instances'][0].get_fields()
            else:
                current_res_dict = each_dict['instances'].get_fields()
            current_boxes = current_res_dict['pred_boxes'].tensor.cpu().detach().numpy().astype(int)
            current_scores = current_res_dict['scores'].cpu().detach().numpy()
            current_classes = current_res_dict['pred_classes'].cpu().detach().numpy()
            res_list.append([current_boxes, current_scores, current_classes])

        return res_list


class MaskPredictor(BasePredictor):
    def __init__(self, cfg_file, model_file):
        """
        该模型将会适用于语义分割网络和变化检测网络
        :param cfg_file:
        :param model_file:
        """
        super(MaskPredictor, self).__init__(cfg_file, model_file)
        pass

    def __call__(self, image_list):
        res = super().__call__(image_list)
        # 模型推理的结果为多个字典组成的列表，这里将解析成后续期望的数据形式
        if not isinstance(res, list):  # 如果处理单张图片时，该处的返回值不为列表
            res = [res]
        res_list = []
        for each_dict in res:
            if 'sem_seg' in each_dict:
                current_res = each_dict['sem_seg']
            else:
                current_res = each_dict['change_detection']
            result = current_res.argmax(0)
            current_res = result.cpu().numpy() * 255
            # current_res = F.softmax(current_res, dim=0)[1] * 255
            # current_res = torch.round(current_res)
            # current_res = current_res.cpu().detach().numpy().astype(np.uint8)  # 转到CPU中处理
            # _, current_res = cv2.threshold(current_res, 127, 255, cv2.THRESH_BINARY)
            res_list.append(current_res)

        return res_list


class ObjectDetection(BoxPredictor):
    def __init__(self, cfg_file, model_file):
        super(ObjectDetection, self).__init__(cfg_file, model_file)

    def inference(self, image_path, output_path):
        """
        开始推理单张数据
        :param image_path: 单张图片路径
        :param output_path: 可视化结果图片的输出路径
        :return:
        """
        out_image = cv2.imread(image_path)
        input_image = self.read_single_data(image_path)
        image_res = super().__call__(input_image)
        # 依次进行画图
        for box, score, t in zip(image_res[0][0], image_res[0][1], image_res[0][2]):
            left, up, right, down = box
            out_image = cv2.rectangle(out_image, (left, up), (right, down), (0, 255, 0), 2)
        cv2.imwrite(output_path, out_image)
        print('推理完成')


class SemSeg(MaskPredictor):
    def __init__(self, cfg_file, model_file):
        super(SemSeg, self).__init__(cfg_file, model_file)

    def inference(self, image_path, output_path):
        """
        开始推理单张数据
        :param image_path: 单张图片路径
        :param output_path: 可视化结果图片的输出路径
        :return:
        """
        input_image = self.read_single_data(image_path)
        image_res = super().__call__(input_image)
        cv2.imwrite(output_path, image_res[0])
        print('推理完成')


class ChangeDetection(MaskPredictor):
    def __init__(self, cfg_file, model_file):
        super(ChangeDetection, self).__init__(cfg_file, model_file)

    def inference(self, pre_path, post_path, output_path):
        """
        开始推理单张数据
        :param pre_path: 单张前景切片影像的路径
        :param post_path: 单张后景切片影像的路径
        :param output_path: 可视化结果图片的输出路径
        :return:
        """
        input_image = self.read_change_single_data(pre_path, post_path)
        image_res = super().__call__(input_image)
        cv2.imwrite(output_path, image_res[0])
        print('推理完成')

    def read_change_single_data(self, pre_path, post_path):
        """
        将数据打包成变化检测模型需要的格式
        :param pre_path: 单张前景切片影像的路径
        :param post_path: 单张后景切片影像的路径
        :return:
        """
        pre_image = cv2.imread(pre_path)
        post_image = cv2.imread(post_path)
        if self.image_format == "RGB":
            pre_image = cv2.cvtColor(pre_image, cv2.COLOR_BGR2RGB)
            post_image = cv2.cvtColor(post_image, cv2.COLOR_BGR2RGB)
        pre_image_shape = pre_image.shape
        post_image_shape = post_image.shape
        if len(pre_image_shape) != 3 or len(post_image_shape) != 3:
            print('目前只支持3通道图片')
            exit()
        image_dict = dict()
        image_dict['pre_image'] = torch.tensor(pre_image.transpose(2, 0, 1))
        image_dict['post_image'] = torch.tensor(post_image.transpose(2, 0, 1))
        return [image_dict]


if __name__ == '__main__':
    # ###################################################################################
    # #############################   目标检测测试   ######################################
    # ###################################################################################
    config_path = '/code/aigislib/model_zoo/object_detection/anchor_free.yaml'
    model_path = '/code/export/model_0039999.pth'
    obj = ObjectDetection(config_path, model_path)
    test_path = '/code/data/oil_well/val/4195.0-419.0_139_2379.tif'
    out_path = '/code/export/1003.jpg'
    obj.inference(test_path, out_path)

    # ###################################################################################
    # ##############################    语义分割测试    ###################################
    # ###################################################################################
    # config_path = '/code/aigislib/model_zoo/semantic_segmentation/agriculture_segmentation.yaml'
    # model_path = '/code/model/agri_bifpn.pth'
    # obj = SemSeg(config_path, model_path)
    # test_path = '/code/data/10005clip.tif'
    # out_path = '/code/export/10005_.jpg'
    # obj.inference(test_path, out_path)

    # ###################################################################################
    # ################################   变化检测测试   ###################################
    # ###################################################################################
    # config_path = '/code/aigislib/model_zoo/change_detection/siameseFPN_new.yaml'
    # model_path = '/code/model/change.pth'
    # obj = ChangeDetection(config_path, model_path)
    # pre_test_path = '/code/data/jiaxiang_area_0_25_13.jpg'
    # post_test_path = '/code/data/jiaxiang_area_5_14_13.jpg'
    # out_path = '/code/export/513.jpg'
    # obj.inference(pre_test_path, post_test_path, out_path)
