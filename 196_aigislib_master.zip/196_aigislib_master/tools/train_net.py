
import sys
import pathlib
import weakref
import torch
import logging
from collections import OrderedDict

import detectron2.utils.comm as comm
from detectron2.utils.events import EventStorage
from detectron2.utils.logger import setup_logger
from detectron2.engine import DefaultTrainer, SimpleTrainer, AMPTrainer, create_ddp_model, TrainerBase
from detectron2.engine import default_argument_parser, default_setup, launch
from detectron2.solver import get_default_optimizer_params
from detectron2.solver.build import maybe_add_gradient_clipping
from detectron2.evaluation import DatasetEvaluator, print_csv_format, verify_results, inference_on_dataset
from detectron2.checkpoint import DetectionCheckpointer

cwd_path = pathlib.Path(__file__).absolute()
parent_path = cwd_path.parent.parent.parent.as_posix()
sys.path.append(parent_path)

from aigislib.data.dataloader import build_train_loader, build_test_loader
from aigislib.config import get_cfg
from aigislib.evaluation.builder import build_evaluator
from aigislib.utils.build_solver import build_lr_scheduler


class Trainer(DefaultTrainer):
    """ 该类继承DefaultTrainer, 包含预定义的训练流程 """
    def __init__(self, cfg):
        """
        Args:
            cfg (CfgNode):
        """
        TrainerBase.__init__(self)
        logger = logging.getLogger("detectron2")
        if not logger.isEnabledFor(logging.INFO):  # setup_logger is not called for d2
            setup_logger()
        cfg = DefaultTrainer.auto_scale_workers(cfg, comm.get_world_size())

        # Assume these objects must be constructed in this order.
        model = self.build_model(cfg)
        optimizer = self.build_optimizer(cfg, model)
        data_loader = self.build_train_loader(cfg)

        model = create_ddp_model(model, broadcast_buffers=False, find_unused_parameters=True)
        self._trainer = (AMPTrainer if cfg.SOLVER.AMP.ENABLED else SimpleTrainer)(
            model, data_loader, optimizer
        )

        self.scheduler = self.build_lr_scheduler(cfg, optimizer)
        self.checkpointer = DetectionCheckpointer(
            # Assume you want to save checkpoints together with logs/statistics
            model,
            cfg.OUTPUT_DIR,
            trainer=weakref.proxy(self),
        )
        self.start_iter = 0
        self.max_iter = cfg.SOLVER.MAX_ITER
        self.cfg = cfg

        self.register_hooks(self.build_hooks())

    def build_hooks(self):
        ret_hooks = super().build_hooks()
        cfg = self.cfg.clone()
        task_id = cfg.TASK_ID
        if task_id != 0:
            from aigislib.engine.extend_hooks import TaskDBHook
            # if comm.is_main_process():
            t_hook = TaskDBHook(cfg.OUTPUT_DIR, self.checkpointer, task_id)
            # ret_hooks.insert(-2,t_hook)
            ret_hooks.append(t_hook)
        return ret_hooks

    @classmethod
    def build_train_loader(cls, cfg):
        """
        cfg: 配置文件
        return:
            iterable
        """
        return build_train_loader(cfg)

    @classmethod
    def build_test_loader(cls, cfg, dataset_name):
        """
        cfg: 配置文件
        dataset_name: 测试数据库名
        return:
            iterable
        """
        return build_test_loader(cfg, dataset_name)

    @classmethod
    def build_evaluator(cls, cfg, evaluator_name, dataset_name):
        """
        cfg: 配置文件
        dataset_name: 测试数据库名
        Returns:
            DatasetEvaluator or None
        """
        return build_evaluator(cfg, evaluator_name, dataset_name)

    @classmethod
    def build_optimizer(cls, cfg, model):
        """ 定义优化器 """
        params = get_default_optimizer_params(
            model,
            weight_decay=cfg.SOLVER.WEIGHT_DECAY,
            weight_decay_norm=cfg.SOLVER.WEIGHT_DECAY_NORM,
            bias_lr_factor=cfg.SOLVER.BIAS_LR_FACTOR,
            weight_decay_bias=cfg.SOLVER.WEIGHT_DECAY_BIAS,
        )
        optimizer_type = cfg.SOLVER.OPTIMIZER
        if optimizer_type == "sgd":
            return maybe_add_gradient_clipping(cfg, torch.optim.SGD)(
                params,
                cfg.SOLVER.BASE_LR,
                momentum=cfg.SOLVER.MOMENTUM,
                nesterov=cfg.SOLVER.NESTEROV,
                weight_decay=cfg.SOLVER.WEIGHT_DECAY,
            )
        elif optimizer_type == "adam":
            return maybe_add_gradient_clipping(cfg, torch.optim.Adam)(
                params,
                cfg.SOLVER.BASE_LR,
                weight_decay=cfg.SOLVER.WEIGHT_DECAY,
            )
        else:
            raise NotImplementedError(f"no optimizer type: {optimizer_type}")

    @classmethod
    def build_lr_scheduler(cls, cfg, optimizer):
        """
        定义学习率更新策略
        """
        return build_lr_scheduler(cfg, optimizer)

    @classmethod
    def test(cls, cfg, model, evaluators=None):
        """
        Args:
            cfg (CfgNode):
            model (nn.Module):
            evaluators (list[DatasetEvaluator] or None): if None, will call
                :meth:`build_evaluator`. Otherwise, must have the same length as
                ``cfg.DATASETS.TEST``.
        Returns:
            dict: a dict of result metrics
        """
        logger = logging.getLogger(__name__)
        # 重载test方法，需要evaluators为None，在配置文件里面定义该方法
        assert evaluators is None

        results = OrderedDict()
        for idx, dataset_item in enumerate(cfg.DATASETS.TEST):
            dataset_name, parse_name, data_path = dataset_item
            data_loader = cls.build_test_loader(cfg, dataset_name)

            # When evaluators are passed in as arguments,
            # implicitly assume that evaluators can be created before data_loader.
            try:
                evaluator_name = cfg.DATASETS.EVALUATOR
                evaluator = cls.build_evaluator(cfg, evaluator_name, dataset_name)
            except NotImplementedError:
                logger.warning(
                    "No evaluator found. Use `DefaultTrainer.test(evaluators=)`, "
                    "or implement its `build_evaluator` method."
                )
                results[dataset_name] = {}
                continue
            results_i = inference_on_dataset(model, data_loader, evaluator)
            results[dataset_name] = results_i
            if comm.is_main_process():
                assert isinstance(
                    results_i, dict
                ), "Evaluator must return a dict on the main process. Got {} instead.".format(
                    results_i
                )
                logger.info("Evaluation results for {} in csv format:".format(dataset_name))
                print_csv_format(OrderedDict(results_i))

        if len(results) == 1:
            results = list(results.values())[0]
        return results

    def train(self):
        logger = logging.getLogger(__name__)
        logger.info("Starting training from iteration {}".format(self.start_iter))

        self.iter = self.start_iter

        with EventStorage(self.start_iter) as self.storage:
            try:
                self.before_train()
                for self.iter in range(self.start_iter, self.max_iter):
                    self.before_step()
                    self.run_step()
                    self.after_step()
                # self.iter == max_iter can be used by `after_train` to
                # tell whether the training successfully finished or failed
                # due to exceptions.
                self.iter += 1
            except Exception:
                logger.exception("Exception during training:")
                # raise
            finally:
                self.after_train()
        # if len(self.cfg.TEST.EXPECTED_RESULTS) and comm.is_main_process():
        #     assert hasattr(
        #         self, "_last_eval_results"
        #     ), "No evaluation results obtained during training!"
        #     verify_results(self.cfg, self._last_eval_results)
        #     return self._last_eval_results

    def after_train(self):
        if self.cfg.EXPORT.ENABLE:
            from aigislib.tools.export_model import ModelExporter
            exporter = ModelExporter(self.model, cfg=self.cfg)
            exporter.export_from_cfg()
        super().after_train()
        

def setup(args):
    """
    Create config
    """
    cfg = get_cfg()
    cfg.merge_from_file(args.config_file)
    # cfg.TASK_ID = 898
    cfg.merge_from_list(args.opts)
    cfg.freeze()
    default_setup(cfg, args)

    return cfg


def main(args):
    cfg = setup(args)

    # 评估网络
    print("cfg: ", args.eval_only)
    if args.eval_only:
        model = Trainer.build_model(cfg)
        DetectionCheckpointer(model, save_dir=cfg.OUTPUT_DIR).resume_or_load(
            cfg.MODEL.WEIGHTS, resume=args.resume
        )
        res = Trainer.test(cfg, model)  # d2 defaults.py
        if comm.is_main_process():
            verify_results(cfg, res)
        return res

    # 训练网络
    logger = logging.getLogger(__name__)
    logger.info("@@@ START JOB!")
    print("@@@ START JOB!")
    trainner = Trainer(cfg)
    trainner.resume_or_load(resume=args.resume)
    # exit(0)
    return trainner.train()


if __name__ == '__main__':
    args = default_argument_parser().parse_args()
    args.config_file = '/code/aigislib/model_zoo/object_detection/new_oil_well.yaml'
    # 启动训练
    launch(
        main,
        args.num_gpus,
        num_machines=args.num_machines,
        machine_rank=args.machine_rank,
        dist_url=args.dist_url,
        args=(args,),
    )
