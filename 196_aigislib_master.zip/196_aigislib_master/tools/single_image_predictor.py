
"""
!!!注意！！！
如果要执行该脚本，需要将rs_utils库放置在aigislib库的同级目录中
"""
from cmd_tool.infer_library.inference_work import MaskInference, ChangeInference, BoxInference


def single_image_inference(task_type, resolution,
                           input_path, output_path, model_file, config_file,
                           crop_height, crop_width, step_height, step_width,
                           post_process_crop_height, post_process_crop_width,
                           post_process_step_height, post_process_step_width,
                           add_post_process, process_num, batch_size):
    """
    处理单张影像
    :param task_type: 任务类型（变化检测、语义分割、目标检测）
    :param resolution: 影像分辨率
    :param input_path: 输入影像路径
    :param output_path: 输出矢量路径
    :param model_file: 模型文件路径
    :param config_file: 配置文件路径
    :param crop_height: 推理阶段切片的高（单位为像素）
    :param crop_width: 推理阶段切片的宽（单位为像素）
    :param step_height: 推理阶段切片步长的高（单位为像素）
    :param step_width: 推理阶段切片步长的宽（单位为像素）
    :param post_process_crop_height: 后处理阶段切片的高（单位为像素）
    :param post_process_crop_width: 后处理阶段切片的宽（单位为像素）
    :param post_process_step_height: 后处理阶段切片步长的高（单位为像素）
    :param post_process_step_width: 后处理阶段切片步长的宽（单位为像素）
    :param add_post_process: 是否添加后处理
    :param process_num: 切片所需的进程数
    :param batch_size: 模型一次处理的图片数量
    :return:
    """
    # TODO: 需要考虑切片大小及步长大于原始影响的情况
    if task_type == 1:  # 语义分割
        ss_obj = MaskInference(model_file, config_file, input_path, output_path,
                               crop_height, crop_width, step_height, step_width,
                               post_process_crop_height, post_process_crop_width,
                               post_process_step_height, post_process_step_width,
                               resolution, add_post_process,
                               process_num=process_num, batch_size=batch_size, mask_on=True)
    elif task_type == 2:  # 变化检测
        ss_obj = ChangeInference(model_file, config_file, input_path, output_path,
                                 crop_height, crop_width, step_height, step_width,
                                 post_process_crop_height, post_process_crop_width,
                                 post_process_step_height, post_process_step_width,
                                 resolution, add_post_process,
                                 process_num=process_num, batch_size=batch_size, mask_on=True)
    else:  # 目标检测
        ss_obj = BoxInference(model_file, config_file, input_path, output_path,
                              crop_height, crop_width, step_height, step_width,
                              post_process_crop_height, post_process_crop_width,
                              post_process_step_height, post_process_step_width,
                              resolution, add_post_process,
                              process_num=process_num, batch_size=batch_size, mask_on=False)
    # 开始处理，如果出现了异常错误，需要杀掉相关进程
    try:
        ss_obj()
    except Exception as e:
        ss_obj.infer_slide_obj.loc_process.clear()
        ss_obj.infer_slide_obj.img_process.clear()
        if add_post_process == 1:
            ss_obj.post_slide_obj.loc_process.clear()
            ss_obj.post_slide_obj.img_process.clear()
        print('推理过程中出现错误： ', e)


if __name__ == '__main__':
    # 推理任务类型：1:语义分割  2:变化检测  3:目标检测
    infer_task_type = 1
    # 期望推理影像的分辨率
    img_resolution = 1
    # 待处理影像的路径，注意：这里的参数必须要以列表的形式存在，如果为变化检测，则列表分别包含前后时像的路径，其他则为单张影像的路径
    input_img_path = ['/code/data/area02_6.tif']
    # 输出结果的路径
    output_res_path = '/code/out/area_02_6.shp'
    # 模型路径
    model_file_path = '/code/agriculture/model_final.pth'
    # 配置文件路径
    config_file_path = '/code/ai-cmd-tools/aigislib/model_zoo/semantic_segmentation/agriculture_segmentation.yaml'
    # 获取切片的进程数
    crop_process_num = 2
    # 模型一次推理的图片数量
    batch_sizes = 1
    # 切片的高（单位为像素）
    crop_h = 512
    # 切片的宽（单位为像素）
    crop_w = 512
    # 切片的步长高（单位为像素）
    step_h = 400
    # 切片的步长宽（单位为像素）
    step_w = 400
    # 是否添加后处理：1代表添加，2代表不添加（如果选择2，则下面的4个参数就没有意义了）
    post_process_addition = 1
    # 后处理时切片的高（单位为像素）
    post_process_crop_h = 3000
    # 后处理时切片的宽（单位为像素）
    post_process_crop_w = 3000
    # 后处理时切片步长的高（单位为像素）
    post_process_step_h = 2500
    # 后处理时切片步长的宽（单位为像素）
    post_process_step_w = 2500

    # 为了避免输入路径可能会导致的错误，这里进行该参数的校验
    if not isinstance(input_img_path, list):
        print('请重新检查参数input_img_path， 该参数必须要以列表的形式存在')
        exit()
    single_image_inference(infer_task_type, img_resolution,
                           input_img_path, output_res_path, model_file_path, config_file_path,
                           crop_h, crop_w, step_h, step_w,
                           post_process_crop_h, post_process_crop_w,
                           post_process_step_h, post_process_step_w,
                           post_process_addition, crop_process_num, batch_sizes)
