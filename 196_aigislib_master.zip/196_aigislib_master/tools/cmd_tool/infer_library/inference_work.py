
"""
推理的基本类
"""
import torch
import numpy as np
from functools import partial
from affine import Affine
import sys
import pathlib
cwd_path = pathlib.Path(__file__).absolute()
parent_path = cwd_path.parent.parent.parent.parent.parent.as_posix()
sys.path.append(parent_path)
from rs_utils.rasters.raster import RasterData
from .produce_crop_image import SlideWindow
from .merge import MaskMerge, BoxMerge
from .post_process import watershed, nms
from .model import MaskPredictor, BoxPredictor


class BaseInference(object):
    def __init__(self,
                 images_path,
                 config_file,
                 model_file,
                 crop_rows,
                 crop_cols,
                 step_rows,
                 step_cols,
                 post_crop_height,
                 post_crop_width,
                 post_step_height,
                 post_step_width,
                 resolution,
                 add_post_process,
                 process_num,
                 batch_size,
                 mask_on=False
                 ):
        """
        遥感影像推理的基础类
        :param images_path: 待处理影像的路径，以列表形式存放，可能有一张或两张（变化检测）
        :param crop_rows: 切片的高（像素）
        :param crop_cols: 切片的宽（像素）
        :param step_rows: 切片的竖直步长（像素）
        :param step_cols: 切片的水平步长（像素）
        :param post_crop_height: 后处理的切片的高（像素）
        :param post_crop_width: 后处理切片的宽（像素）
        :param post_step_height: 后处理切片步长的高（像素）
        :param post_step_width: 后处理的切片步长的宽（像素）
        :param resolution: 期望分辨率
        :param add_post_process: 是否删除后处理
        :param process_num: 进程数量，即多个进程并行获取图片
        :param batch_size: 批量抓取的切片数量
        :param mask_on: 是否获取权重矩阵，对于语义分割相关的任务类型有用
        """
        self.images_path = images_path
        self.config_file = config_file
        self.model_file = model_file
        self.crop_rows = crop_rows
        self.crop_cols = crop_cols
        self.step_rows = step_rows
        self.step_cols = step_cols
        self.post_crop_height = post_crop_height
        self.post_crop_width = post_crop_width
        self.post_step_height = post_step_height
        self.post_step_width = post_step_width
        self.resolution = resolution
        self.add_post_process = add_post_process
        self.process_num = process_num
        self.mask_on = mask_on
        self.batch_size = batch_size
        # 读取影像
        self.image_list = [RasterData.build_file(img_path) for img_path in images_path]
        self.space_extent = self.get_extent()                  # 待处理影像的地理范围
        # self.space_extent = space_extent
        self.pixel_size = self.get_image_pixel_size()     # 待处理影像的像素尺寸
        self.crs_kwt, self.dst_transform = self.parse_vector_property()
        self.post_process_obj = self.post_process_func()  # 后处理对象
        self.merge_obj = self.get_merge_obj()
        self.model_obj = self.get_model_obj()             # 模型处理对象
        # 推理的滑窗对象
        self.infer_slide_obj = None
        self.post_slide_obj = None
        self.image_format = self.model_obj.cfg.INPUT.FORMAT

    def __call__(self, *args, **kwargs):
        import time
        time0 = time.time()
        # 滑窗推理
        model_result = self.slide_infer()
        if self.add_post_process == 1:
            # 后处理
            self.post_pro(model_result)
        # 赋值给合并对象以坐标参考系和窗口分辨率
        self.merge_obj.set_coordinate_system(self.crs_kwt)
        self.merge_obj.set_transform(self.dst_transform)
        if self.add_post_process == 1:
            # 将后处理结果矢量化并将矢量数据进行保存，传参的作用是提示矢量文件的阈值化参数
            self.merge_obj.save_shp_file(0)  # ++++++++++
        else:
            self.merge_obj.save_shp_file(127)
        print('时间消耗为：', time.time() - time0)

    def get_model_obj(self):
        raise NotImplementedError

    def post_process_func(self):
        raise NotImplementedError

    def get_merge_obj(self):
        raise NotImplementedError

    def post_pro(self, model_res):
        """
        滑窗后处理，获得整个影像的矢量结果
        :param model_res: 模型处理结果
        :return:
        """
        # 将模型结果缓冲到内存中
        # time0 = time.time()
        mmap = np.memmap('mymmap', dtype='uint8', mode='w+', shape=(self.pixel_size[0], self.pixel_size[1]))
        mmap[:] = model_res
        mmap.flush()
        # 确保图片完全缓冲到内存中
        mmap = np.memmap('mymmap', dtype='uint8', mode='r', shape=(self.pixel_size[0], self.pixel_size[1]))
        # print('缓冲时间为：', time.time() - time0)
        # 更新拼接的空白矩阵
        self.merge_obj.dst_data = np.zeros((self.pixel_size[0], self.pixel_size[1]), dtype=np.uint8)
        # 后处理的滑窗对象启动
        self.post_slide_obj.flag_queue.put(1)
        flag = 0
        while True:
            # time2 = time.time()
            if flag > 0:
                break
            # 获取一批推理数据
            image_data_obj_list = self.post_slide_obj.batch_data()
            # print('取图片的时间为：', time.time() - time2)
            if len(image_data_obj_list) < self.batch_size:
                # 如果进入这里就表示这是最后一次推理了
                flag += 1
            # 将模型推理结果进行拆分，并将结果赋值给每个对象，以及数据拼接
            for index, data_obj in enumerate(image_data_obj_list):
                pixel_loc = data_obj.pixel_location
                current_model_res = mmap[pixel_loc[1]:pixel_loc[3], pixel_loc[0]:pixel_loc[2]]
                post_process_result = self.post_process_obj(data_obj, current_model_res)  # ++++++
                data_obj.set_res(post_process_result)
                self.merge_obj(data_obj, use_weight=False)
                # data_obj = None
        self.post_slide_obj = None

    def slide_infer(self):
        """
        滑窗推理，获得整个影像的推理结果
        :return:
        """
        # 推理的滑窗对象启动
        self.infer_slide_obj.flag_queue.put(1)
        flag = 0
        while True:
            if flag > 0:
                break
            # 获取一批推理数据
            image_data_obj_list = self.infer_slide_obj.batch_data()  # +++++++++++
            current_batch_num = len(image_data_obj_list)  # 当前批次的数量，可能为零个或多个
            if current_batch_num == 0:  # 如果为零个则直接跳出循环
                break
            if current_batch_num < self.batch_size:
                # 如果进入这里就表示这是最后一次推理了
                flag += 1
            # 将该批推理数据中的图片进行合并
            joint_data = self.batch_crop_img(image_data_obj_list)
            # 模型推理，模型输出结果为列表，每个元素代表每个输入图片的结果
            res = self.model_obj(joint_data)  # +++++++++
            # 将模型推理结果进行拆分，并将结果赋值给每个对象，最后进行拼接
            for index, data_obj in enumerate(image_data_obj_list):
                data_obj.set_res(res[index])
                self.merge_obj(data_obj)  # ++++++递增
        model_result = self.merge_obj.dst_data
        self.infer_slide_obj = None
        return model_result

    def batch_crop_img(self, batch_data_list):
        """
        将列表中的数据打包成一个batch，便于模型批量处理
        :param batch_data_list: data_package对象组成的列表
        :return:
        """
        # 每个对象都需要打包到一个字典中
        joint_data_list = [
            {'image': torch.as_tensor(np.ascontiguousarray(obj.image_list[0])),
             'height': self.crop_rows,
             'width': self.crop_cols}
            for obj in batch_data_list
        ]
        del batch_data_list
        return joint_data_list

    def get_extent(self):
        """
        确定影像的空间坐标范围
        :return:
        """
        # 获取影像的数量，如果为1则为直接获取空间范围，如果为2则需要求解空间交集范围
        img_len = len(self.image_list)
        assert 0 < img_len < 3, '请检查影像路径，可能存在路径错误或多余路径'
        if img_len == 1:
            extent_one = self.image_list[0].region
            return extent_one[0], extent_one[1], extent_one[2], extent_one[3]
        else:
            extent_one = self.image_list[0].region
            extent_two = self.image_list[1].region
            if extent_one[0] >= extent_two[2] or extent_two[0] >= extent_one[2] \
                    or extent_one[1] >= extent_two[3] or extent_two[1] >= extent_one[3]:
                msg = "前后时相坐标系不一致或无重叠区域，请统一坐标系，并确保有重叠区域"
                return False, msg
            # 计算重叠范围
            overlap_x_min = extent_one[0] if extent_one[0] >= extent_two[0] else extent_two[0]
            overlap_y_min = extent_one[1] if extent_one[1] >= extent_two[1] else extent_two[1]
            overlap_x_max = extent_one[2] if extent_one[2] <= extent_two[2] else extent_two[2]
            overlap_y_max = extent_one[3] if extent_one[3] <= extent_two[3] else extent_two[3]
            return overlap_x_min, overlap_y_min, overlap_x_max, overlap_y_max

    def get_image_pixel_size(self):
        """
        获取原始影像的待处理范围的像素尺寸
        :return:
        """
        extent_x_min, extent_y_min, extent_x_max, extent_y_max = self.space_extent
        im_width = extent_x_max - extent_x_min  # 影像的宽（米）
        im_height = extent_y_max - extent_y_min  # 影像的高（米）
        im_pixel_width = round(im_width / self.resolution)  # 影像的宽（像素）
        im_pixel_height = round(im_height / self.resolution)  # 影像的宽（像素）
        return im_pixel_height, im_pixel_width

    def parse_vector_property(self):
        """
        解析矢量数据保存需要的窗口分辨率和坐标系等信息
        :return:
        """
        extent_x_min, extent_y_min, extent_x_max, extent_y_max = self.space_extent
        # 根据影像的空间范围来获取整体影像的窗口
        window = self.image_list[0].cur_handle.window(extent_x_min, extent_y_min, extent_x_max, extent_y_max)
        dst_transform = self.image_list[0].cur_handle.window_transform(window)
        # 调整影像分辨率
        scaling = Affine.scale(abs(self.resolution / dst_transform.a), abs(self.resolution / dst_transform.e))
        dst_transform *= scaling
        # 坐标参考系
        crs_kwt = self.image_list[0].crs

        return crs_kwt, dst_transform


class MaskInference(BaseInference):
    def __init__(self,
                 model_file,
                 config_file,
                 images_path,
                 output_shp_path,
                 crop_rows,
                 crop_cols,
                 step_rows,
                 step_cols,
                 post_crop_height,
                 post_crop_width,
                 post_step_height,
                 post_step_width,
                 resolution,
                 add_post_process,
                 process_num,
                 batch_size,
                 mask_on=True
                 ):
        self.output_shp_path = output_shp_path
        super(MaskInference, self).__init__(images_path, config_file, model_file,
                                            crop_rows, crop_cols, step_rows, step_cols,
                                            post_crop_height, post_crop_width, post_step_height, post_step_width,
                                            resolution, add_post_process,
                                            process_num, batch_size, mask_on)
        # 滑窗对象
        self.infer_slide_obj = SlideWindow(images_path, self.space_extent,
                                           crop_rows, crop_cols, step_rows, step_cols,
                                           resolution, process_num, batch_size, self.image_format, mask_on)
        if self.add_post_process == 1:
            self.post_slide_obj = SlideWindow(images_path, self.space_extent,
                                              post_crop_height, post_crop_width, post_step_height, post_step_width,
                                              resolution, process_num, batch_size, self.image_format, mask_on)

    def get_model_obj(self):
        """
        模型对象
        :return:
        """
        return MaskPredictor(self.config_file, self.model_file)

    def post_process_func(self):
        """
        后处理对象
        :return:
        """
        return partial(watershed, fg_threshold=127, bg_threshold=8)

    def get_merge_obj(self):
        """
        切片推理结果拼接对象
        :return:
        """
        # 影像的像素尺寸
        height, width = self.pixel_size
        return MaskMerge(self.output_shp_path, height, width, self.crop_rows, self.crop_cols)


class BoxInference(BaseInference):
    def __init__(self,
                 model_file,
                 config_file,
                 images_path,
                 output_shp_path,
                 crop_rows,
                 crop_cols,
                 step_rows,
                 step_cols,
                 post_crop_height,
                 post_crop_width,
                 post_step_height,
                 post_step_width,
                 resolution,
                 add_post_process,
                 process_num,
                 batch_size,
                 mask_on=True
                 ):
        self.output_shp_path = output_shp_path
        super(BoxInference, self).__init__(images_path, config_file, model_file,
                                           crop_rows, crop_cols, step_rows, step_cols,
                                           post_crop_height, post_crop_width, post_step_height, post_step_width,
                                           resolution, add_post_process,
                                           process_num, batch_size, mask_on)
        # 滑窗对象
        self.infer_slide_obj = SlideWindow(images_path, self.space_extent,
                                           crop_rows, crop_cols, step_rows, step_cols,
                                           resolution, process_num, batch_size, self.image_format, mask_on)

    def get_model_obj(self):
        """
        模型对象
        :return:
        """
        return BoxPredictor(self.config_file, self.model_file)

    def post_process_func(self):
        """
        后处理对象
        :return:
        """
        return partial(nms, iou_thresh=0.4)

    def get_merge_obj(self):
        """
        切片推理的边框信息进行合并
        :return:
        """
        return BoxMerge(self.output_shp_path)

    def post_pro(self, model_res):
        """
        边框检测的后处理，不同于语义相关的后处理类型，所以需要进行重写
        :param model_res: 模型滑窗推理得到的所有边框，其实这里不需要进行传参，只是为了统一接口
        :return:
        """
        # 对所有同一类别边框进行后处理（非极大值抑制等），获得最终的边框信息
        model_res = self.post_process_obj(None, model_res)
        # print(model_res)
        # 更新原始数据
        # self.merge_obj.dst_data *= 0
        # self.merge_obj.update_dst_data(model_res)
        self.merge_obj.dst_data = model_res
        # 赋值坐标参考系和窗口分辨率
        self.merge_obj.set_coordinate_system(self.crs_kwt)
        self.merge_obj.set_transform(self.dst_transform)
        # 将后处理结果矢量化并将矢量数据进行保存
        self.merge_obj.save_shp_file(None)


class ChangeInference(MaskInference):
    def __init__(self,
                 model_file,
                 config_file,
                 images_path,
                 output_shp_path,
                 crop_rows,
                 crop_cols,
                 step_rows,
                 step_cols,
                 post_crop_height,
                 post_crop_width,
                 post_step_height,
                 post_step_width,
                 resolution,
                 add_post_process,
                 process_num,
                 batch_size,
                 mask_on=True
                 ):
        super(ChangeInference, self).__init__(model_file, config_file, images_path, output_shp_path,
                                              crop_rows, crop_cols, step_rows, step_cols,
                                              post_crop_height, post_crop_width, post_step_height, post_step_width,
                                              resolution, add_post_process,
                                              process_num, batch_size, mask_on)

    def batch_crop_img(self, batch_data_list):
        """
        变化检测不同于语义分割，输入模型时需要两个关键字，前时像和后时像
        :param batch_data_list:
        :return:
        """
        joint_data_list = [
            {
                'pre_image': torch.as_tensor(np.ascontiguousarray(obj.image_list[0])),
                'post_image': torch.as_tensor(np.ascontiguousarray(obj.image_list[1])),
                'height': self.crop_rows,
                'width': self.crop_cols
             }
            for obj in batch_data_list
        ]

        return joint_data_list
