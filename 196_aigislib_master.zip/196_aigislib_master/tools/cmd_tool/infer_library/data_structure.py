
"""
定义数据的接口
"""


class DataPackage(object):
    def __init__(self,
                 image_list=None,
                 pixel_location=None,
                 geo_location=None,
                 process_res=None,
                 margin=None):
        """
        定义数据接口
        :param image_list: 切片影像数据，以列表的形式存放，可能是一张也可能是多张（变化检测）
        :param pixel_location: 切片结果期望存放的像素坐标位置
        :param geo_location: 切片的地理坐标位置
        :param process_res: 切片处理结果数据
        """
        self.image_list = image_list
        self.pixel_location = pixel_location
        self.geo_location = geo_location
        self.process_res = process_res
        self.margin = margin

    def set_image(self, image_list):
        self.image_list = image_list

    def set_pixel_location(self, pixel_location):
        self.pixel_location = pixel_location

    def set_geo_location(self, geo_location):
        self.geo_location = geo_location

    def set_res(self, res):
        self.process_res = res

    def set_margin(self, margin):
        self.margin = margin
