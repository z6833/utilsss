
"""
子进程管理
"""
from multiprocessing import Process


class MultiProcess(object):
    def __init__(self, num, func_obj, *args):
        """
        多进程的启动和关闭
        :param num: 启动的子进程数量
        :param func_obj: 子进程中待运行的函数对象
        :param args: 函数所需的参数
        """
        self.process_list = []
        for _ in range(num):
            c = Process(target=func_obj, args=args)
            self.process_list.append(c)

    def start(self):
        for c in self.process_list:
            c.start()

    def join(self):
        """
        等待子进程结束
        :return:
        """
        for c in self.process_list:
            c.join()

    def clear(self):
        """
        关闭并强制释放进程资源
        :return:
        """
        for c in self.process_list:
            c.kill()
        # sys.stdout.flush()  # 刷新以确保资源的释放


if __name__ == '__main__':
    pass
