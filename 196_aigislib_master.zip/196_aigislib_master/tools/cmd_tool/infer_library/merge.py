
"""
将模型推理结果进行拼接，进而获得整个影像的结果
"""

import fiona
import numpy as np
from rasterio import features
from collections import OrderedDict
from shapely.geometry import Polygon, mapping
from .weight_matrix import WeightMatrix


class Merge(object):
    def __init__(self,
                 output_shp_path,
                 dst_data=None,
                 coordinate_system=None,
                 window_transform=None):
        """
        将切片处理结果数据进行拼接，获得最终的结果
        :param dst_data: 切片结果拼接所在的空白矩阵或其他类型的数据
        :param coordinate_system: shp文件保存的坐标系
        :param window_transform: shp文件的窗口分辨率
        """
        self.dst_data = dst_data
        self.output_shp_path = output_shp_path
        self.coordinate_system = coordinate_system
        self.window_transform = window_transform

    def put(self, *args):
        """
        将data数据贴在self.dst_data数据中
        :return:
        """
        pass

    def __call__(self, data, use_weight=True):
        self.put(data, use_weight)

    def save_shp_file(self, thresh):
        """
        将结果图片进行阈值化，并对阈值化后的图片矢量化并保存
        Args:
            thresh: 阈值化参数
        Returns:
        """
        # 将结果矩阵进行阈值化处理
        import time
        time0 = time.time()
        if thresh == 0:
            self.dst_data[self.dst_data > thresh] = 1
        else:
            self.dst_data[self.dst_data <= thresh] = 0
            self.dst_data[self.dst_data > thresh] = 1
        print(self.dst_data.dtype, np.max(self.dst_data), np.min(self.dst_data))
        print('阈值化的时间为：', time.time() - time0)
        print(self.dst_data.shape)
        # 将阈值化后的掩码，转为矢量数据并保存
        self.label_to_shp_fiona()
        print('保存shp文件成功')

    def label_to_shp_fiona(self):
        """
        使用fiona将处理后的label转为shape file
        :return:
        """
        shapes = features.shapes(self.dst_data, transform=self.window_transform)
        records = list()
        for i, geometry in enumerate(shapes):
            if geometry[1] == 0:
                continue
            d = dict()
            d['type'] = "Feature"
            d['id'] = i
            d['properties'] = {"score": 1}
            d['geometry'] = geometry[0]
            records.append(d)
        with fiona.open(
                self.output_shp_path,
                'w',
                driver='ESRI Shapefile',
                crs_wkt=self.coordinate_system,
                schema={'geometry': 'Polygon', 'properties': OrderedDict([('score', 'int:9')])}
        ) as c:
            c.writerecords(records)

    def set_coordinate_system(self, coordinate_system):
        self.coordinate_system = coordinate_system

    def set_transform(self, window_transform):
        self.window_transform = window_transform


class MaskMerge(Merge):
    def __init__(self, output_shp_path, height, width, crop_height, crop_width):
        """
        掩码形式的拼接
        :param output_shp_path: 输出矢量的路径
        :param height: 原始影像的像素高
        :param width: 原始影像的像素宽
        :param crop_height: 切片的像素高
        :param crop_width: 切片的像素宽
        """
        super(MaskMerge, self).__init__(output_shp_path)
        self.dst_data = np.zeros((height, width), dtype=np.uint8)
        self.weight_matrix_obj = WeightMatrix(crop_height, crop_width)
        self.crop_height = crop_height
        self.crop_width = crop_width

    def put(self, data, use_weight):
        """
        切片结果矩阵与大的空白矩阵的融合
        :param data: 数据对象，包含权重矩阵、得分矩阵、像素位置
        :param use_weight: 是否需要权重矩阵，默认为True即需要
        :return:
        """
        pixel_loc = data.pixel_location
        score = data.process_res
        margin = data.margin
        if use_weight:
            matrix = self.weight_matrix_obj(margin[0], margin[1], margin[2], margin[3])  # +++++++偶尔会增加一点
        else:
            matrix = 1
        score_with_matrix = score * matrix
        score_with_matrix = score_with_matrix.astype(np.uint8)
        # +++++++下面在滑窗推理的时候会增加，但是后处理就不会
        # 如果出现切片尺寸大于原始影像尺寸时，就会出现像素的索引超出范围的情况（左侧或上侧可能会出现负数），这里需要进行对应处理
        if pixel_loc[0] < 0:
            score_with_matrix = score_with_matrix[:, -pixel_loc[0]:]
            pixel_loc[0] = 0
        if pixel_loc[1] < 0:
            score_with_matrix = score_with_matrix[-pixel_loc[1]:, :]
            pixel_loc[1] = 0
        self.dst_data[pixel_loc[1]:pixel_loc[3], pixel_loc[0]:pixel_loc[2]] += score_with_matrix


class BoxMerge(Merge):
    def __init__(self, output_shp_path):
        super(BoxMerge, self).__init__(output_shp_path)
        self.dst_data = np.array([[0, 0, 0, 0, 0]], dtype=np.float16)

    def put(self, data, use_weight):
        """
        切片检测边框结果与self.dst_data的融合
        :param data:
        :param use_weight: 这个参数没用
        :return:
        """
        pixel_loc = data.pixel_location
        boxes = data.process_res  # 当前切片推理的边框，多行五列的矩阵
        if len(boxes) == 0:
            pass
        else:
            # 将当前的位置映射到大的影像像素位置
            add_coordinate = [[pixel_loc[0], pixel_loc[1], pixel_loc[0], pixel_loc[1]]] * len(boxes)
            boxes[:, :4] += np.array(add_coordinate)
            # 将当前切片的边框信息并入dst_data中，便于后续统一处理
            self.dst_data = np.concatenate((self.dst_data, boxes), axis=0)

    def save_shp_file(self, thresh):
        print(self.dst_data.dtype, np.max(self.dst_data), np.min(self.dst_data))
        print(self.dst_data.shape)
        # 将阈值化后的掩码，转为矢量数据并保存
        self.label_to_shp_fiona()
        print('保存shp文件成功')

    def label_to_shp_fiona(self):
        """
        使用fiona将处理后的label转为shape file，基类中已经实现，因为有点偏差，需要进行重写
        :return:
        """
        # 定义shp矢量的类型
        schema = {'geometry': 'Polygon',
                  'properties': {'class': 'str', 'score': 'float', 'status': 'int'}}
        # 提取出地理范围
        records_list = list()
        for i, box in enumerate(self.dst_data[:, :4]):
            min_x, max_y = self.window_transform * (box[0], box[1])  # 左上角地理坐标
            max_x, min_y = self.window_transform * (box[2], box[3])  # 右下角地理坐标
            coordinate = [[min_x, max_y],
                          [min_x, min_y],
                          [max_x, min_y],
                          [max_x, max_y],
                          [min_x, max_y]]
            polygon = Polygon(coordinate)  # 使用地理坐标定义Polygon对象
            polygon = mapping(polygon)     # 将Polygon对象转为GeoJSON格式
            d = dict()
            d['type'] = "Feature"
            d['id'] = i
            d['properties'] = {'class': 1,
                               'score': float(self.dst_data[i, 4]),
                               'status': 0
                               }
            d['geometry'] = polygon
            records_list.append(d)
        with fiona.open(self.output_shp_path, 'w', driver='ESRI Shapefile',
                        crs_wkt=self.coordinate_system, schema=schema) as c:
            c.writerecords(records_list)
