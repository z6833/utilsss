import pathlib
import sys
cwd_path = pathlib.Path(__file__).absolute()
parent_path = cwd_path.parent.as_posix()
sys.path.append(parent_path)

import os
import argparse
from inference_work import MaskInference, ChangeInference, BoxInference
from about_csv import CSV
from detectron2.utils.logger import setup_logger


logger = setup_logger(name=__name__)


def each_image_copy(task_type, resolution,
                    input_path, output_path, model_file, config_file,
                    crop_height, crop_width, step_height, step_width,
                    post_process_crop_height, post_process_crop_width,
                    post_process_step_height, post_process_step_width,
                    remove_post_process_, image_format_):
    """
    处理单张影像
    :param task_type: 任务类型（变化检测、语义分割、目标检测）
    :param resolution: 影像分辨率
    :param input_path: 输入影像路径
    :param output_path: 输出矢量路径
    :param model_file: 模型文件路径
    :param config_file: 配置文件路径
    :param crop_height: 推理阶段切片的高（单位为像素）
    :param crop_width: 推理阶段切片的宽（单位为像素）
    :param step_height: 推理阶段切片步长的高（单位为像素）
    :param step_width: 推理阶段切片步长的宽（单位为像素）
    :param post_process_crop_height: 后处理阶段切片的高（单位为像素）
    :param post_process_crop_width: 后处理阶段切片的宽（单位为像素）
    :param post_process_step_height: 后处理阶段切片步长的高（单位为像素）
    :param post_process_step_width: 后处理阶段切片步长的宽（单位为像素）
    :param remove_post_process_: 是否删除后处理
    :param image_format_: 输入图片的格式
    :return:
    """
    # TODO: 需要考虑切片大小及步长大于原始影响的情况
    if task_type == 1:  # 语义分割
        ss_obj = MaskInference(model_file, config_file, input_path, output_path,
                               crop_height, crop_width, step_height, step_width,
                               post_process_crop_height, post_process_crop_width,
                               post_process_step_height, post_process_step_width,
                               resolution, remove_post_process_, image_format_,
                               process_num=4, batch_size=2, mask_on=True)
    elif task_type == 2:  # 变化检测
        ss_obj = ChangeInference(model_file, config_file, input_path, output_path,
                                 crop_height, crop_width, step_height, step_width,
                                 post_process_crop_height, post_process_crop_width,
                                 post_process_step_height, post_process_step_width,
                                 resolution, remove_post_process_, image_format_,
                                 process_num=4, batch_size=4, mask_on=True)
    else:  # 目标检测
        ss_obj = BoxInference(model_file, config_file, input_path, output_path,
                              crop_height, crop_width, step_height, step_width,
                              post_process_crop_height, post_process_crop_width,
                              post_process_step_height, post_process_step_width,
                              resolution, remove_post_process_, image_format_,
                              process_num=4, batch_size=4, mask_on=False)
    # 开始处理
    ss_obj()


def multi_image_copy(task_type, resolution,
                     input_dir, output_dir, model_file, config_file,
                     crop_height, crop_width, step_height, step_width,
                     post_process_crop_height, post_process_crop_width,
                     post_process_step_height, post_process_step_width,
                     remove_post_process_, image_format_):
    """
    根据csv文件提供的路径来推理多张影像
    :param task_type: 任务类型（变化检测、语义分割、目标检测）
    :param resolution: 影像分辨率
    :param input_dir: csv文件中所有影像对应的根目录，其中必须要包含一个csv文件
    :param output_dir: 输出结果路径（包含预测shp文件）
    :param model_file: 模型文件路径
    :param config_file: 配置文件路径
    :param crop_height: 推理阶段切片的高（单位为像素）
    :param crop_width: 推理阶段切片的宽（单位为像素）
    :param step_height: 推理阶段切片步长的高（单位为像素）
    :param step_width: 推理阶段切片步长的宽（单位为像素）
    :param post_process_crop_height: 后处理阶段切片的高（单位为像素）
    :param post_process_crop_width: 后处理阶段切片的宽（单位为像素）
    :param post_process_step_height: 后处理阶段切片步长的高（单位为像素）
    :param post_process_step_width: 后处理阶段切片步长的宽（单位为像素）
    :param remove_post_process_: 是否删除后处理
    :param image_format_: 输入图片的格式
    :return:
    """
    # 首先判断输入文件夹中是否存在一个csv文件
    csv_file_list = [os.path.join(input_dir, file_name) for file_name in os.listdir(input_dir)
                     if file_name.endswith('.csv')]
    csv_file_num = len(csv_file_list)
    if csv_file_num != 1:
        logger.error(f'There are {csv_file_num} csv file in {input_dir}, expect 1.')
        raise ValueError(f'There are {csv_file_num} csv file in {input_dir}, expect 1.')
    # 根据csv文件名称来定义输出csv文件名
    csv_file_name = csv_file_list[0].split('/')[-1].split('.')[0]
    out_csv_file = os.path.join(output_dir, csv_file_name + '_output.csv')
    # 读取csv文件并获取头信息，并将读取到的头信息添加到新的csv文件中
    csv_obj = CSV(csv_file_list[0], out_csv_file)
    current_line_data = csv_obj.read()
    current_line_data.append('result_shp')
    csv_obj.write(current_line_data)
    # 进入循环，依次读取待测影像路径并开始推理，并根据当前的位置来定义输出矢量路径
    image_index = 1
    while True:
        try:
            current_line_data = csv_obj.read()
        except StopIteration as e:
            break
        current_line_full_path = [os.path.join(input_dir, name) for name in current_line_data]
        output_shp_path = os.path.join(output_dir, '%s.shp' % image_index)
        try:
            each_image_copy(task_type, resolution,
                            current_line_full_path, output_shp_path, model_file, config_file,
                            crop_height, crop_width, step_height, step_width,
                            post_process_crop_height, post_process_crop_width,
                            post_process_step_height, post_process_step_width,
                            remove_post_process_, image_format_)
        except Exception as e:
            logger.info(f'{image_index}张影像出现错误{e}')
        output_line_data = current_line_data + ['%s.shp' % image_index]
        csv_obj.write(output_line_data)
        logger.info(f'已经推理完: {image_index}张影像')
        image_index += 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Start inference.")
    parser.add_argument("--task_type", required=True, type=int,
                        help="inference task type, 1:语义分割  2:变化检测  3:目标检测")
    parser.add_argument("--resolution", required=True, help="expected image resolution")
    parser.add_argument("--input_dir", default="/mnt/data/input", help="input directory")
    parser.add_argument("--output_dir", default="/mnt/data/output", help="output directory")
    parser.add_argument("--model_file", required=True, help="input model file path")
    parser.add_argument("--config_file", required=True, help="config file path")
    parser.add_argument("--crop_height", required=True, help="crop height (pixel)")
    parser.add_argument("--crop_width", required=True, help="crop width (pixel)")
    parser.add_argument("--step_height", required=True, help="crop step height (pixel)")
    parser.add_argument("--step_width", required=True, help="crop step width (pixel)")
    parser.add_argument("--post_process_crop_height", required=True, help="post process crop height (pixel)")
    parser.add_argument("--post_process_crop_width", required=True, help="post process crop width (pixel)")
    parser.add_argument("--post_process_step_height", required=True, help="post process crop step height (pixel)")
    parser.add_argument("--post_process_step_width", required=True, help="post process crop step width (pixel)")
    parser.add_argument("--remove_post_process", required=True, help="whether or not remove post process")
    parser.add_argument("--image_format", required=True, help="image format of input")

    args = parser.parse_args()
    # 补全模型和配置文件路径
    args.model_file = os.path.join('/model_config_dir', args.model_file)
    args.config_file = os.path.join('/model_config_dir', args.config_file)

    # 判断输入的remove_post_process和image_format是否超出边界
    remove_post_process = int(args.remove_post_process)
    if remove_post_process != 1 and remove_post_process != 2:
        logger.error(f'Please check args "remove_post_process", expect 1 or 2')
        exit()
    image_format = int(args.image_format)
    if image_format != 1 and image_format != 2:
        logger.error(f'Please check args "image_format", expect 1 or 2')
        exit()

    multi_image_copy(int(args.task_type), float(args.resolution),
                     args.input_dir, args.output_dir, args.model_file, args.config_file,
                     int(args.crop_height), int(args.crop_width), int(args.step_height), int(args.step_width),
                     int(args.post_process_crop_height), int(args.post_process_crop_width),
                     int(args.post_process_step_height), int(args.post_process_step_width),
                     remove_post_process, image_format)
