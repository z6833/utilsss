
import torch
import numpy as np
import torch.nn.functional as F
from detectron2.modeling import build_model
from aigislib.config.config import get_cfg
from detectron2.checkpoint import DetectionCheckpointer


class BasePredictor(object):
    def __init__(self, cfg_file, model_file):
        """
        模型推理的基类，使用ai gis lib库
        :param cfg_file: 模型配置文件路径，只用于对模型结构进行配置
        :param model_file: 模型文件路径
        """
        cfg = get_cfg()                        # 获取默认配置文件中的所有配置信息
        cfg.merge_from_file(cfg_file)          # 通过配置文件对默认配置文件的对应内容进行更改
        if model_file:
            cfg.defrost()                      # 激活配置文件，使得其中的参数可更改
            cfg.MODEL.WEIGHTS = model_file     # 将配置文件路径更改为当前输入的模型文件
        self.cfg = cfg.clone()                 # 拷贝配置文件信息
        self.cfg.freeze()                      # 冻结配置文件信息
        self.model = build_model(self.cfg)     # 通过配置文件内容构建模型结构
        self.model.eval()                      # 冻结模型结构，使得模型无法进行反向传播操作
        check_pointer = DetectionCheckpointer(self.model)
        check_pointer.load(cfg.MODEL.WEIGHTS)  # 加载模型文件，此时模型都准备好了，可以传入图片进行推理工作

    def __call__(self, image_list):
        """
        模型开始推理
        :param image_list: 可以直接送入模型推理的数据类型（四维数据），可能是一个或两个（变化检测）
                           具体形状为: [n, 3, h, w]
        :return:
        """
        # 开始模型推理工作
        res = self.model(image_list)

        return res


class BoxPredictor(BasePredictor):
    def __init__(self, cfg_file, model_file):
        super(BoxPredictor, self).__init__(cfg_file, model_file)
        pass

    def __call__(self, image_list):
        res = super().__call__(image_list)
        # 模型推理的结果为字典形式，这里将解析成后续期望的数据形式
        res_list = []
        for each_dict in res:
            current_res_dict = each_dict['instances'].get_fields()
            current_boxes = current_res_dict['pred_boxes'].tensor.cpu().detach().numpy()
            current_scores = current_res_dict['scores'].cpu().detach().numpy()
            # TODO: 未来需要兼容多类别的推理工作
            # current_classes = current_res_dict['pred_classes'].cpu().detach().numpy()
            # 将预测边框和得分进行拼接，便于后续的处理
            res_list.append(np.concatenate((current_boxes, current_scores[:, None]), axis=1))
        return res_list


class MaskPredictor(BasePredictor):
    def __init__(self, cfg_file, model_file):
        """
        该模型将会适用于语义分割网络和变化检测网络
        :param cfg_file:
        :param model_file:
        """
        super(MaskPredictor, self).__init__(cfg_file, model_file)
        pass

    def __call__(self, image_list):
        res = super().__call__(image_list)
        # 模型推理的结果为多个字典组成的列表，这里将解析成后续期望的数据形式
        res_list = []
        for each_dict in res:
            if 'sem_seg' in each_dict:
                current_res = each_dict['sem_seg']
            else:
                current_res = each_dict['change_detection']
            current_res = F.softmax(current_res, dim=0)[1] * 255
            current_res = torch.round(current_res)
            current_res = current_res.cpu().detach().numpy().astype(np.uint8)  # 转到CPU中处理
            res_list.append(current_res)

        return res_list


def test_object_detection():
    config_path = '/code/aigislib/model_zoo/object_detection/faster-rcnn.yaml'
    model_file_path = '/code/data/oilwell/model_0019999_0_20211210.pth'
    box_obj = BoxPredictor(config_path, model_file_path)
    import cv2
    img_path1 = '/code/data/oilwell/test1.tif'  # 205.6336, 223.0316, 293.4418, 275.3404
    img_path2 = '/code/data/oilwell/test2.tif'
    img_path3 = '/code/data/oilwell/test3.tif'
    img_path4 = '/code/data/oilwell/test4.tif'
    img_list = [img_path1, img_path2, img_path3, img_path4]
    image_list = []
    for img_path in img_list:
        image = cv2.imread(img_path)
        image = torch.tensor(image.transpose(2, 0, 1))  # 单张图片的形状要求为：3 * h * w
        image_list.append({'image': image})
    result = box_obj(image_list)
    print(result)
    """
    目标检测的结果为一个字典，包含多个键值对，形如下述内容
    [
    {'instances': Instances(num_instances=1, 
                            image_height=500, 
                            image_width=500, 
                            fields=[pred_boxes: Boxes(tensor([[205.6336, 223.0316, 293.4418, 275.3404]], 
                                                      device='cuda:0',
                                                      grad_fn=<IndexBackward>)), 
                                    scores: tensor([0.9996], device='cuda:0', grad_fn=<IndexBackward>), 
                                    pred_classes: tensor([0], device='cuda:0')
                                    ]
                            )
    }, 
    {'instances': Instances(num_instances=2, 
                            image_height=500, 
                            image_width=500, 
                            fields=[pred_boxes: Boxes(tensor([[216.8553, 182.3718, 282.0493, 319.1187],
                                                              [335.3508,  99.3012, 392.1035, 221.4411]], 
                                                      device='cuda:0',
                                                      grad_fn=<IndexBackward>)), 
                                    scores: tensor([0.9998, 0.9994], device='cuda:0', grad_fn=<IndexBackward>), 
                                    pred_classes: tensor([0, 0], device='cuda:0')
                                    ]
                            )
    }
    ]
    """


def test_sem_seg():
    config_path = '/code/aigislib/model_zoo/semantic_segmentation/agriculture_segmentation.yaml'
    model_file_path = '/code/model/model_final.pth'
    mask_obj = MaskPredictor(config_path, model_file_path)
    import cv2
    img_path1 = '/code/data/oilwell/test1.tif'
    img_path2 = '/code/data/oilwell/test2.tif'
    img_path_list = [img_path1, img_path2]
    image_list = []
    for img_path in img_path_list:
        image = cv2.imread(img_path)
        image_list.append({'image': torch.tensor(image.transpose(2, 0, 1))})
    # image = [{'image': torch.tensor(image.transpose(2, 0, 1))}]  # 单张图片的形状要求为：3 * h * w
    res = mask_obj(image_list)
    print(res)
    """
    语义分割的结果形式如下：
    [
        {'sem_seg': tensor_vector}, 张量的形状为：2 * h * w
        {'sem_seg': tensor_vector}
    ]
    """


def test_change_detection():
    config_path = '/code/aigislib/model_zoo/change_detection/siameseFPN_new.yaml'
    model_file_path = '/code/model/change_detection/model_final.pth'
    mask_obj = MaskPredictor(config_path, model_file_path)
    import cv2
    img_path1 = '/code/data/oilwell/test1.tif'
    img_path2 = '/code/data/oilwell/test2.tif'
    pre_image = cv2.imread(img_path1)
    post_image = cv2.imread(img_path2)
    print(pre_image.shape, post_image.shape)
    image = [{
        'pre_image': torch.tensor(pre_image.transpose(2, 0, 1)),
        'post_image': torch.tensor(post_image.transpose(2, 0, 1)),
        }
    ] * 8
    current_time = time.time()
    res = mask_obj(image)
    print(time.time() - current_time)
    print(res)
    """
    变化检测的推理结果是：
    [
        {'change_detection': tensor_vector},  # 每个张量的形状为：2 * h * w
        {'change_detection': tensor_vector}
    ]
    """


if __name__ == '__main__':
    # test_object_detection()
    # test_sem_seg()
    # test_change_detection()
    import os.path as path
    import time
    time0 = time.time()
    mmap = np.memmap('mymmap', dtype='uint8', mode='w+', shape=(100000, 100000))
    mmap[:] = np.ones((100000, 100000), dtype=np.uint8)
    mmap.flush()
    print(time.time() - time0)
    print(dir(mmap))
    mmap1 = np.memmap('mymmap', dtype='uint8', mode='r', shape=(100000, 100000))
    a = mmap1[:3][:3]
    print(a)
    pass
