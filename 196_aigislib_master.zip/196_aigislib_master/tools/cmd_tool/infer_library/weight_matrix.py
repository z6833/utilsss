
import torch
import copy


class WeightMatrix:
    def __init__(self, height, width):
        """
        获取切片拼接的权重矩阵
        :param height: 切片的高，单位为像素
        :param width: 切片的宽，单位为像素
        """
        self.height = height
        self.width = width
        self._cache_dict = dict()

    @staticmethod
    def base_weight(row, col):
        """
        基础权重
        TODO: 用户可以修改该函数来修改切片拼接的权重类型
        :param row: 行数
        :param col: 列数
        :return:
        """
        mask = torch.arange(1, row + 1).unsqueeze(1) * torch.ones((col,)) / (row + 1)
        return mask

    def __call__(self, top_margin, down_margin, left_margin, right_margin):
        """
        程序主入口
        :param top_margin: 上边沿的重叠长度，单位为像素
        :param down_margin: 下边沿的重叠长度，单位为像素
        :param left_margin: 左边沿的重叠长度，单位为像素
        :param right_margin: 右边沿的重叠长度，单位为像素
        :return:
        """
        tuple_id = (top_margin, down_margin, left_margin, right_margin)
        if tuple_id in self._cache_dict:
            return self._cache_dict[tuple_id]
        # 定义一个与切片大小相同的矩阵，后续在该矩阵的基础上对边沿和拐角处进行修改
        slice_matrix = torch.ones((self.height, self.width))
        weight_matrix = self.get_weight(slice_matrix, top_margin, down_margin, left_margin, right_margin)
        # 这里只保存上下左右边界相同的情况
        if top_margin == down_margin and left_margin == right_margin:
            self._cache_dict[tuple_id] = weight_matrix.numpy()
        return weight_matrix.numpy()

    def get_weight(self, slice_matrix, top_margin, down_margin, left_margin, right_margin):
        weight_matrix = copy.deepcopy(slice_matrix)
        if top_margin == 0 and down_margin == 0 and left_margin == 0 and right_margin == 0:
            return weight_matrix
        elif top_margin == 0 and down_margin == 0 and left_margin == 0 and right_margin != 0:
            weight_matrix[:, -right_margin:] = self.right_edge_weight(self.height, right_margin)
        elif top_margin == 0 and down_margin == 0 and left_margin != 0 and right_margin == 0:
            weight_matrix[:, :left_margin] = self.left_edge_weight(self.height, left_margin)
        elif top_margin == 0 and down_margin != 0 and left_margin == 0 and right_margin == 0:
            weight_matrix[-down_margin:, :] = self.down_edge_weight(down_margin, self.width)
        elif top_margin != 0 and down_margin == 0 and left_margin == 0 and right_margin == 0:
            weight_matrix[:top_margin, :] = self.up_edge_weight(top_margin, self.width)
        elif top_margin == 0 and left_margin == 0:
            weight_matrix[-down_margin:, :-right_margin] = self.down_edge_weight(down_margin, self.width-right_margin)
            weight_matrix[-down_margin:, -right_margin:] = self.right_down_corner_weight(down_margin, right_margin)
            weight_matrix[:-down_margin, -right_margin:] = self.right_edge_weight(self.height-down_margin, right_margin)
        elif left_margin == 0 and down_margin == 0:
            weight_matrix[:top_margin, :-right_margin] = self.up_edge_weight(top_margin, self.width-right_margin)
            weight_matrix[:top_margin, -right_margin:] = self.right_up_corner_weight(top_margin, right_margin)
            weight_matrix[top_margin:, -right_margin:] = self.right_edge_weight(self.height-top_margin, right_margin)
        elif down_margin == 0 and right_margin == 0:
            weight_matrix[top_margin:, :left_margin] = self.left_edge_weight(self.height-top_margin, left_margin)
            weight_matrix[:top_margin, :left_margin] = self.left_up_corner_weight(top_margin, left_margin)
            weight_matrix[:top_margin, left_margin:] = self.up_edge_weight(top_margin, self.width-left_margin)
        elif right_margin == 0 and top_margin == 0:
            weight_matrix[:-down_margin, :left_margin] = self.left_edge_weight(self.height-down_margin, left_margin)
            weight_matrix[-down_margin:, :left_margin] = self.left_down_corner_weight(down_margin, left_margin)
            weight_matrix[-down_margin:, left_margin:] = self.down_edge_weight(down_margin, self.width-left_margin)
        elif top_margin == 0:
            weight_matrix[:-down_margin, :left_margin] = self.left_edge_weight(self.height-down_margin, left_margin)
            weight_matrix[-down_margin:, :left_margin] = self.left_down_corner_weight(down_margin, left_margin)
            weight_matrix[-down_margin:, left_margin:-right_margin] = \
                self.down_edge_weight(down_margin, self.width-left_margin-right_margin)
            weight_matrix[-down_margin:, -right_margin:] = self.right_down_corner_weight(down_margin, right_margin)
            weight_matrix[:-down_margin, -right_margin:] = self.right_edge_weight(self.height-down_margin, right_margin)
        elif left_margin == 0:
            weight_matrix[-down_margin:, :-right_margin] = self.down_edge_weight(down_margin, self.width-right_margin)
            weight_matrix[-down_margin:, -right_margin:] = self.right_down_corner_weight(down_margin, right_margin)
            weight_matrix[top_margin:-down_margin, -right_margin:] = \
                self.right_edge_weight(self.height-top_margin-down_margin, right_margin)
            weight_matrix[:top_margin, -right_margin:] = self.right_up_corner_weight(top_margin, right_margin)
            weight_matrix[:top_margin, :-right_margin] = self.up_edge_weight(top_margin, self.width-right_margin)
        elif down_margin == 0:
            weight_matrix[top_margin:, :left_margin] = self.left_edge_weight(self.height-top_margin, left_margin)
            weight_matrix[:top_margin, :left_margin] = self.left_up_corner_weight(top_margin, left_margin)
            weight_matrix[:top_margin, left_margin:-right_margin] = \
                self.up_edge_weight(top_margin, self.width-left_margin-right_margin)
            weight_matrix[:top_margin, -right_margin:] = self.right_up_corner_weight(top_margin, right_margin)
            weight_matrix[top_margin:, -right_margin:] = self.right_edge_weight(self.height-top_margin, right_margin)
        elif right_margin == 0:
            weight_matrix[:top_margin, left_margin:] = self.up_edge_weight(top_margin, self.width-left_margin)
            weight_matrix[:top_margin, :left_margin] = self.left_up_corner_weight(top_margin, left_margin)
            weight_matrix[top_margin:-down_margin, :left_margin] = \
                self.left_edge_weight(self.height-top_margin-down_margin, left_margin)
            weight_matrix[-down_margin:, :left_margin] = self.left_down_corner_weight(down_margin, left_margin)
            weight_matrix[-down_margin:, left_margin:] = self.down_edge_weight(down_margin, self.width-left_margin)
        else:
            weight_matrix[top_margin:-down_margin, :left_margin] = \
                self.left_edge_weight(self.height-top_margin-down_margin, left_margin)
            weight_matrix[:top_margin, :left_margin] = \
                self.left_up_corner_weight(top_margin, left_margin)
            weight_matrix[-down_margin:, :left_margin] = \
                self.left_down_corner_weight(down_margin, left_margin)
            weight_matrix[-down_margin:, left_margin:-right_margin] = \
                self.down_edge_weight(down_margin, self.width-left_margin-right_margin)
            weight_matrix[-down_margin:, -right_margin:] = \
                self.right_down_corner_weight(down_margin, right_margin)
            weight_matrix[top_margin:-down_margin, -right_margin:] = \
                self.right_edge_weight(self.height-top_margin-down_margin, right_margin)
            weight_matrix[:top_margin, -right_margin:] = \
                self.right_up_corner_weight(top_margin, right_margin)
            weight_matrix[:top_margin, left_margin:-right_margin] = \
                self.up_edge_weight(top_margin, self.width-left_margin-right_margin)
        return weight_matrix

    def up_edge_weight(self, row, col):
        """
        获取上边沿的权重
        :param row: 行数
        :param col: 列数
        :return:
        """
        mask = self.base_weight(row, col)
        return mask

    def down_edge_weight(self, row, col):
        """
        获取上边沿的权重
        :param row: 行数
        :param col: 列数
        :return:
        """
        mask = torch.rot90(self.base_weight(row, col), 2)
        return mask

    def left_edge_weight(self, row, col):
        """
        获取左边沿的权重
        :param row: 行数
        :param col: 列数
        :return:
        """
        mask = torch.rot90(self.base_weight(col, row))
        return mask

    def right_edge_weight(self, row, col):
        """
        获取右边沿的权重
        :param row: 行数
        :param col: 列数
        :return:
        """
        mask = torch.rot90(self.base_weight(col, row), 3)
        return mask

    def left_up_corner_weight(self, row, col):
        """
        获取左上角的权重
        :param row: 行数
        :param col: 列数
        :return:
        """
        return self.left_edge_weight(row, col) * self.up_edge_weight(row, col)

    def right_up_corner_weight(self, row, col):
        """
        获取右上角的权重
        :param row: 行数
        :param col: 列数
        :return:
        """
        return self.right_edge_weight(row, col) * self.up_edge_weight(row, col)

    def right_down_corner_weight(self, row, col):
        """
        获取右下角的权重
        :param row: 行数
        :param col: 列数
        :return:
        """
        return self.right_edge_weight(row, col) * self.down_edge_weight(row, col)

    def left_down_corner_weight(self, row, col):
        """
        获取左下角的权重
        :param row: 行数
        :param col: 列数
        :return:
        """
        return self.left_edge_weight(row, col) * self.down_edge_weight(row, col)


if __name__ == '__main__':
    weight_obj = WeightMatrix(6, 6)
    print('第一个')
    print(weight_obj(0, 2, 0, 3))
    # print('第二个')
    # print(weight_obj(0, 2, 2, 2))
    # print('第三个')
    # print(weight_obj(0, 2, 2, 0))
    # print('第四个')
    # print(weight_obj(2, 2, 0, 2))
    # print('第五个')
    # print(weight_obj(2, 2, 2, 2))
    # print('第六个')
    # print(weight_obj(2, 2, 2, 0))
    # print('第七个')
    # print(weight_obj(2, 0, 0, 2))
    # print('第八个')
    # print(weight_obj(2, 0, 2, 2))
    # print('第九个')
    # print(weight_obj(2, 0, 2, 0))
