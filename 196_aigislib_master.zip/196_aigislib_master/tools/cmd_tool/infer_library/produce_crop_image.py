
"""
对输入影像进行滑窗切片，获得待处理切片
"""
import os
import sys
import pathlib
cwd_path = pathlib.Path(__file__).absolute()
parent_path = cwd_path.parent.parent.parent.parent.parent.as_posix()
sys.path.append(parent_path)
import math
import numpy as np
from multiprocessing import Queue
from rs_utils.utilss.window import Rect
from .data_structure import DataPackage
from .multi_process import MultiProcess
from rs_utils.rasters.raster import RasterData


class SlideWindow(object):
    def __init__(self,
                 image_path_list,
                 space_extent,
                 crop_rows,
                 crop_cols,
                 step_rows,
                 step_cols,
                 resolution,
                 process_num,
                 batch_size,
                 image_format,
                 mask_on=False):
        """
        对输入影像进行滑窗切片，获得待处理切片
        :param image_path_list: 待切片的原始影像，以列表形式存放，可能包含一张或两张（变化检测）
        :param space_extent: 待切片原始影像的窗口范围
        :param crop_rows: 切片的高（像素）
        :param crop_cols: 切片的宽（像素）
        :param step_rows: 切片的竖直步长（像素）
        :param step_cols: 切片的水平步长（像素）
        :param resolution: 期望分辨率
        :param process_num: 进程数量，即多个进程并行获取图片
        :param batch_size: 批量抓取的切片数量
        :param image_format: 输入图片的格式
        :param mask_on: 是否获取权重矩阵，对于语义分割相关的任务类型有用
        """
        self.image_path_list = image_path_list
        self.crop_rows = crop_rows
        self.crop_cols = crop_cols
        self.step_rows = step_rows
        self.step_cols = step_cols
        self.resolution = resolution
        self.process_num = process_num
        self.image_format = image_format
        self.mask_on = mask_on
        self.space_extent = space_extent
        self.batch_size = batch_size
        self.loc_iter = self.location_iter()      # 位置迭代对象
        self.loc_queue = Queue(process_num * 2)   # 位置存放队列
        self.img_queue = Queue(process_num * 4)   # 切片存放队列
        self.flag_queue = Queue(process_num * 2)  # 标志位存放队列
        self.loc_process = MultiProcess(1, self.producer)
        self.img_process = MultiProcess(process_num, self.consumer)
        self.loc_process.start()
        self.img_process.start()

    def location_iter(self):
        extent_x_min, extent_y_min, extent_x_max, extent_y_max = self.space_extent

        # 切片的总行数和列数
        crop_rows_meter = self.crop_rows * self.resolution
        crop_cols_meter = self.crop_cols * self.resolution
        step_rows_meter = self.step_rows * self.resolution
        step_cols_meter = self.step_cols * self.resolution
        if extent_y_max - extent_y_min < crop_rows_meter:
            total_row = 1
        else:
            total_row = math.ceil((extent_y_max - extent_y_min - crop_rows_meter) / step_rows_meter) + 1
        if extent_x_max - extent_x_min < crop_cols_meter:
            total_col = 1
        else:
            total_col = math.ceil((extent_x_max - extent_x_min - crop_cols_meter) / step_cols_meter) + 1
        total_count = total_row * total_col
        # 计算特殊的重叠行数和重叠列数，需要像素坐标
        special_bottom_margin = self.crop_rows - ((extent_y_max - extent_y_min - self.crop_rows) % self.step_rows)
        special_right_margin = self.crop_cols - ((extent_x_max - extent_x_min - self.crop_cols) % self.step_cols)

        window_index = 0
        row_index = 0
        # 从上往下开始切，上下切割步长为-self.step_rows
        for row in np.arange(extent_y_max, extent_y_min, -self.step_rows * self.resolution):
            col_index = 0
            row_end = False
            clip_row_start = row
            # 此处判断是否已经切到了纵轴的最后一张，若是，extent_y_min + self.crop_rows开始裁剪纵轴
            if clip_row_start - crop_rows_meter <= extent_y_min:
                clip_row_start = extent_y_min + crop_rows_meter
                row_end = True
            # 从左往右开始切，左右切割步长为self.step_cols
            for col in np.arange(extent_x_min, extent_x_max, self.step_cols * self.resolution):  # 列
                window_index += 1
                print('正在处理：%s / %s' % (window_index, int(total_count)))
                col_end = False
                clip_col_start = col
                # 同理，此处判断是否已经切到了横轴的最后一张，若是，extent_x_max - self.crop_cols开始裁剪纵轴
                if clip_col_start + crop_cols_meter >= extent_x_max:
                    clip_col_start = extent_x_max - crop_cols_meter
                    col_end = True

                geo_locations = (clip_col_start, clip_row_start - crop_rows_meter,
                                 clip_col_start + crop_cols_meter, clip_row_start)
                # 获取切片的空间范围，这里写两次的目的就是为了分别给get和put赋值
                pixel_locations = [int((clip_col_start - extent_x_min) / self.resolution),
                                   int((extent_y_max - clip_row_start) / self.resolution),
                                   int((clip_col_start - extent_x_min) / self.resolution) + self.crop_cols,
                                   int((extent_y_max - clip_row_start) / self.resolution) + self.crop_rows]
                if not self.mask_on:
                    data_obj = DataPackage()
                    data_obj.set_geo_location(geo_locations)      # 切片的地理位置
                    data_obj.set_pixel_location(pixel_locations)  # 切片结果存放的像素位置
                    yield data_obj
                else:
                    # 获取切片拼接需要的权重矩阵
                    top_margin, down_margin, left_margin, right_margin = \
                        self.margin(row_index, col_index, total_row, total_col,
                                    special_bottom_margin, special_right_margin)
                    margin = [top_margin, down_margin, left_margin, right_margin]
                    data_obj = DataPackage()
                    data_obj.set_geo_location(geo_locations)      # 切片的地理位置
                    data_obj.set_pixel_location(pixel_locations)  # 切片结果存放的像素位置
                    data_obj.set_margin(margin)                   # 切片四边重叠的大小，这是为了计算结果拼接用到的权重矩阵
                    yield data_obj

                col_index += 1
                if col_end is True:
                    break
            row_index += 1
            if row_end is True:
                break

    def margin(self, row_index, col_index, total_row, total_col, special_bottom_margin, special_right_margin):
        # 权重矩阵大小的单位是像素，而切片大小和步长的单位是米，需要进行转换处理
        pixel_crop_height = int(self.crop_rows)
        pixel_crop_width = int(self.crop_cols)
        # 需要判断左右边沿或上下边沿之和大于切片窗口大小范围，倒数第二行和倒数第二列会出现这种情况
        second_left_margin = int(self.crop_cols - self.step_cols)
        second_right_margin = int(special_right_margin)
        second_top_margin = int(self.crop_rows - self.step_rows)
        second_down_margin = int(special_bottom_margin)
        if second_top_margin + second_down_margin > pixel_crop_height:
            second_down_margin = pixel_crop_height - second_top_margin
        if second_left_margin + second_right_margin > pixel_crop_width:
            second_right_margin = pixel_crop_width - second_left_margin

        if col_index == 0:
            left_margin = 0
            right_margin = int(self.crop_cols - self.step_cols)
        elif col_index == total_col - 2:
            left_margin = int(self.crop_cols - self.step_cols)
            right_margin = second_right_margin
        elif col_index == total_col - 1:
            left_margin = second_right_margin
            right_margin = 0
        else:
            left_margin = right_margin = int(self.crop_cols - self.step_cols)

        if row_index == 0:
            top_margin = 0
            down_margin = int(self.crop_rows - self.step_rows)
        elif row_index == total_row - 2:
            top_margin = int(self.crop_rows - self.step_rows)
            down_margin = second_down_margin
        elif row_index == total_row - 1:
            top_margin = second_down_margin
            down_margin = 0
        else:
            top_margin = down_margin = int(self.crop_rows - self.step_rows)
        return top_margin, down_margin, left_margin, right_margin

    def get(self, data_obj, image_list):
        try:
            # 切片的地理范围（米）
            geo_location = data_obj.geo_location
            left, up, right, down = geo_location
            crop_rect = Rect(left, up, right, down)  # 这里的位置单位为米
            # 切片的像素尺寸
            output_shape = (3, self.crop_rows, self.crop_cols)
            # 对输入的一景或两景影像进行重写
            input_images_list = []
            for index, img in enumerate(image_list):
                data = img.crop(crop_rect, out_shape=output_shape).data.astype(np.uint8)  # 形状为[3, h, w]
                if np.sum(data) == 0:
                    return None
                # 判断切片图片的格式
                if self.image_format == 'RGB':  # 图片格式为RGB
                    pass
                else:  # 图片格式为BGR
                    data = data[::-1, :, :]
                # gdal读出来的切片shape是3,h,w，需要转换成h,w,3，才能转换成Image格式进行resize
                # data = np.transpose(data, (1, 2, 0))  # h, w, 3
                # input_images_list.append(data[:, :, ::-1])  # switch to BGR
                input_images_list.append(data)
            data_obj.set_image(input_images_list)
            # geo_location = crop_rect = left = up = right = down = None
        except Exception as e:
            print('获取切片的子进程(id号为%s)出现错误" %s "，退出推理过程' % (os.getpid(), e))
        return data_obj

    def batch_data(self):
        data_list = []
        while True:
            each_data = self.img_queue.get()
            if each_data == -1:
                self.flag_queue.put(-1)  # 压入毒药，便于计算停止工作的进程数
                if self.flag_queue.qsize() == self.process_num:
                    break
                continue
            data_list.append(each_data)
            if len(data_list) == self.batch_size:
                break
        return data_list

    def producer(self):
        self.flag_queue.get()
        while True:
            try:
                location_obj = next(self.loc_iter)
                self.loc_queue.put(location_obj)
            except StopIteration:
                # 位置对象结束之后，放入进程数量的毒药，用于结束多进程的工作
                for _ in range(self.process_num):
                    # 放入毒药-1
                    self.loc_queue.put(-1)
                break

    def consumer(self):
        image_list = [RasterData.build_file(img_path) for img_path in self.image_path_list]
        while True:
            res = self.loc_queue.get()
            if res == -1:  # 当前消费者拿到毒药，则当前子进程工作结束，给图片队列中压入一个毒药
                self.img_queue.put(-1)
                break
            res = self.get(res, image_list)
            if res is not None:
                self.img_queue.put(res)
