"""
主要负责csv文件的读取和写入
"""
import csv


class CSV(object):
    def __init__(self, input_file, output_file):
        """
        csv文件的读取和写入（写入新的文件中）
        :param input_file: 待读取的文件
        :param output_file: 待写入的文件
        """
        self.input_file = input_file
        self.output_file = output_file
        self.input_file_handle = open(input_file, 'r')
        self.output_file_handle = open(output_file, 'w')
        self.input_csv_data = csv.reader(self.input_file_handle)
        self.output_csv_data = csv.writer(self.output_file_handle)

    def read(self):
        """
        从输入csv文件中读取一行数据
        :return: 由多个数据责成的列表
        """
        data = next(self.input_csv_data)
        return data

    def write(self, data):
        """
        将一行数据写入输出csv文件中
        :param data:
        :return:
        """
        self.output_csv_data.writerow(data)

    def save(self):
        pass
