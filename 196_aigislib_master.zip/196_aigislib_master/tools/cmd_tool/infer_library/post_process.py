
import cv2
import copy
import torch
import numpy as np


def watershed(data_obj, scores, fg_threshold, bg_threshold):
    """
    分水岭后处理算法
    :param data_obj: 切片得到的数据对象
    :param scores: 模型处理得到的得分矩阵
    :param fg_threshold: 分水岭的前景阈值
    :param bg_threshold: 分水岭的背景阈值
    :return:
    """
    # 注意：切片得到的数据形状为：3 * h * w，需要转换成：h * w * 3
    images_list = data_obj.image_list
    # 获取当前窗口图片对应的marker
    marker = np.zeros_like(scores, dtype=np.int32)
    marker[scores < bg_threshold] = 1
    marker[scores > fg_threshold] = 2
    # 提取当前窗口对应的原始影像
    img_list = []
    for img in images_list:
        img = img.transpose((1, 2, 0))   # 3*h*w --> h*w*3
        each_marker = copy.deepcopy(marker)
        # 算法的结果为int32，为了压缩内存，将其转为int8
        water_res = cv2.watershed(img, each_marker).astype(np.int8)
        # 分水岭算法的结果进行阈值化
        water_res[water_res == -1] = 1
        water_res[water_res == 1] = 0
        water_res[water_res == 2] = 1
        img_list.append(water_res)
    # 如果img_list的长度为1，为语义分割任务，如果为2，则为变化检测任务
    marker_len = len(img_list)
    if marker_len == 1:
        merged_label = img_list[0].astype(np.uint8)
    else:
        inter = np.logical_and(img_list[0], img_list[1])
        merged_label = np.zeros(marker.shape, dtype=np.uint8)
        merged_label[inter] = 1

    return merged_label


def nms(data_obj, scores, iou_thresh):
    """
    目标检测边框间的非极大值抑制
    :param data_obj: 这是为了接口统一，这里的值是无用的
    :param scores: 模型推理得到的边框信息，为多行五列的矩阵
    :param iou_thresh: 非极大值抑制的阈值（IOU）
    :return:
    """
    from torchvision.ops import nms
    # 为了使用库里的非极大值抑制方法，需要将数据转为float32
    scores = torch.tensor(scores, dtype=torch.float32)
    pre_box = scores[:, :4]
    pre_score = scores[:, 4]
    # 开始进行非极大值抑制处理
    nms_res = nms(pre_box, pre_score, iou_thresh)
    # 根据非极大值抑制结果挑选出最终的边框和得分
    # post_nms_box = pre_box[nms_res].numpy()
    # post_nms_score = pre_score[nms_res].numpy()
    post_res = scores[nms_res].numpy()

    return post_res


if __name__ == '__main__':
    test_content = np.array([[1, 1, 4, 4, 0.8],
                             [2, 2, 5, 5, 0.9],
                             [3, 3, 5, 6, 0.6]])
    thresh = 0.3
    res = nms(None, test_content, thresh)
    print(res)
