
import pathlib
import sys
cwd_path = pathlib.Path(__file__).absolute()
parent_path = cwd_path.parent.as_posix()
sys.path.append(parent_path)

import os
import argparse
from infer_library.inference_work import MaskInference, ChangeInference, BoxInference
from infer_library.about_csv import CSV
from detectron2.utils.logger import setup_logger


logger = setup_logger(name=__name__)


def single_image_inference(task_type, resolution,
                           input_path, output_path, model_file, config_file,
                           crop_height, crop_width, step_height, step_width,
                           post_process_crop_height, post_process_crop_width,
                           post_process_step_height, post_process_step_width,
                           add_post_process, process_num, batch_size):
    """
    处理单张影像
    :param task_type: 任务类型（变化检测、语义分割、目标检测）
    :param resolution: 影像分辨率
    :param input_path: 输入影像路径
    :param output_path: 输出矢量路径
    :param model_file: 模型文件路径
    :param config_file: 配置文件路径
    :param crop_height: 推理阶段切片的高（单位为像素）
    :param crop_width: 推理阶段切片的宽（单位为像素）
    :param step_height: 推理阶段切片步长的高（单位为像素）
    :param step_width: 推理阶段切片步长的宽（单位为像素）
    :param post_process_crop_height: 后处理阶段切片的高（单位为像素）
    :param post_process_crop_width: 后处理阶段切片的宽（单位为像素）
    :param post_process_step_height: 后处理阶段切片步长的高（单位为像素）
    :param post_process_step_width: 后处理阶段切片步长的宽（单位为像素）
    :param add_post_process: 是否添加后处理
    :param process_num: 切片所需的进程数
    :param batch_size: 模型一次处理的图片数量
    :return:
    """
    if task_type == 1:  # 语义分割
        ss_obj = MaskInference(model_file, config_file, input_path, output_path,
                               crop_height, crop_width, step_height, step_width,
                               post_process_crop_height, post_process_crop_width,
                               post_process_step_height, post_process_step_width,
                               resolution, add_post_process,
                               process_num=process_num, batch_size=batch_size, mask_on=True)
    elif task_type == 2:  # 变化检测
        ss_obj = ChangeInference(model_file, config_file, input_path, output_path,
                                 crop_height, crop_width, step_height, step_width,
                                 post_process_crop_height, post_process_crop_width,
                                 post_process_step_height, post_process_step_width,
                                 resolution, add_post_process,
                                 process_num=process_num, batch_size=batch_size, mask_on=True)
    else:  # 目标检测
        ss_obj = BoxInference(model_file, config_file, input_path, output_path,
                              crop_height, crop_width, step_height, step_width,
                              post_process_crop_height, post_process_crop_width,
                              post_process_step_height, post_process_step_width,
                              resolution, add_post_process,
                              process_num=process_num, batch_size=batch_size, mask_on=False)
    # 开始处理，如果出现了异常错误，需要杀掉相关进程
    try:
        ss_obj()
        return None
    except Exception as e:
        ss_obj.infer_slide_obj.loc_process.clear()
        ss_obj.infer_slide_obj.img_process.clear()
        if add_post_process == 1:
            ss_obj.post_slide_obj.loc_process.clear()
            ss_obj.post_slide_obj.img_process.clear()
        return e


def multi_image_inference(task_type, resolution,
                          input_csv_file, output_dir, model_file, config_file,
                          crop_height, crop_width, step_height, step_width,
                          post_process_crop_height, post_process_crop_width,
                          post_process_step_height, post_process_step_width,
                          add_post_process, process_num, batch_size):
    """
    根据csv文件提供的路径来推理多张影像
    :param task_type: 任务类型（变化检测、语义分割、目标检测）
    :param resolution: 影像分辨率
    :param input_csv_file: csv文件路径，其中包含了需要推理的所有影像路径
    :param output_dir: 输出结果路径（包含预测shp文件）
    :param model_file: 模型文件路径
    :param config_file: 配置文件路径
    :param crop_height: 推理阶段切片的高（单位为像素）
    :param crop_width: 推理阶段切片的宽（单位为像素）
    :param step_height: 推理阶段切片步长的高（单位为像素）
    :param step_width: 推理阶段切片步长的宽（单位为像素）
    :param post_process_crop_height: 后处理阶段切片的高（单位为像素）
    :param post_process_crop_width: 后处理阶段切片的宽（单位为像素）
    :param post_process_step_height: 后处理阶段切片步长的高（单位为像素）
    :param post_process_step_width: 后处理阶段切片步长的宽（单位为像素）
    :param add_post_process: 是否添加后处理
    :param process_num: 获取切片需要启动的进程数
    :param batch_size: 模型一次推理的图片数量
    :return:
    """
    # 注意：为了便捷，将服务器的根目录映射到容器内的/data，所以需要对这里的所有路径进行拼接处理
    input_csv_file = '/data' + input_csv_file
    output_dir = '/data' + output_dir
    model_file = '/data' + model_file
    config_file = '/data' + config_file
    # 根据csv文件名称来定义输出csv文件名
    csv_file_name = input_csv_file.split('/')[-1].split('.')[0]
    out_csv_file = os.path.join(output_dir, csv_file_name + '_output.csv')
    # 读取csv文件并获取头信息，并将读取到的头信息添加到新的csv文件中
    csv_obj = CSV(input_csv_file, out_csv_file)
    current_line_data = csv_obj.read()
    current_line_data.append('result_shp')
    csv_obj.write(current_line_data)
    # 进入循环，依次读取待测影像路径并开始推理，并根据当前的位置来定义输出矢量路径
    image_index = 1
    while True:
        try:
            current_line_data = csv_obj.read()
        except StopIteration as e:
            break
        current_line_full_path = ['/data' + name for name in current_line_data]
        output_shp_path = os.path.join(output_dir, '%s.shp' % image_index)
        info = single_image_inference(task_type, resolution,
                                      current_line_full_path, output_shp_path, model_file, config_file,
                                      crop_height, crop_width, step_height, step_width,
                                      post_process_crop_height, post_process_crop_width,
                                      post_process_step_height, post_process_step_width,
                                      add_post_process, process_num, batch_size)
        if info:
            logger.info(f'第{image_index}张影像出现错误{info}')
        output_line_data = current_line_data + ['%s.shp' % image_index]
        csv_obj.write(output_line_data)
        logger.info(f'已经推理完第{image_index}张影像')
        image_index += 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Start inference.")
    parser.add_argument("--task_type", required=True, type=int,
                        help="inference task type, 1:语义分割  2:变化检测  3:目标检测")
    parser.add_argument("--resolution", required=True, type=float, help="expected image resolution")
    parser.add_argument("--input_csv_path", required=True, type=str, help="input csv file path")
    parser.add_argument("--output_path", required=True, type=str, help="output directory")
    parser.add_argument("--model_file", required=True, type=str, help="input model file path")
    parser.add_argument("--config_file", required=True, type=str, help="config file path")
    parser.add_argument("--process_num", required=True, type=int, help="config file path")
    parser.add_argument("--batch_size", required=True, type=int, help="config file path")
    parser.add_argument("--crop_height", required=True, type=int, help="crop height (pixel)")
    parser.add_argument("--crop_width", required=True, type=int, help="crop width (pixel)")
    parser.add_argument("--step_height", required=True, type=int, help="crop step height (pixel)")
    parser.add_argument("--step_width", required=True, type=int, help="crop step width (pixel)")
    parser.add_argument("--post_process_crop_height", required=True, type=int,
                        help="post process crop height (pixel)")
    parser.add_argument("--post_process_crop_width", required=True, type=int,
                        help="post process crop width (pixel)")
    parser.add_argument("--post_process_step_height", required=True, type=int,
                        help="post process crop step height (pixel)")
    parser.add_argument("--post_process_step_width", required=True, type=int,
                        help="post process crop step width (pixel)")
    parser.add_argument("--add_post_process", required=True, type=int,
                        help="whether or not add post process")

    args = parser.parse_args()

    # 判断输入的remove_post_process和image_format是否超出边界
    post_process_addition = int(args.add_post_process)
    if post_process_addition != 1 and post_process_addition != 2:
        logger.error(f'Please check args "add_post_process", expect 1 or 2')
        exit()

    multi_image_inference(args.task_type, args.resolution,
                          args.input_csv_path, args.output_path, args.model_file, args.config_file,
                          args.crop_height, args.crop_width, args.step_height, args.step_width,
                          args.post_process_crop_height, args.post_process_crop_width,
                          args.post_process_step_height, args.post_process_step_width,
                          post_process_addition, args.process_num, args.batch_size)
