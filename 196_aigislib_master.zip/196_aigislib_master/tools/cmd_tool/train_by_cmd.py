# -*- coding: utf-8 -*-
"""
@File: train_by_cmd.py
@time: 2022/3/18 14:45
@Desc: 命令行参数训练网络
E-mail = yifan.jiang@southgis.com
"""
import sys
import pathlib
cwd_path = pathlib.Path(__file__).absolute()
parent_path = cwd_path.parent.parent.parent.parent.as_posix()
sys.path.append(parent_path)
import os
from detectron2.engine import default_argument_parser, launch
from aigislib.tools.train_net import main
from aigislib.tools.cmd_tool.merge_yaml import write_yaml


if __name__ == '__main__':
    yaml_path = '/mnt/data/yaml'
    input_path = '/mnt/data/input'
    output_path = '/mnt/data/output'
    parser = default_argument_parser()
    parser.add_argument('--yaml_file', type=str, default=None, help='yaml配置文件')
    parser.add_argument('--task_type', type=str, default=None, help='训练任务类型')
    parser.add_argument('--train_file', type=str, default=None, help='训练集文件夹名称')
    parser.add_argument('--test_file', type=str, default=None, help='测试集集文件夹名称')
    # parser.add_argument('--input_path', type=str, default=None, help='输入数据路径')
    # parser.add_argument('--output_path', type=str, default=None, help='模型、log等文件保存路径')
    # parser.add_argument('--num_gpus', type=int, default=1, help="训练使用的GPU数量")

    args = parser.parse_args()
    yaml_path = os.path.join(yaml_path, args.yaml_file)
    args.config_file = write_yaml(yaml_path, args.task_type, args.train_file,
                                  args.test_file, input_path, output_path)
    # 启动训练
    launch(
        main,
        args.num_gpus,
        num_machines=args.num_machines,
        machine_rank=args.machine_rank,
        dist_url=args.dist_url,
        args=(args,),
    )
