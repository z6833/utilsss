# -*- coding: utf-8 -*-
"""
@File: merge_yaml.py.py
@time: 2022/3/17 16:47
@Desc: ini配置参数添加到yaml文件
E-mail = yifan.jiang@southgis.com
"""
import os
from aigislib.config import get_cfg


def dataset_rewrite(cfg, dataset_mapper, evaluator, data_type, train_file_list, test_file_list, input_path):
    cfg.DATASETS.DatasetMapper = dataset_mapper
    cfg.DATASETS.EVALUATOR = evaluator
    train_data = list()
    for item in train_file_list:
        data = [item, data_type, os.path.join(input_path, item)]
        train_data.append(data)
    cfg.DATASETS.TRAIN = train_data
    test_data = list()
    for item in test_file_list:
        data = [item, data_type, os.path.join(input_path, item)]
        test_data.append(data)
    cfg.DATASETS.TEST = test_data
    return cfg


def write_yaml(yaml_path, task_type, train_file, test_file, input_path, output_path):
    """
    支持change_detection/semantic_segmentation/object_detection三个数据类型
    Args:
        yaml_path:
        task_type:
        train_file:
        test_file:
        input_path:
        output_path:
    Returns:

    """
    cfg = get_cfg()
    cfg.merge_from_file(yaml_path)
    train_file_list = train_file.split(' ')
    test_file_list = test_file.split(' ')
    if task_type == "change_detection":
        dataset_mapper = 'ChangeDetectionDatasetMapper'
        evaluator = 'ChangeDetectionEvaluator'
        data_type = 'change_detection_dataset'

        cfg = dataset_rewrite(cfg, dataset_mapper, evaluator, data_type, train_file_list, test_file_list, input_path)

    elif task_type == "semantic_segmentation":
        dataset_mapper = 'CustomDatasetMapper'
        evaluator = 'SemanticSegmentationEvaluator'
        data_type = 'csv_segmentation_dataset'
        cfg = dataset_rewrite(cfg, dataset_mapper, evaluator, data_type, train_file_list, test_file_list, input_path)

    else:
        dataset_mapper = 'CustomDatasetMapper'
        evaluator = 'COCODataEvaluator'
        data_type = 'coco_detection_dataset'
        cfg = dataset_rewrite(cfg, dataset_mapper, evaluator, data_type, train_file_list, test_file_list, input_path)

    cfg.OUTPUT_DIR = output_path

    new_yaml_path = os.path.join(output_path, "result.yaml")
    with open(new_yaml_path, "w") as f:
        f.write(cfg.dump())

    return new_yaml_path

