import pathlib
from sqlalchemy import true
import torch
from google.protobuf import text_format
import aigislib.tools.triton_tools.model_config_pb2 as PB

class PbtxtGenerator:
    def __init__(
        self,
        model_inputs: tuple,
        model_outputs: tuple,
        output_path: str,
        log_func=print
    ):
        """Triton配置文件生成

        Args:
            model_inputs (tuple): 模型的输入，tensor的tuple
            model_outputs (tuple): 模型的输出，tensor的tuple
            output_path (str): 输出的pbtxt文件路径
            log_func (_type_, optional): 打印日志的函数. Defaults to print.
        """    
        self.model_config = PB.ModelConfig()
        self.model_config.platform = 'pytorch_libtorch'
        self.model_inputs = model_inputs
        self.model_outputs = model_outputs
        self.output_path = pathlib.Path(output_path)
        self.log_func = log_func

    @classmethod
    def from_traceable_model(cls, traceable_model, output_path:str, log_func=print):
        """通过aigislib中导出模型的traceable_model创建对象

        Args:
            traceable_model (TracingAdapter): 使用detectron2的TracingAdapter包装的模型
            output_path (str): 输出的pbtxt文件路径
            log_func (_type_, optional): 打印日志的函数. Defaults to print.

        Returns:
            PbtxtGenerator: 类的实例
        """        
        model_inputs = traceable_model.flattened_inputs
        model_outputs = traceable_model(*model_inputs)
        return cls(model_inputs, model_outputs, output_path, log_func)

    def set_pb_inputs(self):
        """设置pbtxt文件中的输入部分
        """        
        for i, input_tensor in enumerate(self.model_inputs):
            input_pb = self.model_config.input.add()
            input_pb.name = f"INPUT__{i}"
            input_pb.data_type = torch_dtype_to_trtion_type(input_tensor.dtype)
            
            if len(input_tensor.shape) == 3 and input_tensor.shape[0] == 3:
                # 输入为3*h*w，尺寸设置为[3,-1,-1]
                input_pb.dims.extend([3,-1,-1])
            else:
                # 输入不确定，全部设置为-1动态尺寸
                input_pb.dims.extend([-1 for s in input_tensor.shape])

    def set_pb_outputs(self):
        """设置pbtxt文件中的输出部分
        """        
        for i, output_tensor in enumerate(self.model_outputs):
            if output_tensor.device == torch.device('cpu'):
                # 输出位于cpu上时不加入配置文件，避免报错（Tensor位于不同设备）
                self.log_func(f"OUTPUT__{i} is in {output_tensor.device}, so it has been skipped.")
                continue
            output_pb = self.model_config.output.add()
            output_pb.name = f"OUTPUT__{i}"
            output_pb.data_type = torch_dtype_to_trtion_type(output_tensor.dtype)

            if len(output_tensor.shape) == 2 and output_tensor.shape[1] == 4:
                # R-CNN 输出的坐标格式
                output_pb.dims.extend([-1, 4])
            else:
                # 不确定输出，全部设置为-1动态尺寸
                output_pb.dims.extend([-1 for s in output_tensor.shape])

    def set_pb_instance_group(self):
        # TODO: 多GPU多实例的控制
        pass

    def write_pbtxt(self):
        """写入文件
        """        
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        out_str = text_format.MessageToString(
            self.model_config, use_short_repeated_primitives=True)
        self.log_func(f'Triton pbtxt content: \n{out_str}')

        with open(self.output_path, 'w') as f:
            f.write(out_str)
        self.log_func(f'Triton pbtxt file has been written in {self.output_path}')

    def __call__(self):
        self.set_pb_inputs()
        self.set_pb_outputs()
        self.write_pbtxt()


def torch_dtype_to_trtion_type(dtype: torch.dtype):
    """将pytorch中的数据类型dtype转为triton中的数据类型

    Args:
        dtype (torch.dtype): pytorch数据类型

    Returns:
        _type_: Triton中的数据类型
    """    
    convert_dict = {
        torch.bool: PB.TYPE_BOOL,
        torch.uint8: PB.TYPE_UINT8,
        torch.int8: PB.TYPE_INT8,
        torch.int16: PB.TYPE_INT16,
        torch.int32: PB.TYPE_INT32,
        torch.int64: PB.TYPE_INT64,
        torch.float32: PB.TYPE_FP32,
        torch.float64: PB.TYPE_FP64
    }
    return convert_dict[dtype]


if __name__ == '__main__':
    inputs = (
        torch.randn((3,512,512), dtype=torch.float32).cuda(),
        torch.randn((3,512,512), dtype=torch.float32).cuda(),
    )
    outputs = (
        torch.randn((3,4), dtype=torch.float32).cuda(),
        torch.zeros(3, dtype=torch.int64).cuda(),
        torch.ones(3, dtype=torch.float32).cuda(),
        torch.tensor((512,512), dtype=torch.int64).cpu(),
        torch.randn((3,4), dtype=torch.float32).cuda(),
        torch.zeros(3, dtype=torch.int64).cuda(),
        torch.ones(3, dtype=torch.float32).cuda(),
        torch.tensor((512,512), dtype=torch.int64).cpu(),
    )
    g = PbtxtGenerator(inputs, outputs, 'output/config.pbtxt')
    g()