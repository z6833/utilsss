
import csv
import copy
import logging
import torch
from detectron2.evaluation.evaluator import DatasetEvaluator


class ObjDetectionEvaluator(DatasetEvaluator):
    """ 身份证边框检测数据集评估 """
    def __init__(self,
                 cfg,
                 dataset_name=None,
                 ):
        self._logger = logging.getLogger(__name__)
        self.cfg = cfg
        self.save_dir = cfg.OUTPUT_DIR
        self.dataset_name = dataset_name
        self._cpu_device = torch.device("cpu")
        self._num_classes = self.cfg.MODEL.NUM_CLASSES  # 不包括背景

        self.classes_record = dict()

        self.gt_add = 0
        self.gt_type_add = [0] * self._num_classes
        self.pred_add = 0
        self.pred_type_add = [0] * self._num_classes

        self.iou_record_list = {}
        self.iou_thresh_list = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

    def reset(self):
        """ 重置度量值 """
        # ！！！注意！！！其中的四个数字分别代表标签框个数、检测出来的标签框个数、预测框个数、预测正确的预测框个数
        for i in range(self._num_classes):
            self.classes_record['类别%s' % i] = [0, 0, 0, 0]
        self.classes_record['total'] = [0, 0, 0, 0]
        middle_dict = dict()
        for iou_thresh in self.iou_thresh_list:
            middle_dict['%s' % iou_thresh] = copy.deepcopy(self.classes_record)
        self.iou_record_list = middle_dict

    def process(self, inputs, outputs):
        """
        处理每一对(pred, gt)的评估结果
        Args:
            inputs  (dict)
            outputs (dict)
        """
        input_gt = inputs[0]
        if isinstance(outputs, list):
            output_pred = outputs[0]
        else:
            output_pred = outputs

        if 'instances' in input_gt:
            gt_boxes = input_gt['instances'].get('gt_boxes').tensor.cpu()
            gt_labels = input_gt['instances'].get('gt_classes').cpu()
        else:
            gt_boxes = torch.as_tensor(input_gt['bbox'])  # 如果边框的数据为0到1之间的数据，需要进行还原回去
            gt_labels = torch.as_tensor(input_gt['category_id'])

        if 'instances' in output_pred:
            if isinstance(output_pred['instances'], list):
                pred_boxes = output_pred['instances'][0].get('pred_boxes').tensor.cpu()
                pred_labels = output_pred['instances'][0].get('pred_classes').cpu()
            else:
                pred_boxes = output_pred['instances'].get('pred_boxes').tensor.cpu()
                pred_labels = output_pred['instances'].get('pred_classes').cpu()
        elif 'bbox' in output_pred:
            pred_boxes = output_pred['bbox']
            pred_labels = output_pred['category_id']
        else:  # 列表中存放Instance对象的情况
            pred_boxes = output_pred[0].pred_boxes.tensor.cpu()
            pred_labels = output_pred[0].pred_classes.cpu()

        # 首先要考虑到特殊情况，没有标签框或者预测框
        if len(gt_boxes) == 0 and len(pred_boxes) == 0:
            pass
        elif len(gt_boxes) == 0 and len(pred_boxes) != 0:
            self.pred_add += len(pred_boxes)
            for class_index in set(pred_labels.numpy()):
                current_pred_labels = pred_labels == class_index
                self.pred_type_add[class_index] += torch.as_tensor(current_pred_labels).sum()
        elif len(gt_boxes) != 0 and len(pred_boxes) == 0:
            self.gt_add += len(gt_boxes)
            for class_index in set(gt_labels.numpy()):
                current_gt_labels = gt_labels == class_index
                self.gt_type_add[class_index] += torch.as_tensor(current_gt_labels).sum()
        else:
            gt_h, gt_w = gt_boxes.size()
            pred_h, pred_w = pred_boxes.size()
            assert gt_w == 4, "单个边框的表示数据不为4个，可能还包含了其他数据"
            assert pred_w == 4, "单个边框的表示数据不为4个，可能还包含了其他数据"

            # 标签框和预测框的面积
            gt_area = (gt_boxes[:, 2] - gt_boxes[:, 0]) * (gt_boxes[:, 3] - gt_boxes[:, 1])
            pred_area = (pred_boxes[:, 2] - pred_boxes[:, 0]) * (pred_boxes[:, 3] - pred_boxes[:, 1])
            gt_area = gt_area[:, None].expand(gt_h, pred_h)
            pred_area = pred_area[None, :].expand(gt_h, pred_h)

            # 标签框和预测框的类别信息
            gt_labels_middle = gt_labels[:, None].expand(gt_h, pred_h)
            pred_labels_middle = pred_labels[None, :].expand(gt_h, pred_h)
            # 挑选出标签框和预测框类型相同的位置
            match_label_position = gt_labels_middle == pred_labels_middle

            # 开始求解边框交集面积
            gt_boxes = gt_boxes.t().reshape(4, gt_h, 1).expand(4, gt_h, pred_h)
            pred_boxes = pred_boxes.t().reshape(4, pred_h, 1).expand(4, pred_h, gt_h).permute(0, 2, 1)
            # 提取出左上点坐标的最大值、右下点坐标的最小值
            left_up = torch.max(gt_boxes[:2], pred_boxes[:2])
            right_down = torch.min(gt_boxes[2:], pred_boxes[2:])
            # 获取交集边框的宽和高
            inter_w = right_down[0] - left_up[0]
            inter_h = right_down[1] - left_up[1]
            # 过滤掉不相交的位置
            mask = (inter_w > 0) * (inter_h > 0)
            inter_area = inter_h * inter_w * mask
            # 交并比
            iou = inter_area / (gt_area + pred_area - inter_area)
            # 将标签类别不同的位置筛选掉
            iou_label = iou * match_label_position
            # 根据交并比依次添加每一类的边框信息
            for index, iou_thresh in enumerate(self.iou_thresh_list):
                # 利用当前类别进行筛选
                thresh_mask = iou_label > iou_thresh
                # 标签框的总数为
                gt_total = len(iou_label)
                # 检测出来的标签框个数为
                gt_num = torch.as_tensor((torch.as_tensor(thresh_mask).sum(dim=1) > 0)).sum()
                # 预测框的总数为
                pred_total = len(iou_label[0])
                # 预测框正确的个数为
                pred_num = torch.as_tensor((torch.as_tensor(thresh_mask).sum(dim=0) > 0)).sum()

                self.add_into_res(iou_thresh, 'total', gt_total, gt_num, pred_total, pred_num)

                # 开始处理各个类别单独的精度和召回率
                for class_index in set(gt_labels.numpy()):
                    current_gt_labels_middle = gt_labels_middle == class_index
                    # 标签框特定类型的总数为
                    gt_total = torch.as_tensor((torch.as_tensor(current_gt_labels_middle).sum(dim=1) > 0)).sum()
                    # 检测出来的特定标签框个数为
                    class_mask = current_gt_labels_middle * thresh_mask
                    gt_num = torch.as_tensor((torch.as_tensor(class_mask).sum(dim=1) > 0)).sum()
                    # 预测框的特定类的总数为
                    current_pred_middle = pred_labels_middle == class_index
                    pred_total = torch.as_tensor((torch.as_tensor(current_pred_middle).sum(dim=0) > 0)).sum()
                    # 预测框正确的特定类的个数为
                    iou_middle = current_pred_middle * thresh_mask
                    pred_num = torch.as_tensor((torch.as_tensor(iou_middle).sum(dim=0) > 0)).sum()
                    self.add_into_res(iou_thresh, class_index, gt_total, gt_num, pred_total, pred_num)

    def evaluate(self):
        """ 整合测试集中所有图片进行处理 """
        res = dict()
        with open("%s/test.csv" % self.save_dir, "w") as csv_file:
            writer = csv.writer(csv_file)
            # 获取第一行名称字符序列
            name_str = ['iou阈值', '标签框总数', '预测框总数', '总召回率']
            name_str = name_str + ['类别%s召回率' % i for i in range(self._num_classes)] + ['总精度']
            name_str = name_str + ['类别%s精度' % i for i in range(self._num_classes)]
            # 先写入columns_name
            writer.writerow(name_str)
            # 依次写入实际的评估数据
            value_list = []
            for iou_thresh in self.iou_thresh_list:
                iou_value = self.iou_record_list['%s' % iou_thresh]
                each_line = [iou_thresh,
                             iou_value['total'][0]+self.gt_add,
                             iou_value['total'][2]+self.pred_add,
                             self.get_ratio(iou_value, 'total', self.gt_add)]
                each_line += [
                    self.get_ratio(iou_value, '类别%s' % i, self.gt_type_add[i]) for i in range(self._num_classes)
                ]
                each_line += [self.get_ratio(iou_value, 'total', self.pred_add, False)]
                each_line += [
                    self.get_ratio(iou_value, '类别%s' % i, self.pred_type_add[i], False)
                    for i in range(self._num_classes)
                ]
                value_list.append(each_line)

                for i in range(self._num_classes):
                    precision = self.get_ratio(iou_value, '类别%s' % i, self.pred_type_add[i], False)
                    recall = self.get_ratio(iou_value, '类别%s' % i, self.gt_type_add[i])
                    res['阈值%s_类别%s_召回率' % (iou_thresh, i)] = recall
                    res['阈值%s_类别%s_精度' % (iou_thresh, i)] = precision
                    if precision + recall != 0:
                        res['阈值%s_类别%s_F1' % (iou_thresh, i)] = 2 * precision * recall / (precision + recall)
                    else:
                        res['阈值%s_类别%s_F1' % (iou_thresh, i)] = 0
            # 写入多行用writerows
            writer.writerows(value_list)
        self._logger.info(res)
        return res

    def add_into_res(self, iou_thresh, type_num, gt_total, gt_right, pred_total, pred_right):
        """
        将结果添加到结果字典中
        :param iou_thresh: 字典的第一层键值为各个阈值参数
        :param type_num: 类别编号
        :param gt_total: gt框总数量
        :param gt_right: 正确的gt框数量
        :param pred_total: 预测框总数量
        :param pred_right: 正确的预测框数量
        :return:
        """
        if type_num != 'total':
            type_num = '类别%s' % type_num
        self.iou_record_list[str(iou_thresh)][type_num][0] += gt_total
        self.iou_record_list[str(iou_thresh)][type_num][1] += gt_right
        self.iou_record_list[str(iou_thresh)][type_num][2] += pred_total
        self.iou_record_list[str(iou_thresh)][type_num][3] += pred_right

    @staticmethod
    def get_ratio(input_dict, index_name, add_num, recall=True):
        if recall:
            if input_dict[index_name][0] == 0:
                return 0
            ratio = input_dict[index_name][1] / (input_dict[index_name][0] + add_num)
        else:
            if input_dict[index_name][2] == 0:
                return 0
            ratio = input_dict[index_name][3] / (input_dict[index_name][2] + add_num)
        return ratio.data.numpy()
