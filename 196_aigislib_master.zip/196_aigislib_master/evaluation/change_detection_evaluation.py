import os
import logging

import numpy as np
import torch
from detectron2.data.catalog import MetadataCatalog
from detectron2.evaluation.evaluator import DatasetEvaluator


class ChangeDetectionEvaluator(DatasetEvaluator):
    """
    这种评估方式适合变化检测和语义分割
    """
    def __init__(self,
                 dataset_name,
                 output_dir=None,
                 *,
                 cfg=None,
                 num_classes=None,
                 **kwargs,
                 ):
        self._logger = logging.getLogger(__name__)
        if num_classes is None:
            self._logger.warning(
                "SemSegEvaluator(num_classes) is deprecated! It should be obtained from metadata.")

        self.dataset_name = dataset_name
        self._output_dir = output_dir

        self._cpu_device = torch.device("cpu")

        meta = MetadataCatalog.get(dataset_name)
        self._num_classes = len(meta.stuff_classes)

    def reset(self):
        """ 重置度量值 """
        precision_list, recall_list = [], []
        self.TP_list, self.FP_list, self.FN_list = [], [], []
        self._confusion_matrix = np.zeros((self._num_classes, self._num_classes), dtype=np.int64)
        self._predictions = []

    def process(self, inputs, outputs):
        """
        处理每一对(pred, gt)的评估结果
        Args:
            outputs (dict)
        """
        for input, output in zip(inputs, outputs):
            output = output["change_detection"].argmax(dim=0).to(self._cpu_device)      # [B, H, W]
            pred = np.array(output, np.int)
            # gt_pth = self.input_file_to_gt_file[input["file_name"]]
            gt = input["change_detection"].numpy()
            # gt = Image.open(gt_pth)

            assert gt.shape == pred.shape, "gt_image shape is not equire to pre_image"

            # 将gt_mat的255值变成1，与pred_mat值域保持统一
            gt[gt >= 255] = 1
            pred[pred >= 255] = 1

            # messure precision and recall
            TP = np.sum((pred == 1) & (gt == 1))
            FP = np.sum((pred == 1) & (gt == 0))
            FN = np.sum((pred == 0) & (gt == 1))
            self.TP_list.append(TP)
            self.FP_list.append(FP)
            self.FN_list.append(FN)

            # messure mIOU
            mask = (gt >= 0) & (gt < self._num_classes)
            label = self._num_classes * gt[mask].astype('int') + pred[mask]
            self._confusion_matrix += np.bincount(label, minlength=self._num_classes ** 2
                                ).reshape(self._num_classes, self._num_classes)

    def evaluate(self):
        """ 对测试集中所有影像进行处理 """
        if self._output_dir:
            os.mkdir(self._output_dir)

        # cal precision and recall
        precision = sum(self.TP_list) / (sum(self.TP_list) + sum(self.FP_list) + 1e-6)
        recall = sum(self.TP_list) / (sum(self.TP_list) + sum(self.FN_list) + 1e-6)
        F1 = (2 * precision * recall) / (precision + recall + 1e-6)

        # mIou
        MIoU = np.diag(self._confusion_matrix) / (
                np.sum(self._confusion_matrix, axis=1) + np.sum(self._confusion_matrix, axis=0) -
                np.diag(self._confusion_matrix))
        MIoU = np.nanmean(MIoU)

        res = {}
        res["mIou"] = MIoU * 100
        res["precision"] = precision * 100
        res["recall"] = recall * 100
        res["F1"] = F1 * 100

        self._logger.info(res)
        return res
