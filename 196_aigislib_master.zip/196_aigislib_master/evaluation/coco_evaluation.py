import os

import cv2
from detectron2.evaluation import COCOEvaluator
# from detectron2.data import MetadataCatalog
from detectron2.evaluation.coco_evaluation import instances_to_coco_json
from detectron2.utils.visualizer import Visualizer


class COCODataEvaluator(COCOEvaluator):
    """ 用于适配detectron2中的COCOEvaluator """

    def __init__(self,
                 dataset_name,
                 cfg=None,
                 distributed=True,
                 **kwargs
                 ):
        output_dir = os.path.join(cfg.OUTPUT_DIR, "inference", dataset_name)
        os.makedirs(output_dir, exist_ok=True)

        # MetadataCatalog.get(dataset_name).set(thing_classes=["building"],
        #                                         json_file=data_path,
        #                                         evaluation_type="coco"
        #  )
        super(COCODataEvaluator, self).__init__(dataset_name, output_dir=output_dir)
        # 增加样本可视化代码
        self.image_dir = os.path.join(output_dir, "image_viz")
        os.makedirs(self.image_dir, exist_ok=True)
        self.image_num_count = 0

    def process(self, inputs, outputs):
        # 增加样本可视化代码
        super(COCODataEvaluator, self).process(inputs, outputs)
        if self.image_num_count < 10:
            for input, output in zip(inputs, outputs):
                prediction = {"image_id": input["image_id"]}

                if "instances" in output:
                    instances = output["instances"].to(self._cpu_device)
                    # todo mapprer对图片进行缩放的话，可能会存在不对应情况，待解决
                    # prediction["instances"] = instances_to_coco_json(instances, input["image_id"])
                if "proposals" in output:
                    prediction["proposals"] = output["proposals"].to(self._cpu_device)
                img = cv2.imread(input["file_name"], cv2.IMREAD_COLOR)[:, :, ::-1]
                basename = os.path.basename(input["file_name"])
                # print(" prediction: ", prediction)
                # print("img: ", img)
                vis = Visualizer(img)
                vis_pred = vis.draw_instance_predictions(instances).get_image()
                cv2.imwrite(os.path.join(self.image_dir, basename), vis_pred[:, :, ::-1])
                break

            self.image_num_count += 1
