from detectron2.utils.registry import Registry

from aigislib.evaluation.ex_evaluator import SemanticEvaluator
from aigislib.evaluation.change_detection_evaluation import ChangeDetectionEvaluator
from aigislib.evaluation.coco_evaluation import COCODataEvaluator
from aigislib.evaluation.object_detection_evaluation import ObjDetectionEvaluator
from aigislib.evaluation.semantic_evaluation import SemanticSegmentationEvaluator

evaluator_registry = Registry("EVALUATOR")
evaluator_registry.__doc__ = """
Registry for evaluator, which is for calc metric of dataset.
"""
evaluator_registry.register(SemanticEvaluator)
evaluator_registry.register(ChangeDetectionEvaluator)
evaluator_registry.register(COCODataEvaluator)
evaluator_registry.register(ObjDetectionEvaluator)
evaluator_registry.register(SemanticSegmentationEvaluator)


# 旧版评估器没有dataset_name参数，只能评估第一个测试集
# 新版评估器与Detectron2的接口一致，可以根据dataset_name参数评估各测试集
# 此处使用列表对新旧评估器进行区分
evaluator_with_dataset_name = [
    "COCODataEvaluator",
    "ChangeDetectionEvaluator",
    "SemanticSegmentationEvaluator"
]


def build_evaluator(cfg, evaluator_name, dataset_name):
    """
        构建变化检测模型结构
    """
    if evaluator_name in evaluator_with_dataset_name:
        evaluator = evaluator_registry.get(evaluator_name)(dataset_name, cfg=cfg)
    else:
        evaluator = evaluator_registry.get(evaluator_name)(cfg)
    return evaluator
