
from collections import OrderedDict
import json
import os
import cv2
from detectron2.utils.comm import all_gather, is_main_process, synchronize
from detectron2.utils.file_io import PathManager
from detectron2.utils.logger import setup_logger
import numpy as np
from detectron2.evaluation.sem_seg_evaluation import SemSegEvaluator
import torch
from shapely.geometry import Polygon


class SemanticSegmentationEvaluator(SemSegEvaluator):
    """语义分割评估器，支持对象级指标。
    """    
    def __init__(
        self,
        dataset_name,
        distributed=True,
        output_dir=None,
        **kwargs
    ):
        """
        Args:
            dataset_name (str): name of the dataset to be evaluated.
            distributed (bool): if True, will collect results from all ranks for evaluation.
                Otherwise, will evaluate the results in the current process.
            output_dir (str): an output directory to dump results.
        """
        super().__init__(dataset_name, distributed=distributed, output_dir=output_dir)
        self._logger = setup_logger(name=__name__)
        self.iou_threshold_list = [0.4, 0.5, 0.75, 0.95]

    def reset(self):
        super().reset()
        self.obj_conf_matrix = np.zeros((len(self.iou_threshold_list), self._num_classes, 2, 2))

    def process(self, inputs, outputs):
        # TODO 找到数据集中较差的图片（难样本）
        for input, output in zip(inputs, outputs):
            output = output["sem_seg"].argmax(dim=0).to(self._cpu_device)
            pred = np.array(output, dtype=np.int)
            gt = np.array(input['sem_seg'], dtype=np.int)

            gt[gt == self._ignore_label] = self._num_classes
            # 混淆矩阵行为预测标签，列为真实标签
            # ----- ----- ----- -----
            #        t1    t2
            # pred1  TP    FP     0
            # pred2  FN    TN     0
            #        0      0     0
            # ----- ----- ----- -----
            self._conf_matrix += np.bincount(
                (self._num_classes + 1) * pred.reshape(-1) + gt.reshape(-1),
                minlength=self._conf_matrix.size,
            ).reshape(self._conf_matrix.shape)

            ious_matrix, class_matrix = self.get_obj_iou_class_matrix(
                output, gt)
            for iou_index, iou_threshold in enumerate(self.iou_threshold_list):
                for i in range(self._num_classes):
                    # 计算TP
                    # 预测polygon与标签polygon都为i分类的，且iou大于阈值的标记True
                    tp_matrix = np.bitwise_and(
                        class_matrix[0] == i, class_matrix[1] == i)
                    tp_matrix = np.bitwise_and(
                        tp_matrix, ious_matrix > iou_threshold)
                    tp_num_each_row = np.sum(tp_matrix, axis=1)
                    tp_num = np.sum(tp_num_each_row > 0)
                    # 计算FP
                    # 找到预测分类为i的列，没有TP的列即为FP
                    pred_i_index = np.unique(np.where(class_matrix[0] == i)[1])
                    tp_num_each_col_i = np.sum(
                        tp_matrix[:, pred_i_index], axis=0)
                    fp_num = pred_i_index.shape[0] - \
                        np.sum(tp_num_each_col_i > 0)
                    # 计算FN
                    # GT数量减去TP数量
                    gt_i_num = np.unique(
                        np.where(class_matrix[1] == i)[0]).shape[0]
                    fn_num = gt_i_num - tp_num
                    # 计算TN
                    # 剩余的全部记为TN
                    tn_num = np.sum(
                        np.sum(
                            np.bitwise_and(class_matrix[0] != i, class_matrix[1] != i), axis=1
                        ) > 0
                    )
                    # 混淆矩阵行为预测标签，列为真实标签
                    # ----- ----- -----
                    #        t1    t2
                    # pred1  TP    FP
                    # pred2  FN    TN
                    # ----- ----- -----
                    self.obj_conf_matrix[iou_index][i, 0, 0] += tp_num
                    self.obj_conf_matrix[iou_index][i, 0, 1] += fp_num
                    self.obj_conf_matrix[iou_index][i, 1, 0] += fn_num
                    self.obj_conf_matrix[iou_index][i, 1, 1] += tn_num

    def evaluate(self):
        if self._distributed:
            synchronize()
            conf_matrix_list = all_gather(self._conf_matrix)
            obj_conf_matrix_list = all_gather(self.obj_conf_matrix)
            if not is_main_process():
                return

            self._conf_matrix = np.zeros_like(self._conf_matrix)
            self.obj_conf_matrix = np.zeros_like(self.obj_conf_matrix)
            for conf_matrix in conf_matrix_list:
                self._conf_matrix += conf_matrix
            for obj_conf_matrix in obj_conf_matrix_list:
                self.obj_conf_matrix += obj_conf_matrix

        if self._output_dir:
            PathManager.mkdirs(self._output_dir)
            file_path = os.path.join(
                self._output_dir, "sem_seg_predictions.json")
            with PathManager.open(file_path, "w") as f:
                f.write(json.dumps(self._predictions))

        acc = np.full(self._num_classes, np.nan, dtype=np.float)
        precision = np.full(self._num_classes, np.nan, dtype=np.float)
        f1_score = np.full(self._num_classes, np.nan, dtype=np.float)
        iou = np.full(self._num_classes, np.nan, dtype=np.float)
        tp = self._conf_matrix.diagonal()[:-1].astype(np.float)  # 各类tp数量
        pos_gt = np.sum(
            self._conf_matrix[:-1, :-1], axis=0).astype(np.float)  # 各类的真实标签数量
        class_weights = pos_gt / np.sum(pos_gt)  # 各类像素的出现频率
        pos_pred = np.sum(
            self._conf_matrix[:-1, :-1], axis=1).astype(np.float)  # 各类的预测数量
        acc_valid = pos_gt > 0  # 只计算真实标签数量大于0的类别
        acc[acc_valid] = tp[acc_valid] / \
            pos_gt[acc_valid]  # acc按计算方法实际为召回率recall
        precision_valid = pos_pred > 0  # 只计算被预测到的类别
        precision[precision_valid] = tp[precision_valid] / \
            pos_pred[precision_valid]  # 各类的精确率
        f1_score = 2 * (acc * precision) / (acc + precision)  # 各类的f1分数
        iou_valid = (pos_gt + pos_pred) > 0
        union = pos_gt + pos_pred - tp
        iou[acc_valid] = tp[acc_valid] / union[acc_valid]
        macc = np.sum(acc[acc_valid]) / np.sum(acc_valid)
        miou = np.sum(iou[acc_valid]) / np.sum(iou_valid)
        fiou = np.sum(iou[acc_valid] * class_weights[acc_valid])
        pacc = np.sum(tp) / np.sum(pos_gt)
        mprecision = np.sum(
            precision[precision_valid]) / np.sum(precision_valid)
        mf1 = np.sum(f1_score) / self._num_classes

        res = {}
        res["mIoU"] = 100 * miou
        res["fwIoU"] = 100 * fiou
        for i, name in enumerate(self._class_names):
            res["IoU-{}".format(name)] = 100 * iou[i]
        res["mACC"] = 100 * macc
        res["pACC"] = 100 * pacc
        for i, name in enumerate(self._class_names):
            res["ACC-{}".format(name)] = 100 * acc[i]
        res["mPrecision"] = 100 * mprecision
        for i, name in enumerate(self._class_names):
            res["Precision-{}".format(name)] = 100 * precision[i]
        res["mF1Score"] = 100 * mf1
        for i, name in enumerate(self._class_names):
            res["F1-{}".format(name)] = 100 * f1_score[i]

        # 对象级指标 各类的精确率、召回率和F1分数
        for iou_index, iou_th in enumerate(self.iou_threshold_list):
            psum = 0
            rsum = 0
            f1sum = 0
            for i, name in enumerate(self._class_names):
                tp_i_obj = self.obj_conf_matrix[iou_index][i, 0, 0]
                fp_i_obj = self.obj_conf_matrix[iou_index][i, 0, 1]
                fn_i_obj = self.obj_conf_matrix[iou_index][i, 1, 0]
                p = tp_i_obj / (tp_i_obj + fp_i_obj)
                r = tp_i_obj / (tp_i_obj + fn_i_obj)
                f1_i_obj = 2 * p * r / (p + r) if (p+r != 0) else np.nan
                res['Precision-object-{}-iou{}'.format(name, iou_th)] = p * 100
                res['Recall-object-{}-iou{}'.format(name, iou_th)] = r * 100
                res['F1Score-object-{}-iou{}'.format(name, iou_th)] = f1_i_obj * 100
                psum += p
                rsum += r
                f1sum += f1_i_obj
            res['mPrecision-object-iou{}'.format(iou_th)] = psum / self._num_classes * 100
            res['mRecall-object-iou{}'.format(iou_th)] = rsum / self._num_classes * 100
            res['mF1Score-object-iou{}'.format(iou_th)] = f1sum / self._num_classes * 100

        if self._output_dir:
            file_path = os.path.join(
                self._output_dir, f"{self._dataset_name}_sem_seg_evaluation.json")
            with PathManager.open(file_path, "w") as f:
                json.dump(res, f, ensure_ascii=False, indent=4)
        results = OrderedDict({"sem_seg": res})

        self._logger.info(results)
        return results

    def get_obj_iou_class_matrix(self, pred_mask: np.ndarray, gt_mask: np.ndarray) -> tuple:
        """获取对象级的iou矩阵及Polygon对象的具体分类矩阵
        iou矩阵ious_matrix尺寸为(gt_polygons_num, pred_polygons_num)
        Polygon对象分类矩阵class_matrix尺寸为(2, gt_polygons_num, pred_polygons_num)，
        其中class_matrix[0]为预测polygon的分类，class_matrix[1]为真实标签polygon的分类

        Args:
            pred_mask (np.ndarray): 预测掩码
            gt_mask (np.ndarray): 真实标签掩码

        Returns:
            tuple: iou矩阵和Polygon对象分类矩阵
        """
        pred_polygons_list = list()
        pred_class_list = list()
        gt_polygons_list = list()
        gt_class_list = list()
        for i in range(self._num_classes):
            # 每一类的预测结果和标签进行二值化
            pred_i_binary_mask = np.zeros(pred_mask.shape, dtype=np.uint8)
            pred_i_binary_mask[pred_mask == i] = 255
            gt_i_binary_mask = np.zeros(gt_mask.shape, dtype=np.uint8)
            gt_i_binary_mask[gt_mask == i] = 255

            # 膨胀操作 避免出现只有两个点的轮廓
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
            pred_i_binary_mask = cv2.dilate(pred_i_binary_mask, kernel)
            gt_i_binary_mask = cv2.dilate(gt_i_binary_mask, kernel)

            # 使用CCOMP模式寻找轮廓，每个轮廓的层级最多2层
            pred_contours, pred_hierarchy = cv2.findContours(
                pred_i_binary_mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE
            )
            gt_contours, gt_hierarchy = cv2.findContours(
                gt_i_binary_mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE
            )
            # 将opencv的轮廓转换为shapely的Polygon对象（多边形中可以存在空洞）
            pred_polygons_classi = self.contours_to_polygons(
                pred_contours, pred_hierarchy)
            gt_polygons_classi = self.contours_to_polygons(
                gt_contours, gt_hierarchy)

            pred_objects_num = len(pred_polygons_classi)
            gt_objects_num = len(gt_polygons_classi)

            pred_polygons_list.extend(pred_polygons_classi)
            pred_class_list.extend([i]*pred_objects_num)

            gt_polygons_list.extend(gt_polygons_classi)
            gt_class_list.extend([i]*gt_objects_num)

        # 初始化iou矩阵，复制预测分类和标签分类生成分类矩阵
        ious_matrix = np.zeros(
            (len(gt_polygons_list), len(pred_polygons_list)))
        class_matrix = np.zeros((2, *ious_matrix.shape))
        class_matrix[0] = np.tile(np.array(pred_class_list), [
                                  ious_matrix.shape[0], 1])
        class_matrix[1] = np.tile(np.array(gt_class_list), [
                                  ious_matrix.shape[1], 1]).transpose()

        # 计算每个预测Polygon与标签Polygon的iou并存储到iou矩阵中
        for gt_index in range(ious_matrix.shape[0]):
            for pred_index in range(ious_matrix.shape[1]):
                intersection = pred_polygons_list[pred_index].intersection(
                    gt_polygons_list[gt_index]).area
                union = pred_polygons_list[pred_index].union(
                    gt_polygons_list[gt_index]).area
                ious_matrix[gt_index, pred_index] = intersection / union

        return ious_matrix, class_matrix

    def contours_to_polygons(self, contours: np.ndarray, hierarchy: np.ndarray) -> list:
        """将OpenCV找到的contours转换为Shapely中Polygon的list

        Args:
            contours (np.ndarray): cv2.findcontours返回的轮廓
            hierarchy (np.ndarray): cv2.findcontours返回的轮廓层级（两层模式）

        Returns:
            list: Polygon的list
        """        
        if contours is None or hierarchy is None:
            return []
        polygon_objects = list()
        shapely_contours = list(map(np.squeeze, contours)) # OpenCV格式转为Shapely需要的格式
        record = list() # 记录已经构建过Polygon的轮廓
        for h_index, h in enumerate(hierarchy[0]):
            if h_index in record:
                continue
            else:
                record.append(h_index)
            _, __, first_child, parent = h
            # 没有子轮廓的外部轮廓
            if first_child == -1 and parent == -1:
                polygon_objects.append(
                    Polygon(shapely_contours[h_index]).buffer(0))
            # 遍历同一父轮廓的子轮廓
            elif first_child != -1 and parent == -1:
                childs = np.where(hierarchy[0, :, 3] == h_index)[0]
                holes = list()
                for child in childs:
                    record.append(child)
                    holes.append(shapely_contours[child])
                polygon_objects.append(
                    Polygon(shapely_contours[h_index], holes).buffer(0))
        return polygon_objects


if __name__ == '__main__':
    # 测试代码
    class TestEvaluator(SemanticSegmentationEvaluator):
        def __init__(self) -> None:
            self._num_classes = 2
            self._class_names = ['bg', 'fg']
            self._cpu_device = 'cpu'
            self._ignore_label = 256
            self._distributed = True
            self._output_dir = None
            self._logger = setup_logger(name=__name__)
            self.iou_threshold_list = [0.4, 0.5, 0.75, 0.95]

    gt = np.zeros((512, 512), dtype=np.uint8)
    gt[200:250, 200:250] = 1
    gt[100:110, 100:110] = 1
    pred = np.zeros((512, 512), dtype=np.uint8)
    pred[210:260, 210:260] = 1
    pred[280:285, 280:285] = 1
    output = np.zeros((2, 512, 512))
    output[0] = 1 - pred
    output[1] = pred
    output = torch.from_numpy(output)
    inputs = [{'sem_seg': gt}, {'sem_seg': gt}]
    outputs = [{'sem_seg': output}, {'sem_seg': output}]

    te = TestEvaluator()
    te.reset()
    te.process(inputs, outputs)
    te.evaluate()
