# aigislib

基于detectron2框架搭建的深度学习框架，用于模型训练与推理