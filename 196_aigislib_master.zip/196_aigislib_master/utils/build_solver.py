import torch
from detectron2.config import CfgNode
from detectron2.solver import build_lr_scheduler as build_d2_lr_scheduler

from aigislib.utils.lr_scheduler import (
    WarmupPolyLR, 
    WarmupCosineAnnealingWarmRestarts,
    WarmupCosineAnnealingLR,
)

def build_lr_scheduler(
        cfg: CfgNode, optimizer: torch.optim.Optimizer
) -> torch.optim.lr_scheduler._LRScheduler:
    """
    从config文件中选择学习调整策略
    """
    name = cfg.SOLVER.LR_SCHEDULER_NAME
    # 添加poly学习率方式
    if name == 'WarmupPolyLR':
        return WarmupPolyLR(optimizer,
                            cfg.SOLVER.MAX_ITER,
                            warmup_factor=cfg.SOLVER.WARMUP_FACTOR,
                            warmup_iters=cfg.SOLVER.WARMUP_ITERS,
                            warmup_method=cfg.SOLVER.WARMUP_METHOD,
                            power=cfg.SOLVER.POLY_LR_POWER,
                            constant_ending=cfg.SOLVER.POLY_LR_CONSTANT_ENDING,
                            )
    elif name == 'WarmupCosineAnnealingWarmRestarts':
        return WarmupCosineAnnealingWarmRestarts(
            optimizer,
            cfg.SOLVER.MAX_ITER,
            warmup_factor=cfg.SOLVER.WARMUP_FACTOR,
            warmup_iters=cfg.SOLVER.WARMUP_ITERS,
            warmup_method=cfg.SOLVER.WARMUP_METHOD,
            T_0=cfg.SOLVER.T_0,
            T_mult=cfg.SOLVER.T_MULT,
            eta_min=cfg.SOLVER.ETA_MIN
        )
    elif name == 'WarmupCosineAnnealingLR':
        return WarmupCosineAnnealingLR(
            optimizer,
            cfg.SOLVER.MAX_ITER,
            warmup_factor=cfg.SOLVER.WARMUP_FACTOR,
            warmup_iters=cfg.SOLVER.WARMUP_ITERS,
            warmup_method=cfg.SOLVER.WARMUP_METHOD,
            T_0=cfg.SOLVER.T_0,
            eta_min=cfg.SOLVER.ETA_MIN
        )
    
    else:
        return build_d2_lr_scheduler(cfg, optimizer)