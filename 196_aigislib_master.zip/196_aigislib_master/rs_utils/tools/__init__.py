from .multi_process import Producer, Consumer, Consumer2, main
from .single_process_entrance import SampleMake
