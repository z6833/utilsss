# -*- coding: utf-8 -*-
"""
@File: __init__.py
@time: 2022/3/29 9:03
@Desc: 实现xxx
E-mail = yifan.jiang@southgis.com
"""
from sample_makes.sample_make_bace import SampleMakeBase
from sample_makes.change_detection_sample_make import ChangeDetectionSampleMake
from sample_makes.segmentation_sample_make import SegmentationSampleMake
from sample_makes.target_detection_sample_make import TargetDetectionSampleMake