# -*- coding:utf-8 -*-
# @FileName  :demo.py
# @Time      :2022/4/21 17:16
# @Author    :zhaolun
item_list = [
    'new-4193.0-415',
    'new-4193.0-416',
    'new-4193.0-417',
    'new-4193.0-418',
    'new-4193.0-419',
    'new-4194.0-414',
    'new-4194.0-416',
    'new-4194.0-417',
    'new-4194.0-418',
    'new-4195.0-416',
    'new-4195.0-417',
    'new-4195.0-418',
    'new-4195.0-419',
    'new-4196.0-416',
    'new-4196.0-417',
    'new-4196.0-418',
    'new-4196.0-419',
    'new-4197.0-415',
    'new-4197.0-416',
    'new-4198.0-415',
    'new-4198.0-417',
    'new-4199.0-415',
    'new-4199.0-416',
    '2019dy-40',
    '202101',
]

result = []
for item in item_list:
    aa = [f"{item}/raw_data/0_norm", "coco_detection_dataset", f"/data_01/results/train/{item}/raw_data"]
    result.append(aa)

    # if 'new-' in item:
    #     nums = 8
    # else:
    #     nums = 3
    nums = 8
    for i in range(nums):
        tt = [f"{item}/aug_data/{i}_move", "coco_detection_dataset", f"/data_01/results/train/{item}/aug_data/{i}_move"]
        result.append(tt)

print(result)
print(len(result))
