# -*- coding:utf-8 -*-
# @FileName  :demo.py
# @Time      :2022/4/28 9:20
# @Author    :zhaolun

import json
import os

def main():

    data_path = r'/data_01/updated/cropped'

    filepath = os.path.join(data_path, 'instances_train.json')

    fp = open(filepath, 'r')
    results = json.load(fp)
    for res in results['images']:
        res['file_name'] = ''


    return


if __name__ == "__main__":
    main()