"""
数据增强不引入Normalize操作
"""

import copy
import numpy as np
import logging
from typing import List, Union
import cv2
import pyclipper
import torch
import torchvision.transforms as transforms
from detectron2.data.dataset_mapper import DatasetMapper
from detectron2.data.detection_utils import SizeMismatchError
from detectron2.data import detection_utils as utils
from detectron2.data import transforms as T
from detectron2.utils.logger import setup_logger
from .build import MAPPER_REGISTRY
from ..transformer.build import build_augmentation
from detectron2.config import configurable

# from ..transformer import CustomAugInput
__all__ = [
    'OriginalDatasetMapper',
    'WordRecognitionDatasetMapper',
    'ChangeDetectionDatasetMapper',
    'WordLineDetectionDatasetMapper',
    'WordCharDetectionDatasetMapper',
    'IdcardBorderDatasetMapper',
    'UnderlineDatasetMapper',
    'CustomDatasetMapper'
    ]

MAPPER_REGISTRY.register(DatasetMapper)


@MAPPER_REGISTRY.register()
class OriginalDatasetMapper(DatasetMapper):
    def __init__(self, cfg, *args, is_train=True, image_format="RGB", **kwargs):
        super(OriginalDatasetMapper, self).__init__(cfg, *args, is_train=is_train, image_format=image_format, **kwargs)
        pass


def build_transform_gen(cfg, is_train):
    """
    Create a list of :class:`TransformGen` from config.
    Returns:
        list[TransformGen]
    """
    if is_train:
        min_size = cfg.INPUT.MIN_SIZE_TRAIN
        max_size = cfg.INPUT.MAX_SIZE_TRAIN
        sample_style = cfg.INPUT.MIN_SIZE_TRAIN_SAMPLING
    else:
        min_size = cfg.INPUT.MIN_SIZE_TEST
        max_size = cfg.INPUT.MAX_SIZE_TEST
        sample_style = "choice"
    if sample_style == "range":
        assert len(min_size) == 2, "more than 2 ({}) min_size(s) are provided for ranges".format(len(min_size))

    logger = logging.getLogger(__name__)
    tfm_gens = []
    if is_train:
        tfm_gens.append(T.RandomFlip())
    tfm_gens.append(T.ResizeShortestEdge(min_size, max_size, sample_style))
    if is_train:
        logger.info("TransformGens used in training: " + str(tfm_gens))
    return tfm_gens


@MAPPER_REGISTRY.register()
class OneNetDatasetMapper:
    """
    A callable which takes a dataset dict in Detectron2 Dataset format,
    and map it into a format used by OneNet.

    The callable currently does the following:

    1. Read the image from "file_name"
    2. Applies geometric transforms to the image and annotation
    3. Find and applies suitable cropping to the image and annotation
    4. Prepare image and annotation to Tensors
    """

    def __init__(self, cfg, is_train=True):
        if cfg.INPUT.CROP.ENABLED and is_train:
            self.crop_gen = [
                T.ResizeShortestEdge([400, 500, 600], sample_style="choice"),
                T.RandomCrop(cfg.INPUT.CROP.TYPE, cfg.INPUT.CROP.SIZE),
            ]
        else:
            self.crop_gen = None

        self.tfm_gens = build_transform_gen(cfg, is_train)
        logging.getLogger(__name__).info(
            "Full TransformGens used in training: {}, crop: {}".format(str(self.tfm_gens), str(self.crop_gen))
        )

        self.img_format = cfg.INPUT.FORMAT
        self.is_train = is_train

    def __call__(self, dataset_dict):
        """
        Args:
            dataset_dict (dict): Metadata of one image, in Detectron2 Dataset format.

        Returns:
            dict: a format that builtin models in detectron2 accept
        """
        dataset_dict = copy.deepcopy(dataset_dict)  # it will be modified by code below
        image = utils.read_image(dataset_dict["file_name"], format=self.img_format)
        utils.check_image_size(dataset_dict, image)

        if self.crop_gen is None:
            image, transforms = T.apply_transform_gens(self.tfm_gens, image)
        else:
            if np.random.rand() > 0.5:
                image, transforms = T.apply_transform_gens(self.tfm_gens, image)
            else:
                image, transforms = T.apply_transform_gens(
                    self.tfm_gens[:-1] + self.crop_gen + self.tfm_gens[-1:], image
                )

        image_shape = image.shape[:2]  # h, w

        # Pytorch's dataloader is efficient on torch.Tensor due to shared-memory,
        # but not efficient on large generic data structures due to the use of pickle & mp.Queue.
        # Therefore it's important to use torch.Tensor.
        dataset_dict["image"] = torch.as_tensor(np.ascontiguousarray(image.transpose(2, 0, 1)))

        if not self.is_train:
            # USER: Modify this if you want to keep them for some reason.
            dataset_dict.pop("annotations", None)
            return dataset_dict

        ann_list = []
        if "bbox" in dataset_dict:
            each_dict = dict()
            each_dict["bbox"] = dataset_dict["bbox"][0]
            each_dict["bbox_mode"] = 0
            each_dict["category_id"] = 0  # dataset_dict["category_id"][0]
            each_dict["iscrowd"] = 0
            ann_list.append(each_dict)
        dataset_dict["annotations"] = ann_list

        if "annotations" in dataset_dict:
            # USER: Modify this if you want to keep them for some reason.
            for anno in dataset_dict["annotations"]:
                anno.pop("segmentation", None)
                anno.pop("keypoints", None)

            # USER: Implement additional transformations if you have other types of data
            annos = [
                utils.transform_instance_annotations(obj, transforms, image_shape)
                for obj in dataset_dict.pop("annotations")
                if obj.get("iscrowd", 0) == 0
            ]
            instances = utils.annotations_to_instances(annos, image_shape)
            dataset_dict["instances"] = utils.filter_empty_instances(instances)
        return dataset_dict


@MAPPER_REGISTRY.register()
class WordRecognitionDatasetMapper(DatasetMapper):
    """
    文字识别
    """
    def __init__(self, cfg, is_train=True, image_format="RGB"):
        super(WordRecognitionDatasetMapper, self).__init__(cfg, is_train)
        self.format = image_format
        self.mean = cfg.MODEL.PIXEL_MEAN
        self.std = cfg.MODEL.PIXEL_STD
        self.toTensor = transforms.ToTensor()

    def __call__(self, dataset_dict):
        """
            dataset_dict(dict): 一张图像的元数据
        """
        # 避免后续操作进行修改
        dataset_dict = copy.deepcopy(dataset_dict)

        # 加载文字图像
        src_image = utils.read_image(dataset_dict['file_name'], self.format)
        utils.check_image_size(dataset_dict, src_image)

        # 读取文字识别标签
        label = dataset_dict['utf8_string']

        # TODO： transform
        # aug_pre_input = T.AugInput(pre_image, sem_seg=label)
        src_image, label = src_image, label

        output_dict = dict()
        output_dict['image'] = torch.as_tensor(np.ascontiguousarray(np.transpose(src_image, (2, 0, 1))))
        output_dict['utf8_string'] = label
        output_dict['width'] = dataset_dict['width']
        output_dict['height'] = dataset_dict['height']

        return output_dict


@MAPPER_REGISTRY.register()
class ChangeDetectionDatasetMapper(DatasetMapper):
    """
    变化检测Mapper类
    """
    @configurable
    def __init__(self,
                 is_train: bool,
                 augmentations: List[Union[T.Augmentation, T.Transform]],
                 image_format: str = "RGB"):
        # super(ChangeDetectionDatasetMapper, self).__init__(cfg, is_train)
        self.is_train = is_train
        self.format = image_format
        self.augmentations = T.AugmentationList(augmentations)
        self.logger = setup_logger(name=__name__)
        mode = "training" if is_train else "inference"
        self.logger.info(f"DatasetMapper Augmentations used in {mode}: {augmentations}")

    @classmethod
    def from_config(cls, cfg, is_train: bool = True):
        # 生成transformer pipeline
        augs = build_augmentation(cfg) if is_train else utils.build_augmentation(cfg, False)

        ret = {
            "is_train": is_train,
            "augmentations": augs,
            "image_format": cfg.INPUT.FORMAT,
        }
        return ret

    def __call__(self, dataset_dict):
        """
            dataset_dict(dict): 一张图像的元数据
        """
        # 避免后续操作进行修改
        dataset_dict = copy.deepcopy(dataset_dict)
        # 加载图像
        pre_image = utils.read_image(dataset_dict['file_name'][0], self.format)
        post_image = utils.read_image(dataset_dict['file_name'][1], self.format)

        utils.check_image_size(dataset_dict, pre_image)
        utils.check_image_size(dataset_dict, post_image)

        # 读取变化检测标签
        label = utils.read_image(dataset_dict['change_detection_file_name'], "L").squeeze(2)
        label = np.array(label.copy())
        # label[label < 128] = 0
        # label[label >= 128] = 1
        if label.max() == 255:
            self.logger.warning('The max label value is 255, maybe the label is not in the order 0,1,2...')

        # TODO：transform
        aug_input = T.AugInput(pre_image, sem_seg=label)
        transforms = self.augmentations(aug_input)

        if isinstance(aug_input.image, (list, tuple)):
            pre_image, post_image = aug_input.image[0], aug_input.image[1]
            label = aug_input.sem_seg
        else:
            pre_image, label = aug_input.image, aug_input.sem_seg

        post_image = transforms.apply_image(post_image)
        # ndarray-->tensor
        output_dict = dict()
        output_dict['pre_image'] = torch.as_tensor(np.ascontiguousarray(np.transpose(pre_image, (2, 0, 1))))
        output_dict['post_image'] = torch.as_tensor(np.ascontiguousarray(np.transpose(post_image, (2, 0, 1))))
        output_dict['change_detection'] = torch.as_tensor(label.astype("long"))
        output_dict['width'] = dataset_dict['width']
        output_dict['height'] = dataset_dict['height']

        return output_dict


@MAPPER_REGISTRY.register()
class WordLineDetectionDatasetMapper(DatasetMapper):
    """
    文字检测
    """
    def __init__(self, cfg, is_train=True, image_format="RGB"):
        super(WordLineDetectionDatasetMapper, self).__init__(cfg, is_train)
        self.is_train = is_train
        self.format = image_format
        self.label_size = cfg.MODEL.HEADS.OUT_SIZE
        self.device = torch.device(cfg.MODEL.DEVICE)
        augmentation = build_augmentation(cfg)
        self.augmentations = T.AugmentationList(augmentation)

    def generate_rbox(self, im_size, text_polys, text_tags, training_mask, shrink_ratio):
        """
        生成mask图，白色部分是文本，黑色是北京
        :param im_size: 图像的h,w
        :param text_polys: 框的坐标
        :param text_tags: 标注文本框是否参与训练
        :param training_mask: 忽略标注为 DO NOT CARE 的矩阵
        :return: 生成的mask图
        """
        h, w = im_size
        score_map = np.zeros((h, w), dtype=np.uint8)
        for i, (poly, tag) in enumerate(zip(text_polys, text_tags)):
            try:
                poly = poly.astype(np.int)
                d_i = cv2.contourArea(poly) * (1 - shrink_ratio) / cv2.arcLength(poly, True) + 0.5
                pco = pyclipper.PyclipperOffset()
                pco.AddPath(poly, pyclipper.JT_ROUND, pyclipper.ET_CLOSEDPOLYGON)
                shrinked_poly = np.array(pco.Execute(-d_i))
                cv2.fillPoly(score_map, shrinked_poly, i + 1)
                if not tag:
                    cv2.fillPoly(training_mask, shrinked_poly, 0)
            except:
                print(poly)
        return score_map, training_mask

    def __call__(self, dataset_dict):
        """
            dataset_dict(dict): 一张图像的元数据
        """
        # 避免后续操作进行修改
        dataset_dict = copy.deepcopy(dataset_dict)

        # 加载图像
        image = utils.read_image(dataset_dict['file_name'], self.format)
        utils.check_image_size(dataset_dict, image)

        # 读取行检测标签
        line_box_list = dataset_dict['proposal_line_bboxes']
        text_tags = np.array([1] * len(line_box_list))
        line_box_list = np.array(line_box_list)
        training_mask = np.ones((dataset_dict['height'], dataset_dict['width']),
                                dtype=np.uint8)

        score_maps = []
        for i in (1, 0.5):  # self.shrink_ratio=0.5
            score_map, training_mask = self.generate_rbox(
                (dataset_dict['height'], dataset_dict['width']),
                line_box_list,
                text_tags,
                training_mask,
                i
            )
            score_maps.append(score_map)
        score_maps.append(training_mask)
        label = np.stack(score_maps, axis=2)

        # TODO： transform
        # aug_input = CustomAugInput(image, sem_seg=label)
        # transforms = self.augmentations(aug_input)
        #
        # if isinstance(aug_input.image, (list, tuple)):
        #     image = aug_input.image
        #     label = aug_input.sem_seg
        # else:
        #     image, label = aug_input.image, aug_input.sem_seg
        # 调整图片，使得高和宽都为32的整数倍
        h, w, _ = image.shape
        new_h = (h // 32) * 32
        new_w = (w // 32) * 32
        image = cv2.resize(image, (new_h, new_w))
        label = cv2.resize(label,
                           (int(new_h*self.label_size), int(new_w*self.label_size)))

        # ndarray-->tensor
        output_dict = dict()
        image = image.astype(np.float32)
        image = (image / 255. - 0.588) / 0.193
        image = image.transpose([2, 0, 1])
        output_dict['image'] = torch.from_numpy(image).unsqueeze(0).to(self.device)
        # output_dict['file_name'] = torch.as_tensor(
        #     np.ascontiguousarray(np.transpose(image, (2, 0, 1)))
        # )
        output_dict['proposal_line_bboxes'] = torch.as_tensor(label).unsqueeze(0).to(self.device)
        output_dict['width'] = dataset_dict['width']
        output_dict['height'] = dataset_dict['height']
        output_dict["line_evaluation"] = dataset_dict['line_evaluation']

        return output_dict


@MAPPER_REGISTRY.register()
class WordCharDetectionDatasetMapper(DatasetMapper):
    """
    文字检测
    """
    def __init__(self, cfg, is_train=True, image_format="RGB"):
        super(WordCharDetectionDatasetMapper, self).__init__(cfg, is_train)
        self.is_train = is_train
        self.format = image_format
        self.device = torch.device(cfg.MODEL.DEVICE)
        self.label_size = cfg.MODEL.HEADS.OUT_SIZE
        # augmentation = build_augmentation(cfg)
        # self.augmentations = T.AugmentationList(augmentation)
        from .utils.gaussion import GaussianTransformer
        self.gaussianTransformer = GaussianTransformer(imgSize=1024,
                                                       region_threshold=0.35,
                                                       affinity_threshold=0.15)

    def __call__(self, dataset_dict):
        """
            dataset_dict(dict): 一张图像的元数据
        """
        # 避免后续操作进行修改
        dataset_dict = copy.deepcopy(dataset_dict)

        # 加载图像
        image = utils.read_image(dataset_dict['file_name'], self.format)
        utils.check_image_size(dataset_dict, image)

        # 读取行检测标签
        char_box_list = dataset_dict['proposal_char_bboxes']
        region_scores = np.zeros((dataset_dict['height'], dataset_dict['width']),
                                 dtype=np.float32)

        region_scores = self.gaussianTransformer.generate_region(
            region_scores.shape, char_box_list
        )
        affinity_scores, affinity_bboxes = self.gaussianTransformer.generate_affinity(
                region_scores.shape, char_box_list
            )
        region_scores = region_scores.astype(np.float32)
        region_scores /= 255.
        affinity_scores = affinity_scores.astype(np.float32)
        affinity_scores /= 255.
        training_mask = np.ones((dataset_dict['height'], dataset_dict['width']),
                                dtype=np.float32)

        score_maps = [region_scores, affinity_scores, training_mask]
        label = np.stack(score_maps, axis=2)

        # TODO： transform
        # aug_input = CustomAugInput(image, sem_seg=label)
        # transforms = self.augmentations(aug_input)
        #
        # if isinstance(aug_input.image, (list, tuple)):
        #     image = aug_input.image
        #     label = aug_input.sem_seg
        # else:
        #     image, label = aug_input.image, aug_input.sem_seg
        # 调整图片，使得高和宽都为32的整数倍
        h, w, _ = image.shape
        new_h = (h // 32) * 32
        new_w = (w // 32) * 32
        image = cv2.resize(image, (new_h, new_w))
        label = cv2.resize(label,
                           (int(new_h * self.label_size), int(new_w * self.label_size)))

        # ndarray-->tensor
        output_dict = dict()
        image = image.astype(np.float32)
        image = (image / 255. - 0.588) / 0.193
        image = image.transpose([2, 0, 1])
        output_dict['image'] = torch.from_numpy(image).unsqueeze(0).to(self.device)
        # output_dict['file_name'] = torch.as_tensor(
        #     np.ascontiguousarray(np.transpose(image, (2, 0, 1)))
        # )
        output_dict['proposal_line_bboxes'] = torch.as_tensor(label).unsqueeze(0).to(self.device)
        output_dict['width'] = dataset_dict['width']
        output_dict['height'] = dataset_dict['height']
        output_dict["line_evaluation"] = dataset_dict['line_evaluation']

        return output_dict


@MAPPER_REGISTRY.register()
class IdcardBorderDatasetMapper(DatasetMapper):
    """
    身份证边框检测
    """
    def __init__(self, cfg, is_train=True, image_format="RGB"):
        super(IdcardBorderDatasetMapper, self).__init__(cfg, is_train)
        self.format = image_format
        self.mean = cfg.MODEL.PIXEL_MEAN
        self.std = cfg.MODEL.PIXEL_STD

    def __call__(self, dataset_dict):
        """
            dataset_dict(dict): 一张图像的元数据
        """
        # 避免后续操作进行修改
        dataset_dict = copy.deepcopy(dataset_dict)

        # 加载文字图像
        pre_image = utils.read_image(dataset_dict['file_name'], self.format)
        utils.check_image_size(dataset_dict, pre_image)
        # 需要将所有图片resize到300*300
        pre_image = cv2.resize(pre_image, (320, 320))

        # 读取文字识别标签
        bbox = dataset_dict['bbox']
        category_id = dataset_dict['category_id']

        # TODO： transform
        # aug_pre_input = T.AugInput(pre_image, sem_seg=label)
        pre_image, bbox, category_id = pre_image, bbox, category_id

        # if self.is_train:
        #     # 需要将边框的坐标转化为比例值
        #     bbox = np.array(bbox).astype(np.float32)
        #     bbox[:, 0] = bbox[:, 0]/dataset_dict['width']
        #     bbox[:, 2] = bbox[:, 2]/dataset_dict['width']
        #     bbox[:, 1] = bbox[:, 1]/dataset_dict['height']
        #     bbox[:, 3] = bbox[:, 3]/dataset_dict['height']

        # nd_array-->tensor
        output_dict = dict()
        output_dict['image'] = torch.as_tensor(np.ascontiguousarray(np.transpose(pre_image, (2, 0, 1))))
        output_dict['bbox'] = torch.as_tensor(bbox)
        output_dict['category_id'] = torch.as_tensor(category_id)
        output_dict['width'] = dataset_dict['width']
        output_dict['height'] = dataset_dict['height']

        return output_dict


@MAPPER_REGISTRY.register()
class UnderlineDatasetMapper(DatasetMapper):
    """
    下划线检测
    """
    def __init__(self, cfg, is_train=True, image_format="RGB"):
        super(UnderlineDatasetMapper, self).__init__(cfg, is_train)
        self.format = image_format
        self.mean = cfg.MODEL.PIXEL_MEAN
        self.std = cfg.MODEL.PIXEL_STD

    def draw_poly(self, img, poly, color=(0, 0, 255), string_width=2):
        cv2.line(img, (poly[0][0], poly[0][1]), (poly[1][0], poly[1][1]), color, string_width)
        cv2.line(img, (poly[1][0], poly[1][1]), (poly[2][0], poly[2][1]), color, string_width)
        cv2.line(img, (poly[2][0], poly[2][1]), (poly[3][0], poly[3][1]), color, string_width)
        cv2.line(img, (poly[3][0], poly[3][1]), (poly[0][0], poly[0][1]), color, string_width)
        return img

    def __call__(self, dataset_dict):
        """
            dataset_dict(dict): 一张图像的元数据
        """
        # 避免后续操作进行修改
        dataset_dict = copy.deepcopy(dataset_dict)

        # 加载文字图像
        pre_image = utils.read_image(dataset_dict['file_name'], self.format)
        utils.check_image_size(dataset_dict, pre_image)

        lines_list = dataset_dict["line_polygens"]
        if lines_list != []:
            old_shape = np.array(lines_list).astype(np.int).shape
            lines_list = np.array(lines_list).astype(np.int).reshape((old_shape[0], 4, 2))
            # img = cv2.imread(record["file_name"])
            # img = cv2.imdecode(np.fromfile(dataset_dict["file_name"], dtype=np.uint8), -1)
            label = np.zeros((dataset_dict["height"], dataset_dict["width"]))
            for line in lines_list:
                label = self.draw_poly(label, line, color=255, string_width=4)
        else:
            label = np.zeros((dataset_dict["height"], dataset_dict["width"]))

        # 需要将所有图片resize到300*300
        w, h = pre_image.shape[:2]
        thresh = 600
        if max(w, h) > thresh:
            scale = max(w, h) / thresh
            w, h = int(w / scale), int(h / scale)
            pre_image = cv2.resize(pre_image, (w, h))
            label = cv2.resize(label, (w, h))
        # TODO： transform
        # aug_pre_input = T.AugInput(pre_image, sem_seg=label)
        pre_image, label = pre_image, label

        # ndarray-->tensor
        output_dict = dict()
        # 如果图片为灰度图需要进行处理
        if len(pre_image.shape) == 2:
            pass
        # pre_image = pre_image.astype(np.float32)
        # pre_image = (pre_image / 255. - self.mean) / self.std
        # pre_image = pre_image.transpose([2, 0, 1])
        label = label / 255.
        output_dict['image'] = torch.as_tensor(np.ascontiguousarray(np.transpose(pre_image, (2, 0, 1))))  # torch.from_numpy(pre_image)  # .unsqueeze(0)
        output_dict['line'] = torch.as_tensor(label)  # .unsqueeze(0)
        output_dict['width'] = dataset_dict['width']
        output_dict['height'] = dataset_dict['height']

        return output_dict


@MAPPER_REGISTRY.register()
class CustomDatasetMapper(DatasetMapper):
    """通用数据集mapper，继承自Detectron2自带的DatasetMapper，支持语义分割和coco目标检测
    """    
    @configurable
    def __init__(self,
                 is_train: bool,
                 augmentations: List[Union[T.Augmentation, T.Transform]],
                 image_format: str = "RGB"):
        super().__init__(
            is_train=is_train, 
            augmentations=augmentations,
            image_format=image_format)

    @classmethod
    def from_config(cls, cfg, is_train: bool = True):
        # 生成transformer pipeline
        augs = build_augmentation(cfg) if is_train else utils.build_augmentation(cfg, False)

        ret = {
            "is_train": is_train,
            "augmentations": augs,
            "image_format": cfg.INPUT.FORMAT,
        }
        return ret

    def __call__(self, dataset_dict):
        """
        Args:
            dataset_dict (dict): Metadata of one image, in Detectron2 Dataset format.

        Returns:
            dict: a format that builtin models in detectron2 accept
        """
        dataset_dict = copy.deepcopy(dataset_dict)  # it will be modified by code below
        # USER: Write your own image loading if it's not from a file
        if "file_name" in dataset_dict:
            image = utils.read_image(dataset_dict["file_name"], format=self.image_format)
        elif "np_image" in dataset_dict:  # H x W x C
            image = dataset_dict["np_image"]
        else:
            raise "Image not found"
        utils.check_image_size(dataset_dict, image)

        # USER: Remove if you don't do semantic/panoptic segmentation.
        if "sem_seg_file_name" in dataset_dict:
            sem_seg_gt = utils.read_image(dataset_dict.pop("sem_seg_file_name"), "L").squeeze(2)
        else:
            sem_seg_gt = None

        aug_input = T.AugInput(image, sem_seg=sem_seg_gt)
        transforms = self.augmentations(aug_input)
        image, sem_seg_gt = aug_input.image, aug_input.sem_seg

        image_shape = image.shape[:2]  # h, w

        # Pytorch's dataloader is efficient on torch.Tensor due to shared-memory,
        # but not efficient on large generic data structures due to the use of pickle & mp.Queue.
        # Therefore it's important to use torch.Tensor.
        dataset_dict["image"] = torch.as_tensor(np.ascontiguousarray(image.transpose(2, 0, 1)))
        if "np_image" in dataset_dict:
            dataset_dict.pop("np_image", None)
        if sem_seg_gt is not None:
            dataset_dict["sem_seg"] = torch.as_tensor(sem_seg_gt.astype("long"))

        # USER: Remove if you don't use pre-computed proposals.
        # Most users would not need this feature.
        if self.proposal_topk is not None:
            utils.transform_proposals(
                dataset_dict, image_shape, transforms, proposal_topk=self.proposal_topk
            )

        # if not self.is_train:
        #     # USER: Modify this if you want to keep them for some reason.
        #     dataset_dict.pop("annotations", None)
        #     dataset_dict.pop("sem_seg_file_name", None)
        #     return dataset_dict

        if "annotations" in dataset_dict:
            # USER: Modify this if you want to keep them for some reason.
            for anno in dataset_dict["annotations"]:
                if not self.use_instance_mask:
                    anno.pop("segmentation", None)
                if not self.use_keypoint:
                    anno.pop("keypoints", None)

            # USER: Implement additional transformations if you have other types of data
            annos = [
                utils.transform_instance_annotations(
                    obj, transforms, image_shape, keypoint_hflip_indices=self.keypoint_hflip_indices
                )
                for obj in dataset_dict.pop("annotations")
                if obj.get("iscrowd", 0) == 0
            ]
            instances = utils.annotations_to_instances(
                annos, image_shape, mask_format=self.instance_mask_format
            )

            # After transforms such as cropping are applied, the bounding box may no longer
            # tightly bound the object. As an example, imagine a triangle object
            # [(0,0), (2,0), (0,2)] cropped by a box [(1,0),(2,2)] (XYXY format). The tight
            # bounding box of the cropped triangle should be [(1,0),(2,1)], which is not equal to
            # the intersection of original bounding box and the cropping box.
            if self.recompute_boxes:
                instances.gt_boxes = instances.gt_masks.get_bounding_boxes()
            dataset_dict["instances"] = utils.filter_empty_instances(instances)
        return dataset_dict


if __name__ == "__main__":
    pass
