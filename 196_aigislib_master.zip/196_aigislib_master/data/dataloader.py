
# Copyright (c) Facebook, Inc. and its affiliates.
import logging
import itertools
import torch.utils.data

from detectron2.config import configurable
from detectron2.data.common import DatasetFromList, MapDataset
from detectron2.data.samplers import InferenceSampler, RepeatFactorTrainingSampler, TrainingSampler
from detectron2.data.build import build_batch_data_loader, trivial_batch_collator

from .data_parse import build_data_parse
from .data_mapper import build_data_mapper
"""
This file contains the default logic to build a dataloader for training or testing.
"""

__all__ = [
    "build_train_loader",
    "build_test_loader",
    "get_dataset_dicts",
]


def get_dataset_dicts(names, filter_empty=True, min_keypoints=0, proposal_files=None):
    """
    Load and prepare dataset dicts for instance detection/segmentation and semantic segmentation.

    Args:
        names (str or list[str]): a dataset name or a list of dataset names
        filter_empty (bool): whether to filter out images without instance annotations
        min_keypoints (int): filter out images with fewer keypoints than
            `min_keypoints`. Set to 0 to do nothing.
        proposal_files (list[str]): if given, a list of object proposal files
            that match each dataset in `names`.

    Returns:
        list[dict]: a list of dicts following the standard dataset dict format.
    """
    # 此时的names是一个元组，包含的元素是四个字符串组成的一系列列表
    assert len(names), names
    # 定义一个列表，用于存放解析出来的所有标签数据信息
    dataset_dicts = []
    # 定义一个列表，用于存放所有的数据库名称
    data_name_list = []
    for name in names:
        # 数据库名称
        data_name = name[0]
        # 解析函数名称
        parse_name = name[1]
        # 数据库路径
        data_path = name[2]
        data_parser = build_data_parse(parse_name)
        dataset_dicts.append(data_parser(data_path, data_name))
        # dataset_dicts.append(build_data_parse(parse_name, data_path))
        data_name_list.append(data_name)
    assert len(dataset_dicts), "No valid data found in {}.".format(",".join(names))
    return dataset_dicts, data_name_list


def get_test_dataset_dicts(names, dataset_name):
    for name in names:
        # 数据库名称
        data_name = name[0]
        # 解析函数名称
        parse_name = name[1]
        # 数据库路径
        data_path = name[2]
        if dataset_name == data_name:
            data_parser = build_data_parse(parse_name)
            return data_parser(data_path, data_name)
    return dict()


def _train_loader_from_config(cfg):
    # 解析数据
    dataset_list, data_name_list = get_dataset_dicts(
        cfg.DATASETS.TRAIN,
        filter_empty=cfg.DATALOADER.FILTER_EMPTY_ANNOTATIONS,
        min_keypoints=cfg.MODEL.ROI_KEYPOINT_HEAD.MIN_KEYPOINTS_PER_IMAGE
        if cfg.MODEL.KEYPOINT_ON
        else 0,
        proposal_files=cfg.DATASETS.PROPOSAL_FILES_TRAIN if cfg.MODEL.LOAD_PROPOSALS else None,
    )

    # 将所有解析出来的数据进行合并
    dataset = list(itertools.chain.from_iterable(dataset_list))

    # 从配置文件件中获取map
    mapper = build_data_mapper(cfg.DATASETS.DatasetMapper)(cfg, True)

    sampler_name = cfg.DATALOADER.SAMPLER_TRAIN
    logger = logging.getLogger(__name__)
    logger.info("Using training sampler {}".format(sampler_name))
    if sampler_name == "TrainingSampler":
        sampler = TrainingSampler(len(dataset))
    elif sampler_name == "RepeatFactorTrainingSampler":
        repeat_factors = RepeatFactorTrainingSampler.repeat_factors_from_category_frequency(
            dataset, cfg.DATALOADER.REPEAT_THRESHOLD
        )
        sampler = RepeatFactorTrainingSampler(repeat_factors)
    else:
        raise ValueError("Unknown training sampler: {}".format(sampler_name))

    return {
        "dataset": dataset,
        "sampler": sampler,
        "mapper": mapper,
        "total_batch_size": cfg.SOLVER.IMS_PER_BATCH,
        "aspect_ratio_grouping": cfg.DATALOADER.ASPECT_RATIO_GROUPING,
        "num_workers": cfg.DATALOADER.NUM_WORKERS,
    }


# TODO can allow dataset as an iterable or IterableDataset to make this function more general
@configurable(from_config=_train_loader_from_config)
def build_train_loader(
    dataset, *, mapper, sampler=None, total_batch_size, aspect_ratio_grouping=True, num_workers=0
):
    """
    Build a dataloader for object detection with some default features.
    This interface is experimental.

    Args:
        dataset (list or torch.utils.data.Dataset): a list of dataset dicts,
            or a map-style pytorch dataset. They can be obtained by using
            :func:`DatasetCatalog.get` or :func:`get_detection_dataset_dicts`.
        mapper (callable): a callable which takes a sample (dict) from dataset and
            returns the format to be consumed by the model.
            When using cfg, the default choice is ``DatasetMapper(cfg, is_train=True)``.
        sampler (torch.utils.data.sampler.Sampler or None): a sampler that produces
            indices to be applied on ``dataset``. Default to :class:`TrainingSampler`,
            which coordinates an infinite random shuffle sequence across all workers.
        total_batch_size (int): total batch size across all workers. Batching
            simply puts data into a list.
        aspect_ratio_grouping (bool): whether to group images with similar
            aspect ratio for efficiency. When enabled, it requires each
            element in dataset be a dict with keys "width" and "height".
        num_workers (int): number of parallel data loading workers

    Returns:
        torch.utils.data.DataLoader: a dataloader. Each output from it is a
            ``list[mapped_element]`` of length ``total_batch_size / num_workers``,
            where ``mapped_element`` is produced by the ``mapper``.
    """
    dataset = DatasetFromList(dataset, copy=False)
    dataset = MapDataset(dataset, mapper)
    assert isinstance(sampler, torch.utils.data.sampler.Sampler)
    return build_batch_data_loader(
        dataset,
        sampler,
        total_batch_size,
        aspect_ratio_grouping=aspect_ratio_grouping,
        num_workers=num_workers,
    )


def _test_loader_from_config(cfg, dataset_name):
    """
    Uses the given `dataset_name` argument (instead of the names in cfg), because the
    standard practice is to evaluate each test set individually (not combining them).
    """
    dataset = get_test_dataset_dicts(
        cfg.DATASETS.TEST,
        dataset_name,
    )

    # 从配置文件件中获取map
    mapper = build_data_mapper(cfg.DATASETS.DatasetMapper)(cfg, False)

    return {
        "dataset": dataset,
        "mapper": mapper,
        # "dataset_name": dataset_name,
        "num_workers": 0 #cfg.DATALOADER.NUM_WORKERS
    }


@configurable(from_config=_test_loader_from_config)
def build_test_loader(dataset, *, mapper, num_workers=0):
    """
    Similar to `build_detection_train_loader`, but uses a batch size of 1,
    and :class:`InferenceSampler`. This sampler coordinates all workers to
    produce the exact set of all samples.
    This interface is experimental.

    Args:
        dataset (list or torch.utils.data.Dataset): a list of dataset dicts,
            or a map-style pytorch dataset. They can be obtained by using
            :func:`DatasetCatalog.get` or :func:`get_detection_dataset_dicts`.
        mapper (callable): a callable which takes a sample (dict) from dataset
           and returns the format to be consumed by the model.
           When using cfg, the default choice is ``DatasetMapper(cfg, is_train=False)``.
        num_workers (int): number of parallel data loading workers

    Returns:
        DataLoader: a torch DataLoader, that loads the given detection
        dataset, with test-time transformation and batching.

    Examples:
    ::
        data_loader = build_detection_test_loader(
            DatasetRegistry.get("my_test"),
            mapper=DatasetMapper(...))

        # or, instantiate with a CfgNode:
        data_loader = build_detection_test_loader(cfg, "my_test")
    """
    dataset = DatasetFromList(dataset, copy=False)
    dataset = MapDataset(dataset, mapper)
    sampler = InferenceSampler(len(dataset))

    # Always use 1 image per worker during inference since this is the
    # standard when reporting inference time in papers.
    batch_sampler = torch.utils.data.sampler.BatchSampler(sampler, 1, drop_last=False)
    data_loader = torch.utils.data.DataLoader(
        dataset,
        num_workers=num_workers,
        batch_sampler=batch_sampler,
        collate_fn=trivial_batch_collator,
    )
    return data_loader
