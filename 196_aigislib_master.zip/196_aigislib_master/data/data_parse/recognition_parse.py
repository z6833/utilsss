import os
import glob
import json
import csv
import pathlib
import logging
from PIL import Image
from detectron2.data.catalog import DatasetCatalog
from pycocotools.coco import COCO
import pycocotools.mask as mask_util

from .build import PARSE_REGISTRY

from detectron2.data.datasets import load_coco_json
from detectron2.structures import BoxMode
from detectron2.data import MetadataCatalog
from detectron2.utils.logger import setup_logger


logger = setup_logger(name=__name__)

@PARSE_REGISTRY.register()
def recognition_dataset(path):
    dataset_list = []
    # 判断数据格式
    json_on = False
    lmdb_on = False
    if '.json' in path.split('/')[-1]:
        json_on = True
    else:
        lmdb_on = True
    # lmdb数据格式
    if lmdb_on:
        env = lmdb.open(path, max_readers=32, readonly=True, lock=False, readahead=False, meminit=False)
        with env.begin(write=False) as txn:
            nSamples = int(txn.get('num-samples'.encode()))
            for index in range(nSamples):
                index += 1  # lmdb starts with 1
                label_key = 'label-%09d'.encode() % index
                label = txn.get(label_key).decode('utf-8')
                img_key = 'image-%09d'.encode() % index
                imgbuf = txn.get(img_key)

                buf = six.BytesIO()
                buf.write(imgbuf)
                buf.seek(0)
                img = Image.open(buf).convert('RGB')
    # json数据格式
    if json_on:
        json_path = os.path.join(path)
        dirname_path = "/".join(path.split("/")[:-1])
        with open(json_path, 'r', encoding='utf8') as f:
            data = f.read()
            img_data = json.loads(data)
        for i in img_data['imgs']:
            record = {}
            record["file_name"] = dirname_path + "/" + img_data['imgs'][i]["file_name"]
            record["height"] = img_data['imgs'][i]["height"]
            record["width"] = img_data['imgs'][i]["width"]
            index_num = img_data['imgToAnns'][i][0]
            record["utf8_string"] = img_data['anns'][str(index_num)]["utf8_string"]
            dataset_list.append(record)
    return dataset_list
