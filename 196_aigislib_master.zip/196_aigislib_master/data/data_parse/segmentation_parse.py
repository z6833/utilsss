import os
import glob
import json
import csv
import pathlib
import logging
from PIL import Image
from detectron2.data.catalog import DatasetCatalog
from pycocotools.coco import COCO
import pycocotools.mask as mask_util

from .build import PARSE_REGISTRY

from detectron2.data.datasets import load_coco_json
from detectron2.structures import BoxMode
from detectron2.data import MetadataCatalog
from detectron2.utils.logger import setup_logger


logger = setup_logger(name=__name__)


@PARSE_REGISTRY.register()
def semantic_segmentation_dataset(path, *args):
    """ 语义分割解析函数 """
    # 查找文件
    file_list = os.listdir(path)
    file_path = None
    for file_name in file_list:
        if file_name.endswith('.csv'):
            file_path = os.path.join(path, file_name)
        elif file_name.endswith('.json'):
            file_path = os.path.join(path, file_name)
    if file_path is None:
        raise ValueError("dataset dir not have csv or json file.")

    # 添加list of dict
    dataset_list = []
    with open(file_path, 'r') as f:
        if file_path.endswith('csv'):
            csv_data = csv.reader(f)
            # 跳过头部的header
            header = next(csv_data)
            for i, row in enumerate(csv_data):
                record = {}
                img_path = os.path.join(path, row[0])
                mask_path = os.path.join(path, row[1])
                if not os.path.exists(img_path):
                    print("{} image file not exist!".format(img_path))
                    continue
                if not os.path.exists(mask_path):
                    print("{} mask file not exist!".format(mask_path))
                    continue
                image = Image.open(img_path)
                width, height = image.size[:2]
                record['image_id'] = i
                record['file_name'] = img_path
                record['height'] = height
                record['width'] = width
                record['sem_seg_file_name'] = mask_path
                dataset_list.append(record)
                # 调试代码，1000个样本返回
                # if i >50:
                #     break
    return dataset_list


@PARSE_REGISTRY.register()
def csv_segmentation_dataset(path, dataset_name, **kwargs):
    """ 语义分割解析函数 
    需要的数据目录结构：
    path
    ├── *.csv
    ├── mask_root
    │   ├── 1.png
    │   ├── 2.png
    │   ├── ...
    │
    ├── img_root
    │   ├── 1.jpg
    │   ├── 2.jpg
    │   ├── ...
    csv文件格式：
    第一行为数据集版本、创建者、创建时间等信息，“#”开头
    第二行为类别信息，“#”开头
    后续为图像与标签的路径
    #,version,1,data_creater,2022-03-21 13:43:59.069534
    #,category,水田,1,水浇地,2,旱地,3
    img_root/1.jpg,mask_root/1.png
    img_root/2.jpg,mask_root/2.png
    ...
    标签文件格式：
    mask中各类别像素值应连续，如二分类则使用0和1，三分类则使用0,1,2，以此类推
    mask不可使用有损压缩格式（jpg），建议png或tif
    """
    # 查找文件
    file_list = os.listdir(path)
    file_path = None
    csv_num = 0
    for file_name in file_list:
        if file_name.endswith('.csv'):
            file_path = os.path.join(path, file_name)
            csv_num += 1
    # 若存在多个csv文件直接报错
    if csv_num > 1:
        logger.error(f'There are {csv_num} csv file in {path}, expect 1.')
        raise ValueError(f'There are {csv_num} csv file in {path}, expect 1.')
    if file_path is None:
        raise ValueError(f"There is no csv file in {path}.")

    # 添加list of dict
    dataset_list = []
    classes_names = []
    with open(file_path, 'r') as f:
        csv_data = csv.reader(f)
        for i, row in enumerate(csv_data):
            # 校验表头，分不同版本
            # 版本1："#"开头用以注释类别等信息
            if row[0] == '#':
                # 版本信息，直接打印后跳转到下一行
                if row[1] == 'version':
                    logger.info(' '.join(row))
                    continue
                # 类别信息
                elif row[1] == 'category':
                    # 根据该行的元素数量初始化类别名称list全为background
                    classes_names = ['background' for i in range(len(row)//2)]
                    for i in range(3, len(row), 2):
                        # 若该行已标记0类别的名称，列表长度减去一
                        if int(row[i]) == 0:
                            classes_names.pop()
                        classes_names[int(row[i])] = row[i-1]
                    logger.info(f'Classes names: {" ".join(classes_names)}')
                    continue
                else:
                    continue
            # 版本2：第一行为'file_name', 'sem_seg_file_name'，默认二分类，日志警告
            elif i==0 and row == ['file_name', 'sem_seg_file_name']:
                logger.warning(
                    f'The header {row} is not recommended. The comments should start with #')
                classes_names = ['background','foreground']
                logger.info(f'Classes names: {" ".join(classes_names)}')
                continue
            # 版本3：第一行为类名称，对应mask像素值，从0开始，需要连续；
            # 第二行为'file_name', 'sem_seg_file_name'
            else:
                if i == 0:
                    classes_names = row
                    continue
                if i == 1:
                    assert row == ['file_name', 'sem_seg_file_name']
                    logger.warning(
                        f'The header {row} is not recommended. The comments should start with #')
                    logger.info(f'Classes names: {" ".join(classes_names)}')
                    continue
                   
            # 获取图像和标签的路径
            record = {}
            img_path = os.path.join(path, row[0])
            mask_path = os.path.join(path, row[1])
            if not os.path.exists(img_path):
                logger.warning(f"{img_path} image file not exist!")
                continue
            if not os.path.exists(mask_path):
                logger.warning(f"{mask_path} mask file not exist!")
                continue
            image = Image.open(img_path)
            width, height = image.size[:2]
            record['image_id'] = i
            record['file_name'] = img_path
            record['height'] = height
            record['width'] = width
            record['sem_seg_file_name'] = mask_path
            dataset_list.append(record)

    # 注册数据集 写入元数据
    if dataset_name in DatasetCatalog.list():
        DatasetCatalog.remove(dataset_name)
        logger.info(f'Dataset {dataset_name} has been registered, previous dataset catalog will be removed.')
    DatasetCatalog.register(dataset_name, lambda:dataset_list)
    meta = MetadataCatalog.get(dataset_name)
    meta.stuff_classes = classes_names
    classes_id = [i for i,_ in enumerate(classes_names)]
    meta.stuff_dataset_id_to_contiguous_id = dict(zip(classes_id, classes_id))
    meta.ignore_label = 256
                
    return dataset_list