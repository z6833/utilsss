
# Copyright (c) Facebook, Inc. and its affiliates.
from detectron2.utils.registry import Registry

PARSE_REGISTRY = Registry("DATA_PARSE")
PARSE_REGISTRY.__doc__ = """
Registry for data parse, which parse data from label dataset.

The registered object will be called with `obj(cfg)`.
The call should return a `nn.Module` object.
"""

def build_data_parse(name):
    """
    Build a proposal generator from `cfg.MODEL.PROPOSAL_GENERATOR.NAME`.
    The name can be "PrecomputedProposals" to use no proposal generator.
    """
    return PARSE_REGISTRY.get(name)
