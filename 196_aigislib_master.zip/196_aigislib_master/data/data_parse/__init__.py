from .build import build_data_parse, PARSE_REGISTRY
from .recognition_parse import *
from .detection_parse import *
from .segmentation_parse import *

