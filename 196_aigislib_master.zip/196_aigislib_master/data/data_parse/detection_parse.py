import os
import glob
import json
import csv
import pathlib
import logging
from PIL import Image
from detectron2.data.catalog import DatasetCatalog
from pycocotools.coco import COCO
import pycocotools.mask as mask_util

from .build import PARSE_REGISTRY

from detectron2.data.datasets import load_coco_json
from detectron2.structures import BoxMode
from detectron2.data import MetadataCatalog
from detectron2.utils.logger import setup_logger


logger = setup_logger(name=__name__)


@PARSE_REGISTRY.register()
def object_detection_dataset_1(path, **kwargs):
    """
    目标检测数据集,用于调试目标检测数据parse部分
    path: 自定义数据中json路径
    """
    json_file = pathlib.Path(path)
    # with open(json_file, 'r') as f:
    #     imgs_anns = json.load(f)
    dataset_root = json_file.parent.parent
    if "train" in str(json_file):
        data_path = dataset_root.joinpath("train")
    elif "val" in str(json_file):
        data_path = dataset_root.joinpath("val")
    else:
        raise ValueError("dataset not contain train or val.")

    coco_api = COCO(json_file)
    logging.info("Loading {}".format(json_file))

    cat_ids = sorted(coco_api.getCatIds())
    id_map = {v: i for i, v in enumerate(cat_ids)}
    # 对图像索引进行排序
    img_ids = sorted(coco_api.imgs.keys())
    # 加载图像以及对应的annotations
    imgs = coco_api.loadImgs(img_ids)
    anns = [coco_api.imgToAnns[img_id] for img_id in img_ids]
    imgs_anns = list(zip(imgs, anns))
    logging.info("Loaded {} images in COCO format from {}".format(imgs_anns, json_file))

    dataset_dicts = []
    ann_keys = ["iscrowd", "bbox", "rec", "category_id"]
    num_instances_without_valid_segmentation = 0

    for (img_dict, anno_dict_list) in imgs_anns:
        record = {}

        record["file_name"] = os.path.join(data_path, img_dict["file_name"])
        record["height"] = img_dict["height"]
        record["width"] = img_dict["width"]
        image_id = record["image_id"] = img_dict["id"]

        # 加载每个对象的标注信息
        objs = []
        for anno in anno_dict_list:
            assert anno["image_id"] == image_id
            assert anno.get("ignore", 0) == 0, '"ignore" in COCO json file is not supported.'
            obj = {key: anno[key] for key in ann_keys if key in anno}

            # segmentation
            segm = anns.get("segmentation", None)
            if segm :
                if isinstance(segm, dict):
                    if isinstance(segm.get('counts'), list):
                        segm = mask_util.frPyObjects(segm, *segm["size"])
                else:
                    # 过滤小于3pionts
                    segm = [poly for poly in segm if len(poly) % 2 == 0 and len(poly) >= 6]
                    if len(segm) == 0:
                        num_instances_without_valid_segmentation += 1
                        continue
                obj["segmentation"] = segm

            obj["bbox_mode"] = BoxMode.XYWH_ABS
            if id_map:
                annotation_category_id = obj["category_id"]
                try:
                    obj["category_id"] = id_map[annotation_category_id]
                except KeyError as e:
                    raise KeyError(
                        f"Encountered category_id={annotation_category_id} "
                        "but this id does not exist in 'categories' of the json file."
                    ) from e
            objs.append(obj)
        record["annotations"] = objs
        dataset_dicts.append(record)
    if num_instances_without_valid_segmentation > 0:
        logger.warning(
            "Filtered out {} instances without valid segmentation. ".format(
                num_instances_without_valid_segmentation
            )
            + "There might be issues in your dataset generation process. "
              "A valid polygon should be a list[float] with even length >= 6."
        )
    print(len(dataset_dicts))
    print(dataset_dicts[0]['height'])
    print(dataset_dicts[0]['annotations'])
    return dataset_dicts


@PARSE_REGISTRY.register()
def change_detection_dataset(path, **kwargs):
    """ 变化检测解析函数 """
    # 查找文件
    if path.endswith(".csv"):
        csv_file = path
    else:
        raise FileNotFoundError("csv file not found!")

    dataset_list = []
    with open(csv_file, 'r') as f:
        csv_data = csv.reader(f)

        for row in csv_data:
            record = {}
            pre_img_name = row[0]
            post_img_name = row[1]
            # 将前后时相打包为一个具名元组
            # FileName = namedtuple('FileName', ['pre_image', 'post_image'])
            # filename = FileName(pre_img_name, post_img_name)
            # 使用Image获取图片的状态信息
            pre_img = Image.open(pre_img_name)
            width, height = pre_img.size[:2]

            record["file_name"] = (pre_img_name, post_img_name)
            record["height"] = height
            record["width"] = width
            record["change_detection_file_name"] = row[2]

            dataset_list.append(record)

    return dataset_list


@PARSE_REGISTRY.register()
def word_detection_dataset(path):
    dataset_list = []
    json_path = os.path.join(path, 'synthpdf1.json')
    json_content = json.load(open(json_path, 'r'))
    for i in json_content['imgs']:
        record = {}
        record["file_name"] = path + '/' + json_content['imgs'][i]["file_name"]
        record["height"] = json_content['imgs'][i]["height"]
        record["width"] = json_content['imgs'][i]["width"]
        lines_list = []
        chars_list = []
        lines_evaluate_list = []
        for j in json_content['imgToAnns'][i]:
            lines_list.append(json_content['anns'][str(j)]["polygon"])
            chars_list.append(json_content['anns'][str(j)]["cbbox"])
            line_evaluate = {
                'points': json_content['anns'][str(j)]["polygon"],
                'ignore': False,
            }
            lines_evaluate_list.append(line_evaluate)
        record["proposal_line_bboxes"] = lines_list
        record["proposal_char_bboxes"] = chars_list
        record["line_evaluation"] = lines_evaluate_list
        dataset_list.append(record)

    return dataset_list


@PARSE_REGISTRY.register()
def idcard_border_dataset(path):
    dataset_list = []
    json_path = os.path.join(path, 'idcard.json')
    json_content = json.load(open(json_path, 'r'))
    for i in json_content['imgs']:
        record = {}
        record["file_name"] = path + '/' + json_content['imgs'][i]["file_name"]
        record["height"] = json_content['imgs'][i]["height"]
        record["width"] = json_content['imgs'][i]["width"]
        boxes_list = []
        labels_list = []
        for j in json_content['imgToAnns'][i]:
            boxes_list.append(json_content['anns'][str(j)]["bbox"])
            labels_list.append(1)
        record["bbox"] = boxes_list
        record["category_id"] = labels_list
        dataset_list.append(record)

    return dataset_list


@PARSE_REGISTRY.register()
def underline_detection_dataset(path):
    dataset_list = []
    for json_path in glob.glob(path + '/anns/*.json'):
        json_content = json.load(open(json_path, 'r'))
        for num, i in enumerate(json_content['imgs']):
            record = {}
            record["file_name"] = path + '/images/' + json_content['imgs'][i]["file_name"]
            record["height"] = json_content['imgs'][i]["height"]
            record["width"] = json_content['imgs'][i]["width"]
            lines_list = []
            for j in json_content['imgToAnns'][i]:
                if json_content['anns'][str(j)]["class"] == 'line':
                    lines_list.append(json_content['anns'][str(j)]["polygon"])
            record["line_polygens"] = lines_list
            dataset_list.append(record)

    return dataset_list


@PARSE_REGISTRY.register()
def coco_detection_dataset(path, dataset_name, **kwargs):
    """
    COCO格式数据集读取，使用内置函数，支持目标检测
    需要的数据目录结构：
    path
    ├── *.json    要求只有一个
    ├── img_root  要求只有一个
    │   ├── 1.jpg
    │   ├── 2.jpg
    │   ├── ...
    json文件为coco格式，其中file_name字段需要提供相对path的图片路径，而非原始coco格式中的文件名
    """
    # 查找文件
    file_list = os.listdir(path)
    file_path = None
    json_num = 0
    folder_list = []
    for file_name in file_list:
        if file_name.endswith('.json'):
            file_path = os.path.join(path, file_name)
            json_num += 1
        else:
            folder_list.append(file_name)
    # 若存在多个json文件直接报错
    if json_num > 1:
        logger.error(f'There are {json_num} json file in {path}, expect 1.')
        raise ValueError(f'There are {json_num} json file in {path}, expect 1.')
    if file_path is None:
        raise ValueError(f"There is no json file in {path}.")

    # 若存在多个文件夹直接报错
    folder_num = len(folder_list)
    if folder_num > 1:
        logger.error(f'There are {folder_num} folder in {path}, expect 1.')
        raise ValueError(f'There are {folder_num} folder in {path}, expect 1.')
    if folder_num == 0:
        raise ValueError(f"There is no folder in {path}.")
    
    # coco原始数据集中file_name字段仅包含图片名信息，因此load_coco_json需要图片根目录参数
    # 此处需要的coco格式数据集file_name字段包含图片的相对路径
    json_file = pathlib.Path(file_path)
    dir_name = folder_list[0]
    #
    if dir_name.startswith("train") or dir_name.startswith("val"):
        image_root = os.path.join(path, folder_list[0])
    else:
        image_root = path
    dataset_list = load_coco_json(json_file, image_root, dataset_name=dataset_name)
    if dataset_name in DatasetCatalog.list():
        DatasetCatalog.remove(dataset_name)
        logger.info(f'Dataset {dataset_name} has been registered, previous dataset catalog will be removed.')
    DatasetCatalog.register(dataset_name, lambda: dataset_list)
    meta = MetadataCatalog.get(dataset_name)
    meta.json_file = json_file
    
    return dataset_list


@PARSE_REGISTRY.register()
def csv_change_detection_dataset(path, dataset_name, **kwargs):
    """变化检测解析函数
    需要的数据目录结构：
    path
    ├── *.csv
    ├── label_root
    │   ├── 1.png
    │   ├── 2.png
    │   ├── ...
    │
    ├── t1_img_root
    │   ├── 1.jpg
    │   ├── 2.jpg
    │   ├── ...
    ├── t2_img_root
    │   ├── 1.jpg
    │   ├── 2.jpg
    │   ├── ...
    csv文件格式：
    第一行为数据集版本、创建者、创建时间等信息，“#”开头
    第二行为类别信息，“#”开头
    后续为前时相、后时相图像与标签的路径
    #,version,1,data_creater,2022-03-21 13:43:59.069534
    #,category,水田,1,水浇地,2,旱地,3
    t1_img_root/1.jpg,t2_img_root/1.jpg,label_root/1.png
    t1_img_root/2.jpg,t2_img_root/2.jpg,label_root/2.png
    ...
    标签文件格式：
    label中各类别像素值应连续，如二分类则使用0和1，三分类则使用0,1,2，以此类推
    label不可使用有损压缩格式（jpg），建议png或tif

    Args:
        path (str): 数据集的路径，路径下应有csv文件
        dataset_name (str): 数据集的名称

    Returns:
        list: 解析完成，传递给mapper的dict list
    """        
    # 查找文件
    file_list = os.listdir(path)
    csv_file = None
    csv_num = 0
    for file_name in file_list:
        if file_name.endswith('.csv'):
            csv_file = os.path.join(path, file_name)
            csv_num += 1
    # 若存在多个csv文件直接报错
    if csv_num > 1:
        logger.error(f'There are {csv_num} csv file in {path}, expect 1.')
        raise ValueError(f'There are {csv_num} csv file in {path}, expect 1.')
    if csv_file is None:
        raise ValueError(f"There is no csv file in {path}.")

    dataset_list = []
    classes_names = []

    with open(csv_file, 'r') as f:
        csv_data = csv.reader(f)
        for i, row in enumerate(csv_data):
            # 版本1："#"开头用以注释类别等信息
            if row[0] == '#':
                # 版本信息，直接打印后跳转到下一行
                if row[1] == 'version':
                    logger.info(' '.join(row))
                    continue
                # 类别信息
                elif row[1] == 'category':
                    # 根据该行的元素数量初始化类别名称list全为unchanged
                    classes_names = ['unchanged' for i in range(len(row)//2)]
                    for i in range(3, len(row), 2):
                        # 若该行已标记0类别的名称，列表长度减去一
                        if int(row[i]) == 0:
                            classes_names.pop()
                        classes_names[int(row[i])] = row[i-1]
                    logger.info(f'Classes names: {" ".join(classes_names)}')
                    continue
                else:
                    continue

            elif i == 0:
                # 检查表头
                # 若无表头直接为路径，则类别标记为两类
                if '.' in ''.join(row):
                    classes_names = ['unchanged', 'changed']
                    logger.info(f'Classes names: {" ".join(classes_names)}')
                # 表头第一行为类别名，第二行为类名
                else:
                    classes_names = row
                    header = next(csv_data)
                    assert header == ['pre_image', 'post_image', 'label']
                    logger.info(f'Classes names: {" ".join(classes_names)}')
                    logger.warning(
                        f'The header {header} is not recommended. The comments should start with #')
                    continue
                
            record = {}
            pre_img_name = os.path.join(path, row[0]) 
            post_img_name = os.path.join(path, row[1])
            # 使用Image获取图片的状态信息
            pre_img = Image.open(pre_img_name)
            width, height = pre_img.size[:2]
            
            record["file_name"] = (pre_img_name, post_img_name)
            record["height"] = height
            record["width"] = width
            record["change_detection_file_name"] = os.path.join(path, row[2])

            dataset_list.append(record)
    # 注册数据集 写入元数据
    if dataset_name in DatasetCatalog.list():
        DatasetCatalog.remove(dataset_name)
        logger.info(f'Dataset {dataset_name} has been registered, previous dataset catalog will be removed.')
    DatasetCatalog.register(dataset_name, lambda:dataset_list)
    meta = MetadataCatalog.get(dataset_name)
    meta.stuff_classes = classes_names
    classes_id = [i for i, _ in enumerate(classes_names)]
    meta.stuff_dataset_id_to_contiguous_id = dict(zip(classes_id, classes_id))
    meta.ignore_label = 256

    return dataset_list
