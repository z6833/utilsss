import random
import numpy as np
from detectron2.data import transforms as T
from detectron2.data.transforms import Transform, NoOpTransform
from detectron2.data.transforms.augmentation import Augmentation

from .transform_impl import ChannelShuffleTransform, ColorJitterTransform, \
    GaussianBlurTransform, RandomFogTransform, SharpenTransform, GaussNoiseTransform, \
        MediaBlurTransform, HueSaturationValueTransform
from ..transformer.build import TRANSFORMS

# detectron2自带变换方式
# 几何变换
# TRANSFORMS.register(T.Resize)
# TRANSFORMS.register(T.ResizeShortestEdge)
# TRANSFORMS.register(T.ResizeScale)
# TRANSFORMS.register(T.RandomRotation)
# TRANSFORMS.register(T.RandomCrop)
TRANSFORMS.register(T.RandomFlip)
# 非几何变换
TRANSFORMS.register(T.RandomContrast)
TRANSFORMS.register(T.RandomLighting)
TRANSFORMS.register(T.RandomBrightness)
TRANSFORMS.register(T.RandomSaturation)


@TRANSFORMS.register()
class GaussianBlur(Augmentation):
    def __init__(self, kernel_size=3, sigma=0, prob=1.0) -> None:
        """高斯模糊变换

        Args:
            kernel_size (int or tuple of int): 高斯核的大小，可指定大小或范围，必须为零或奇数且在 [0, inf) 范围内
            sigma (float or tuple of float): 高斯分布标准差，可指定大小或范围，必须在 [0, inf) 范围内
            prob (float, optional): 应用变换的概率. Defaults to 1.
        """               
        super().__init__()
        if isinstance(kernel_size, int):
            kernel_size = (kernel_size, kernel_size)
        if isinstance(sigma, (int, float)):
            sigma = (sigma, sigma)
        self.kernel_size = kernel_size
        self.sigma = sigma
        self.prob = prob

    def get_transform(self, image) -> Transform:
        if random.random() < self.prob:
            kernel_size_value = random.randint(*self.kernel_size)
            if kernel_size_value != 0 and kernel_size_value % 2 != 1:
                kernel_size_value = (kernel_size_value + 1) % (self.kernel_size[1] + 1)
            sigma_value = random.uniform(*self.sigma)
            return GaussianBlurTransform(kernel_size_value, sigma_value)
        else:
            return NoOpTransform()


@TRANSFORMS.register()
class MedianBlur(Augmentation):
    def __init__(self, kernel_size=3, prob=1.0, distribution='uniform') -> None:
        """中值滤波模糊变换

        Args:
            kernel_size (int or tuple of int): 高斯核的大小，可指定大小或范围，必须是奇数且在 [3, inf) 范围内
            prob (float, optional): 应用变换的概率. Defaults to 1.
            distribution (str): （未实现）核大小范围的分布. Defaults to 'uniform'.
        """               
        super().__init__()
        if isinstance(kernel_size, int):
            kernel_size = (kernel_size, kernel_size)
        self.kernel_size = kernel_size
        self.prob = prob

    def get_transform(self, image) -> Transform:
        if random.random() < self.prob:
            kernel_size_value = random.randint(*self.kernel_size)
            if kernel_size_value != 0 and kernel_size_value % 2 != 1:
                kernel_size_value = (kernel_size_value + 1) % (self.kernel_size[1] + 1)
            return MediaBlurTransform(kernel_size_value)
        else:
            return NoOpTransform()


@TRANSFORMS.register()
class ColorJitter(Augmentation):
    def __init__(self, brightness=0.2, contrast=0.2, saturation=0.2, hue=0.2, prob=1.0) -> None:
        """颜色抖动变换

        Args:
            brightness (float or tuple of float): 亮度抖动的幅度或范围，必须在 [0, inf) 范围内
            contrast (float or tuple of float): 对比度抖动的幅度或范围，必须在 [0, inf) 范围内
            saturation (float or tuple of float): 饱和度抖动的幅度或范围，必须在 [0, inf) 范围内
            hue (float or tuple of float): 色调抖动的幅度或范围，范围[-0.5, 0.5]
            prob (float, optional): 应用变换的概率. Defaults to 1.
        """        
        super().__init__()
        if isinstance(brightness, (int, float)):
            brightness = (brightness, brightness)
        if isinstance(contrast, (int, float)):
            contrast = (contrast, contrast)
        if isinstance(saturation, (int, float)):
            saturation = (saturation, saturation)
        if isinstance(hue, (int, float)):
            hue = (hue, hue)
        self.brightness = brightness
        self.contrast = contrast
        self.saturation = saturation
        self.hue = hue
        self.prob = prob

    def get_transform(self, image) -> Transform:
        if random.random() < self.prob:
            brightness_value = random.uniform(*self.brightness)
            contrast_value = random.uniform(*self.contrast)
            saturation_value = random.uniform(*self.saturation)
            hue_value = random.uniform(*self.hue)
            return ColorJitterTransform(
                brightness_value, 
                contrast_value,
                saturation_value,
                hue_value
                )
        else:
            return NoOpTransform()


@TRANSFORMS.register()
class HueSaturationValue(Augmentation):
    def __init__(self, hue=20, saturation=20, value=20, prob=1.0) -> None:
        """随机改变输入图像的色调、饱和度和明度值

        Args:
            hue (int or tuple of int): 色调变化值或范围，大小无限制，但实际变化存在上下限
            saturation (int or tuple of int): 饱和度变化值或范围，大小无限制，但实际变化存在上下限
            value (int or tuple of int): 明度变化值或范围，大小无限制，但实际变化存在上下限
            prob (float, optional): 应用变换的概率. Defaults to 1.0.
        """                   
        super().__init__()
        if isinstance(hue, int):
            hue = (hue, hue)
        if isinstance(saturation, int):
            saturation = (saturation, saturation)
        if isinstance(value, int):
            value = (value, value)

        self.hue = hue
        self.saturation = saturation
        self.value = value
        self.prob = prob

    def get_transform(self, image) -> Transform:
        if random.random() < self.prob:
            hue_value = random.randint(*self.hue)
            saturation_value = random.randint(*self.saturation)
            value_value = random.randint(*self.value)
            return HueSaturationValueTransform(hue_value, saturation_value, value_value)
        else:
            return NoOpTransform()


@TRANSFORMS.register()
class Sharpen(Augmentation):
    def __init__(self, alpha=0.5, lightness=0.5, prob=1.0) -> None:
        """锐化图像并将结果与原图叠加

        Args:
            alpha (float or tuple of float): 叠加锐化图像的可见性占比，范围为[0,1]，在 0 时，只有原始图像可见，在 1.0 时，只有它的锐化版本可见
            lightness (float or tuple of float): 锐化图像的亮度，无大小限制
            prob (float, optional): 应用变换的概率. Defaults to 1.0.
        """        
        super().__init__()
        if isinstance(alpha, float):
            alpha = (alpha, alpha)
        if isinstance(lightness, (int, float)):
            lightness = (lightness, lightness)

        self.alpha = alpha
        self.lightness = lightness
        self.prob = prob

    def get_transform(self, image) -> Transform:
        if random.random() < self.prob:
            alpha_value = random.uniform(*self.alpha)
            lightness_value = random.uniform(*self.lightness)
            return SharpenTransform(alpha_value, lightness_value)
        else:
            return NoOpTransform()


@TRANSFORMS.register()
class ChannelShuffle(Augmentation):
    def __init__(self, prob=1.0) -> None:
        """随机重新排列RGB通道

        Args:
            prob (float, optional): 应用变换的概率. Defaults to 1.0.
        """             
        super().__init__()
        self.prob = prob

    def get_transform(self, image) -> Transform:
        if random.random() < self.prob:
            ch_arr = list(range(image.shape[2]))
            random.shuffle(ch_arr)
            return ChannelShuffleTransform(ch_arr)
        else:
            return NoOpTransform()


@TRANSFORMS.register()
class GaussNoise(Augmentation):
    def __init__(self, variance=10, mean=0, per_channel=True, prob=1.0) -> None:
        """为图像添加高斯噪声

        Args:
            variance (float or tuple of float): 高斯噪声的方差，无大小限制
            mean (float): 高斯噪声的平均值，无大小限制
            per_channel (bool, optional): 对每个通道独立采样噪声，若为False则对所有通道一次采样. Defaults to True.
            prob (float, optional): 应用变换的概率. Defaults to 1.0.
        """                   
        super().__init__()
        if isinstance(variance, (int, float)):
            variance = (variance, variance)
        self.variance = variance
        self.mean = mean
        self.per_channel = per_channel
        self.prob = prob

    def get_transform(self, image) -> Transform:
        if random.random() < self.prob:
            variance_value = random.uniform(*self.variance)
            random_state = np.random.RandomState(random.randint(0, 2 ** 32 - 1))
            return GaussNoiseTransform(variance_value, self.mean, self.per_channel, random_state)
        else:
            return NoOpTransform()


@TRANSFORMS.register()
class RandomFog(Augmentation):
    def __init__(self, fog_coef=0.5, alpha=0.5,  prob=1.0) -> None:
        """随机增加模拟雾效果

        Args:
            fog_coef (float or tuple of float): 雾的强度系数，范围为[0, 1]
            alpha (float)): 雾圈的透明度，范围为[0, 1]
            prob (float, optional): 应用变换的概率. Defaults to 1.0.
        """                   
        super().__init__()
        if isinstance(fog_coef, (int, float)):
            fog_coef = (fog_coef, fog_coef)
        self.fog_coef = fog_coef
        self.alpha = alpha
        self.prob = prob

    def get_transform(self, image) -> Transform:
        if random.random() < self.prob:
            fog_coef_value = random.uniform(*self.fog_coef)
            height, width = imshape = image.shape[:2]

            hw = max(1, int(width // 3 * fog_coef_value))

            haze_list = []
            midx = width // 2 - 2 * hw
            midy = height // 2 - hw
            index = 1

            while midx > -hw or midy > -hw:
                for _i in range(hw // 10 * index):
                    x = random.randint(midx, width - midx - hw)
                    y = random.randint(midy, height - midy - hw)
                    haze_list.append((x, y))

                midx -= 3 * hw * width // sum(imshape)
                midy -= 3 * hw * height // sum(imshape)
                index += 1
            return RandomFogTransform(fog_coef_value, self.alpha, haze_list)
        else:
            return NoOpTransform()

