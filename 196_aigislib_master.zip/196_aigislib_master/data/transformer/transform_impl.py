import numpy as np
from albumentations.augmentations import functional as F
from detectron2.data.transforms import ColorTransform

# 调用albumentations底层函数
class GaussianBlurTransform(ColorTransform):
    def __init__(self, kernel_size=3, sigma=1):
        self.kernel_size = kernel_size
        self.sigma = sigma

    def op(self, img):
        return F.gaussian_blur(img, ksize=self.kernel_size, sigma=self.sigma)


class MediaBlurTransform(ColorTransform):
    def __init__(self, kernel_size=3):
        self.kernel_size = kernel_size

    def op(self, img):
        return F.median_blur(img, ksize=self.kernel_size)


class ColorJitterTransform(ColorTransform):
    def __init__(self, brightness=0.2, contrast=0.2, saturation=0.2, hue=0.2):
        self.brightness = brightness
        self.contrast = contrast
        self.saturation = saturation
        self.hue = hue

    def op(self, img):
        transforms = [
            lambda x: F.adjust_brightness_torchvision(x, self.brightness),
            lambda x: F.adjust_contrast_torchvision(x, self.contrast),
            lambda x: F.adjust_saturation_torchvision(x, self.saturation),
            lambda x: F.adjust_hue_torchvision(x, self.hue),
        ]
        for transform in transforms:
            img = transform(img)
        return img


class HueSaturationValueTransform(ColorTransform):
    def __init__(self, hue=20, saturation=20, value=20):
        self.hue = hue
        self.saturation = saturation
        self.value = value
        
    def op(self, img):
        return F.shift_hsv(img, self.hue, self.saturation, self.value)


class SharpenTransform(ColorTransform):
    def __init__(self, alpha=0.2, lightness=0.5):
        self.alpha = alpha
        self.lightness = lightness

    @staticmethod
    def __generate_sharpening_matrix(alpha_sample, lightness_sample):
        matrix_nochange = np.array([[0, 0, 0], [0, 1, 0], [0, 0, 0]], dtype=np.float32)
        matrix_effect = np.array(
            [[-1, -1, -1], [-1, 8 + lightness_sample, -1], [-1, -1, -1]],
            dtype=np.float32,
        )

        matrix = (1 - alpha_sample) * matrix_nochange + alpha_sample * matrix_effect
        return matrix

    def op(self, img):
        sharpening_matrix = self.__generate_sharpening_matrix(self.alpha, self.lightness)
        return F.convolve(img, sharpening_matrix)


class ChannelShuffleTransform(ColorTransform):
    def __init__(self, ch_arr=(0, 1, 2)):
        self.ch_arr = ch_arr

    def op(self, img):
        return F.channel_shuffle(img, self.ch_arr)


class GaussNoiseTransform(ColorTransform):
    def __init__(self, variance=10, mean=0, per_channel=True, random_state=None):
        self.variance = variance
        self.mean = mean
        self.per_channel = per_channel
        self.random_state = random_state

    def op(self, img):
        sigma = self.variance ** 0.5
        if self.per_channel:
            gauss = self.random_state.normal(self.mean, sigma, img.shape)
        else:
            gauss = self.random_state.normal(self.mean, sigma, img.shape[:2])
            if len(img.shape) == 3:
                gauss = np.expand_dims(gauss, -1)
        return F.gauss_noise(img, gauss=gauss)


class RandomFogTransform(ColorTransform):
    def __init__(self, fog_coef, alpha, haze_list):
        self.fog_coef = fog_coef
        self.alpha = alpha
        self.haze_list = haze_list

    def op(self, img):
        return F.add_fog(img, self.fog_coef, self.alpha, self.haze_list)