from detectron2.utils.registry import Registry
from fvcore.transforms.transform import TransformList
TRANSFORMS = Registry("transforms")

TRANSFORMS.__doc__ = """
Registry for Transformers.

The registered object will be called with `obj(cfg)`.
The call should return a `Transformer` object.
"""


def build_augmentation(cfg):
    """
    从cfg中创建TransformGen的列表
    """
    pipelines = cfg.AUGMENTATION

    transform_generator = []
    if isinstance(pipelines, dict):
        # 从yaml文件获取对应的augmentation
        for tfm_name, args in pipelines.items():
            tfm = TRANSFORMS.get(tfm_name)(**args)
            transform_generator.append(tfm)
    if isinstance(pipelines, (list, tuple)):
        # 获取augmentation列表，格式为[{'NAME': tfm_name, 'ARGS': {arg1: arg1, ...}},...]
        for tfm_dict in pipelines:
            tfm_name = tfm_dict['NAME']
            args = tfm_dict['ARGS']
            tfm = TRANSFORMS.get(tfm_name)(**args)
            transform_generator.append(tfm)
    else:
        raise ValueError("transformer's format in config is wrong.")

    return transform_generator









