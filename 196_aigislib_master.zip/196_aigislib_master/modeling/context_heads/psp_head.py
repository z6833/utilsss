import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Union, List, Tuple

from detectron2.config import configurable
from ..builder import HEADS


class PPM(nn.ModuleList):
    """ 空间金字塔池化最小结构 """
    def __init__(self,
                 pool_scales: Union[List, Tuple],
                 in_channels: int,
                 channels: int,
                 ):
        super(PPM, self).__init__()
        self.pool_scales = pool_scales
        self.in_channels = in_channels
        self.channels = channels

        for pool_scale in pool_scales:
            self.append(
                nn.Sequential(
                    nn.AdaptiveAvgPool2d(pool_scale),
                    nn.Conv2d(self.in_channels, self.channels, kernel_size=1)
                )
            )

    def forward(self, inputs):
        ppm_outs = []
        for ppm in self:
            ppm_out = ppm(inputs)
            upsample_ppm_out = F.interpolate(ppm_out, size=inputs.size()[2:],
                                             mode='bilinear', align_corners=True)
            ppm_outs.append(upsample_ppm_out)
        return ppm_outs


@HEADS.register()
class PPMHead(nn.Module):
    """ 金字塔池化模块 """
    @configurable
    def __init__(self,
                 in_channels: Union[List[int], int],
                 out_channels: int,
                 pool_scales: List
                 ):
        super(PPMHead, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.bins = pool_scales

        self.psp_module = PPM(self.bins, self.in_channels[-1], self.out_channels)
        self.bottleneck = nn.Conv2d(self.in_channels[-1] + self.out_channels * len(self.bins),
                                    self.out_channels, kernel_size=1, stride=1, bias=False)
        self.relu = nn.ReLU(inplace=True)

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.HEADS.IN_CHANNELS,
            out_channels=cfg.MODEL.HEADS.OUT_CHANNELS,
            pool_scales=cfg.MODEL.HEADS.POOL_SCALES,
        )
        return ret

    def forward(self, inputs):
        if isinstance(inputs, (list, tuple)):
            inputs = inputs[-1]
        h, w = inputs.size(2), inputs.size(3)
        psp_outs = [inputs]
        # 输入特征结合池化特征
        psp_outs.extend(self.psp_module(inputs))
        out = torch.cat(psp_outs, dim=1)
        out = self.bottleneck(out)

        return self.relu(out)
