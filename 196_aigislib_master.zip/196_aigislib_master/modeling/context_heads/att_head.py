import torch
import torch.nn as nn
import torch.nn.functional as F
from ..builder import HEADS


@HEADS.register()
class SelfAttentionBlock(nn.Module):
    """ 自注意力模块
        类似transformer中self-attention
    """
    def __init__(self, in_channels, key_channels, value_channels, out_channels):
        """

        :param in_channels: 输入通道数
        :param key_channels: 关键值通道数
        :param value_channels: 值通道
        :param out_channels: 输出通道数
        """
        super(SelfAttentionBlock, self).__init__()
        self.key_channels = key_channels
        self.value_channels = value_channels
        self.out_channels = out_channels

        self.f_key = nn.Sequential(
            nn.Conv2d(in_channels, key_channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(key_channels),
        )
        self.f_query = self.f_key
        self.f_value = nn.Sequential(
            nn.Conv2d(in_channels, value_channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(value_channels),
        )
        self.softmax = nn.Softmax(dim=-1)
        self.W = nn.Conv2d(value_channels, out_channels, kernel_size=1, stride=1)

    def forward(self, feat):
        batch, channel, height, weight = feat.size()

        value = self.f_value(feat).view(batch, self.value_channels, -1)     # (b, v, h*w)
        value = value.permute(0, 2, 1)      # (b, h*w, v)
        query = self.f_query(feat).view(batch, self.key_channels, -1)
        query = query.permute(0, 2, 1)      # (b, h*w, k)
        key = self.f_key(feat).view(batch, self.key_channels, -1)           # (b, k, h*w)

        # matric multiply
        sim_map = torch.matmul(query, key)          # (b, h*w, h*w)
        sim_map = sim_map * (self.key_channels ** -.5)
        sim_map = self.softmax(sim_map)

        context = torch.matmul(sim_map, value)      # (b, h*w, v)
        context = context.permute(0, 2, 1).contiguous()
        context = context.view(batch, self.value_channels, height, weight)
        context = self.W(context)

        return context