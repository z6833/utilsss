
import torch
import torch.nn as nn
import torch.nn.functional as F
from fvcore.nn import sigmoid_focal_loss_jit
from detectron2.config import configurable
from detectron2.config import CfgNode as CN
from detectron2.layers import cat
from detectron2.structures import Instances, Boxes
from detectron2.config.defaults import _C

from ..builder import HEADS
from .basehead import BoxBaseHead, BaseMatch
from .utils.comm import reduce_mean, compute_ious, ml_nms
from ..utils.data_structrue import TensorPackage

INF = 100000000


class IOULoss(nn.Module):
    """
    Intersection Over Union (IoU) loss which supports three different IoU computations:

    * IoU
    * Linear IoU
    * gIoU
    """
    def __init__(self, loc_loss_type='iou'):
        super(IOULoss, self).__init__()
        self.loc_loss_type = loc_loss_type

    def forward(self, ious, gious=None, weight=None):
        if self.loc_loss_type == 'iou':
            losses = -torch.log(ious)
        elif self.loc_loss_type == 'linear_iou':
            losses = 1 - ious
        elif self.loc_loss_type == 'giou':
            assert gious is not None
            losses = 1 - gious
        else:
            raise NotImplementedError

        if weight is not None:
            return (losses * weight).sum()
        else:
            return losses.sum()


@HEADS.register()
class FCOSHead(nn.Module):
    @configurable
    def __init__(self,
                 in_channels,
                 num_classes,
                 num_share_con,
                 num_cls_con,
                 num_reg_con,
                 prior_prob,
                 sizes_of_interest,
                 focal_loss_alpha,
                 focal_loss_gamma,
                 loss_weight_cls,
                 loss_weight_reg,
                 loss_weight_ctr,
                 loc_loss_func,
                 pre_nms_thresh_train,
                 pre_nms_topk_train,
                 post_nms_topk_train,
                 pre_nms_thresh_test,
                 pre_nms_topk_test,
                 post_nms_topk_test,
                 nms_thresh,
                 strides,
                 ):
        super().__init__()
        assert len(set(in_channels)) == 1, '多级特征映射需要有相同的通道数量'
        self.in_channel = in_channels[0]
        self.num_classes = num_classes
        self.num_share_con = num_share_con
        self.num_cls_con = num_cls_con
        self.num_reg_con = num_reg_con
        self.prior_prob = prior_prob

        self.sizes_of_interest = sizes_of_interest
        self.focal_loss_alpha = focal_loss_alpha
        self.focal_loss_gamma = focal_loss_gamma
        self.loss_weight_cls = loss_weight_cls
        self.loss_weight_reg = loss_weight_reg
        self.loss_weight_ctr = loss_weight_ctr
        self.loc_loss_func = loc_loss_func

        self.pre_nms_thresh_train = pre_nms_thresh_train
        self.pre_nms_topk_train = pre_nms_topk_train
        self.post_nms_topk_train = post_nms_topk_train
        self.pre_nms_thresh_test = pre_nms_thresh_test
        self.pre_nms_topk_test = pre_nms_topk_test
        self.post_nms_topk_test = post_nms_topk_test
        self.nms_thresh = nms_thresh
        self.strides = strides

        # 中心度的引入是为了降低距离目标中心点距离较远特征点的计算权重，以降低定位误差
        self.ctrness = nn.Conv2d(self.in_channel, 1, kernel_size=3, stride=1, padding=1)
        # 基础公共结构
        self.base_structure = BoxBaseHead(num_share_con, num_cls_con, num_reg_con,
                                          self.in_channel, num_classes, prior_prob)

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            # 模型相关
            in_channels=cfg.MODEL.FCOS.IN_CHANNELS,        # 输入特征的通道数
            num_classes=cfg.MODEL.NUM_CLASSES,        # 分类数量，不包含背景类
            num_share_con=cfg.MODEL.FCOS.NUM_SHARE_CONVS,  # 共享卷积层数
            num_cls_con=cfg.MODEL.FCOS.NUM_CLS_CONVS,      # 分类卷积层数
            num_reg_con=cfg.MODEL.FCOS.NUM_BOX_CONVS,      # 回归卷积层数
            prior_prob=cfg.MODEL.FCOS.PRIOR_PROB,          # 分类卷积中的偏置参数初始化参数

            # 损失函数相关
            sizes_of_interest=cfg.MODEL.FCOS.SIZES_OF_INTEREST,  # 各级特征最大值限制
            focal_loss_alpha=cfg.MODEL.FCOS.LOSS_ALPHA,
            focal_loss_gamma=cfg.MODEL.FCOS.LOSS_GAMMA,
            loss_weight_cls=cfg.MODEL.FCOS.LOSS_WEIGHT_CLS,
            loss_weight_reg=cfg.MODEL.FCOS.LOSS_WEIGHT_REG,
            loss_weight_ctr=cfg.MODEL.FCOS.LOSS_WEIGHT_CTR,
            loc_loss_func=IOULoss(cfg.MODEL.FCOS.LOC_LOSS_TYPE),

            # 推理相关
            pre_nms_thresh_train=cfg.MODEL.FCOS.INFERENCE_TH_TRAIN,
            pre_nms_topk_train=cfg.MODEL.FCOS.PRE_NMS_TOPK_TRAIN,
            post_nms_topk_train=cfg.MODEL.FCOS.POST_NMS_TOPK_TRAIN,
            pre_nms_thresh_test=cfg.MODEL.FCOS.INFERENCE_TH_TEST,
            pre_nms_topk_test=cfg.MODEL.FCOS.PRE_NMS_TOPK_TEST,
            post_nms_topk_test=cfg.MODEL.FCOS.POST_NMS_TOPK_TEST,
            nms_thresh=cfg.MODEL.FCOS.NMS_TH,

            # 公共参数
            strides=cfg.MODEL.FCOS.STRIDES,
        )
        return ret

    def forward(self, input_data):
        """
        FCOS头结构的公共部分，在此基础上将会进行回归和分类等操作
        :param input_data: TensorPackage对象，来自于neck结构的输出
        :return:
        """
        cls_share_tensor_list, reg_share_tensor_list, logits, bbox_reg = self.base_structure.base_forward(input_data)
        # 中心度特征映射从共享回归卷积特征映射中计算得到
        ctrness = [self.ctrness(tensor) for tensor in reg_share_tensor_list]

        # 获得分类张量、回归张量和中心度张量，中心度张量只是起到了辅助作用，真正发挥作用的还是分类张量和回归张量
        # 所以这里需要将中心度张量融合到分类张量中去
        tensor_package_obj = TensorPackage(multi_tensor=[logits, bbox_reg, ctrness],
                                           tensor=None, size=None, channel=None, stride=None)
        return tensor_package_obj

    def head_fix(self, inference_tensor_obj):
        """
        通常情况下，网络输出除了分类张量和回归张量外，还有其他张量，引入其他张量是为了提高模型的学习效果，
        但是后续最终需要处理的还是分类张量和回归张量，所以引入该方法进行修正处理，以获得最终的分类张量和回归张量
        :param inference_tensor_obj: 头结构输出的一系列张量，包括分类张量、回归张量和中心度张量
        :return:
        """
        cls_feature_list = []
        reg_feature_list = []
        logits_list, bbox_reg_list, ctrness_list = inference_tensor_obj.multi_tensor
        for logits, bbox_reg, ctrness in zip(logits_list, bbox_reg_list, ctrness_list):
            N, C, H, W = logits.shape

            # put in the same format as locations
            logits = logits.view(N, C, H, W).permute(0, 2, 3, 1)
            logits = logits.reshape(N, -1, C).sigmoid()
            bbox_reg = bbox_reg.view(N, 4, H, W).permute(0, 2, 3, 1)
            bbox_reg = bbox_reg.reshape(N, -1, 4)
            ctrness = ctrness.view(N, 1, H, W).permute(0, 2, 3, 1)
            ctrness = ctrness.reshape(N, -1).sigmoid()

            logits_pred = logits * ctrness[:, :, None]
            cls_feature_list.append(logits_pred)
            reg_feature_list.append(bbox_reg)

        return cls_feature_list, reg_feature_list

    def prepare_loss_material(self, inference_tensor_obj, locations, gt_instances):
        """
        准备计算损失需要的所有原材料，包括模型推理结果和对应的标签信息
        :param inference_tensor_obj: 模型推理获得一些张量，包括分类张量、回归张量和中心度张量
        :param locations: 多级特征映射的坐标位置，是一个列表形式
        :param gt_instances: 标签
        :return: 返回的结果为多级特征映射，每一级都融合了mini batch中各图片对应的特征信息
        """
        logits_pred, bbox_reg, ctrness_pred = inference_tensor_obj.multi_tensor
        match_object = FCOSMatch(logits_pred, bbox_reg, ctrness_pred, gt_instances,
                                 self.sizes_of_interest, self.num_classes, self.strides)
        # 匹配获得标签信息
        instances = match_object.start_matcher(locations)
        # 增加模型推理结果
        instances.logits_pred = cat([
            # Reshape: (N, C, Hi, Wi) -> (N, Hi, Wi, C) -> (N*Hi*Wi, C)
            x.permute(0, 2, 3, 1).reshape(-1, self.num_classes) for x in logits_pred
        ], dim=0, )
        instances.reg_pred = cat([
            # Reshape: (N, B, Hi, Wi) -> (N, Hi, Wi, B) -> (N*Hi*Wi, B)
            x.permute(0, 2, 3, 1).reshape(-1, 4) for x in bbox_reg
        ], dim=0, )
        instances.ctrness_pred = cat([
            # Reshape: (N, 1, Hi, Wi) -> (N*Hi*Wi,)
            x.permute(0, 2, 3, 1).reshape(-1) for x in ctrness_pred
        ], dim=0, )
        return instances

    def inference(self, inference_tensor_obj, locations, image_sizes):
        # TODO: 这里需要兼容推理一张图片或多张图片
        logits_pred, reg_pred = self.head_fix(inference_tensor_obj)
        if self.training:
            self.pre_nms_thresh = self.pre_nms_thresh_train
            self.pre_nms_topk = self.pre_nms_topk_train
            self.post_nms_topk = self.post_nms_topk_train
        else:
            self.pre_nms_thresh = self.pre_nms_thresh_test
            self.pre_nms_topk = self.pre_nms_topk_test
            self.post_nms_topk = self.post_nms_topk_test

        # 将多级特征映射的位置放在一起，组成一个多行两列的矩阵
        # locations = torch.cat(locations, dim=0)

        sampled_boxes = []
        bundle = {"l": locations, "o": logits_pred, "r": reg_pred, "s": self.strides}

        for i, per_bundle in enumerate(zip(*bundle.values())):
            # per_bundle将多张图片的同级特征映射进行合并
            per_bundle = dict(zip(bundle.keys(), per_bundle))
            # recall that during training, we normalize regression targets with FPN's stride.
            # we denormalize them here.
            l = per_bundle["l"]
            o = per_bundle["o"]
            r = per_bundle["r"] * per_bundle["s"]

            sampled_boxes.append(self.forward_for_single_feature_map(l, o, r, image_sizes))

        boxlists = list(zip(*sampled_boxes))
        boxlists = [Instances.cat(boxlist) for boxlist in boxlists]
        boxlists = self.select_over_all_levels(boxlists)

        return boxlists

    def loss(self, inference_tensor_obj, locations, gt_instances):
        instances = self.prepare_loss_material(inference_tensor_obj, locations, gt_instances)
        losses, extras = {}, {}

        # 计算分类损失
        num_classes = instances.logits_pred.size(1)
        assert num_classes == self.num_classes
        # 挑选并剔除掉背景类
        labels = instances.labels.flatten()
        pos_inds = torch.nonzero(labels != num_classes).squeeze(1)
        num_pos_local = torch.ones_like(pos_inds).sum()
        num_pos_avg = max(reduce_mean(num_pos_local).item(), 1.0)
        class_target = torch.zeros_like(instances.logits_pred)
        class_target[pos_inds, labels[pos_inds]] = 1

        class_loss = sigmoid_focal_loss_jit(
            instances.logits_pred,
            class_target,
            alpha=self.focal_loss_alpha,
            gamma=self.focal_loss_gamma,
            reduction="sum"
        )
        class_loss = class_loss / num_pos_avg
        losses["loss_fcos_cls"] = class_loss * self.loss_weight_cls

        # 计算回归误差和中心度误差
        instances = instances[pos_inds]  # 剔除掉背景标签对应的数据
        instances.pos_inds = pos_inds
        ious, gious = compute_ious(instances.reg_pred, instances.reg_targets)  # 计算预测框和回归框的交并比
        # 计算中心度标签
        ctrness_targets = self.compute_ctrness_targets(instances.reg_targets)
        instances.gt_ctrs = ctrness_targets
        ctrness_targets_sum = ctrness_targets.sum()
        loss_denorm = max(reduce_mean(ctrness_targets_sum).item(), 1e-6)
        reg_loss = self.loc_loss_func(ious, gious, ctrness_targets) / loss_denorm
        losses["loss_fcos_loc"] = reg_loss

        ctrness_loss = F.binary_cross_entropy_with_logits(
            instances.ctrness_pred, ctrness_targets, reduction="sum") / num_pos_avg
        losses["loss_fcos_ctr"] = ctrness_loss

        return losses

    @staticmethod
    def compute_ctrness_targets(reg_targets):
        if len(reg_targets) == 0:
            return reg_targets.new_zeros(len(reg_targets))
        left_right = reg_targets[:, [0, 2]]
        top_bottom = reg_targets[:, [1, 3]]
        ctrness = (left_right.min(dim=-1)[0] / left_right.max(dim=-1)[0]) * \
                  (top_bottom.min(dim=-1)[0] / top_bottom.max(dim=-1)[0])
        return torch.sqrt(ctrness)

    def forward_for_single_feature_map(self, locations, logits_pred, reg_pred, image_sizes):
        """
        对所有图片的单级特征映射进行后处理
        :param locations: 单级特征映射的所有位置坐标
        :param logits_pred: 单级概率特征映射，形状为[batch_size, n, classes] n为单级特征映射的位置数量，classes为任务的类别数（不包含背景）
        :param reg_pred: 单级回归特征映射
        :param image_sizes: 当前图片的原始尺寸系列（一张或多张）
        :return:
        """
        # 获取当前计算的图片数量
        num_pic = logits_pred.size(0)
        # 对分类张量进行阈值处理
        candidate_inds = logits_pred > self.pre_nms_thresh
        # 计算单张图片中，大于得分阈值的候选点数量
        pre_nms_top_n = candidate_inds.reshape(num_pic, -1).sum(1)
        # 将非极大值抑制前的候选点数量限定在一定的范围内
        pre_nms_top_n = pre_nms_top_n.clamp(max=self.pre_nms_topk)

        # 开始依次计算每张图片的单级特征映射
        results = []
        for i in range(num_pic):
            per_box_cls = logits_pred[i]                   # 当前图片的分类张量
            per_candidate_inds = candidate_inds[i]         # 当前图片中大于分类阈值的bool张量
            per_box_cls = per_box_cls[per_candidate_inds]  # 筛选出大于分类阈值的  “分类值”

            # per_candidate_nonzeros = per_candidate_inds.nonzero()
            per_candidate_nonzeros = torch.nonzero(per_candidate_inds, as_tuple=False)
            per_box_loc = per_candidate_nonzeros[:, 0]  # 大于分类阈值的候选点，一个候选点可能被分配到多个类别
            per_class = per_candidate_nonzeros[:, 1]    # 大于分类阈值的候选点对应的  “类别”

            per_box_regression = reg_pred[i]                      # 当前图片的回归张量
            per_box_regression = per_box_regression[per_box_loc]  # 大于分类阈值的所有候选点对应的  “回归目标”
            per_locations = locations[per_box_loc]                # 大于分类阈值的所有  “候选点对应的坐标”

            per_pre_nms_top_n = pre_nms_top_n[i]  # 当前图片在非极大值抑制前的预期边框数量

            # 如果大于分类阈值的候选点数量大于预期数量，则进行分数降序来获取前预期个得分
            if per_candidate_inds.sum().item() > per_pre_nms_top_n.item():
                per_box_cls, top_k_indices = per_box_cls.topk(per_pre_nms_top_n, sorted=False)
                per_class = per_class[top_k_indices]
                per_box_regression = per_box_regression[top_k_indices]
                per_locations = per_locations[top_k_indices]

            # 获取最终的检测框左上点和右下点的坐标
            detections = torch.stack([
                per_locations[:, 0] - per_box_regression[:, 0],
                per_locations[:, 1] - per_box_regression[:, 1],
                per_locations[:, 0] + per_box_regression[:, 2],
                per_locations[:, 1] + per_box_regression[:, 3],
            ], dim=1)
            # 将边框的范围限制到0到图片尺寸之间
            detections[:, 0] = detections[:, 0].clamp(min=0)
            detections[:, 1] = detections[:, 1].clamp(min=0)
            detections[:, 2] = detections[:, 2].clamp(max=image_sizes[i][1])
            detections[:, 3] = detections[:, 3].clamp(max=image_sizes[i][0])

            boxlist = Instances(image_sizes[i])
            boxlist.pred_boxes = Boxes(detections)    # 边框坐标
            boxlist.scores = torch.sqrt(per_box_cls)  # 边框得分
            boxlist.pred_classes = per_class          # 边框类别
            boxlist.locations = per_locations         # 候选点坐标
            results.append(boxlist)

        return results

    def select_over_all_levels(self, boxlists):
        num_images = len(boxlists)
        results = []
        for i in range(num_images):
            # multiclass nms
            result = ml_nms(boxlists[i], self.nms_thresh)
            number_of_detections = len(result)

            # Limit to max_per_image detections **over all classes**
            if number_of_detections > self.post_nms_topk > 0:
                cls_scores = result.scores
                image_thresh, _ = torch.kthvalue(
                    cls_scores.cpu(),
                    number_of_detections - self.post_nms_topk + 1
                )
                keep = cls_scores >= image_thresh.item()
                keep = torch.nonzero(keep).squeeze(1)
                result = result[keep]
            results.append(result)

        return {'instances': results}


def add_fcos_head_config():
    """
        Add config for FCOS head.
    """
    _C.MODEL.FCOS = CN()
    _C.MODEL.FCOS.IN_CHANNELS = []
    _C.MODEL.FCOS.NUM_SHARE_CONVS = 2
    _C.MODEL.FCOS.NUM_CLS_CONVS = 2
    _C.MODEL.FCOS.NUM_BOX_CONVS = 2
    _C.MODEL.FCOS.PRIOR_PROB = 0.01

    _C.MODEL.FCOS.SIZES_OF_INTEREST = []
    _C.MODEL.FCOS.LOSS_ALPHA = 0.25
    _C.MODEL.FCOS.LOSS_GAMMA = 2.0
    _C.MODEL.FCOS.LOSS_WEIGHT_CLS = 1.0
    _C.MODEL.FCOS.LOSS_WEIGHT_REG = 1.0
    _C.MODEL.FCOS.LOSS_WEIGHT_CTR = 1.0
    _C.MODEL.FCOS.LOC_LOSS_TYPE = 'giou'

    _C.MODEL.FCOS.INFERENCE_TH_TRAIN = 0.05  # 训练时的得分阈值
    _C.MODEL.FCOS.PRE_NMS_TOPK_TRAIN = 1000
    _C.MODEL.FCOS.POST_NMS_TOPK_TRAIN = 100
    _C.MODEL.FCOS.INFERENCE_TH_TEST = 0.2    # 推理时的得分阈值
    _C.MODEL.FCOS.PRE_NMS_TOPK_TEST = 1000   # 推理时非极大值抑制前，单级特征映射的
    _C.MODEL.FCOS.POST_NMS_TOPK_TEST = 100
    _C.MODEL.FCOS.NMS_TH = 0.6
    _C.MODEL.FCOS.STRIDES = []


class FCOSMatch(BaseMatch):
    def __init__(self, logits_pred, reg_pred, ctrness, gt_instances, sizes_of_interest, num_classes, strides):
        """
        相对于基类，当前头结构引入了两个限制：
        1、每个特征映射位置到gt边框各边界的最大值有限定；
        2、如果某个特征映射的位置映射到多个边框重叠区域内，则取面积最小的边框为当前特征映射的标签框
        :param logits_pred: 多个四维分类特征映射组成的列表
        :param reg_pred: 多个四维回归特征特征映射组成的列表
        :param ctrness: 多个四维中心度特征映射组成的列表
        :param gt_instances: 多个Instance对象组成的列表
        :param sizes_of_interest: 多级特征映射到gt框边界最大值的范围限定
        :param num_classes: 当前任务的分类数量
        :param strides: 多级特征映射对应的步长列表
        """
        super(FCOSMatch, self).__init__(logits_pred, reg_pred, gt_instances)
        self.logits_pred = logits_pred
        self.reg_pred = reg_pred
        self.ctrness = ctrness
        self.device = logits_pred[0].device
        self.gt_instances = gt_instances
        self.sizes_of_interest = sizes_of_interest
        self.num_classes = num_classes
        self.strides = strides

    @staticmethod
    def get_size_limit(locations, sizes_of_interest):
        """
        获取每一级特征的尺寸限制
        :param locations: 多个多行两列的二维矩阵组成的列表，表示当前级特征映射的所有位置信息
        :param sizes_of_interest: 一系列数字组成的列表，长度与locations的列表长度一致，表示对应级特征映射的最大尺寸限制
        :return:
        """
        # 计算每一级特征映射位置的个数
        num_loc_list = [len(loc) for loc in locations]
        # 获取每一级特征映射的尺寸限制
        soi = []
        prev_size = -1
        for s in sizes_of_interest:
            soi.append([prev_size, s])
            prev_size = s
        soi.append([prev_size, INF])
        # 通过传播机制，计算得到所有特征映射位置的尺寸限制
        location_size_range = []
        for ind, loc_per_level in enumerate(locations):
            loc_to_size_range_per_level = loc_per_level.new_tensor(soi[ind])
            location_size_range.append(
                loc_to_size_range_per_level[None].expand(num_loc_list[ind], -1)
            )
        location_size_range = torch.cat(location_size_range, dim=0)

        return location_size_range

    def start_matcher(self, location_list):
        labels = []
        reg_targets = []
        target_inds = []
        # 计算每个特征点到所有gt框的边界距离
        num_loc_list = [len(num) for num in location_list]
        locations = torch.cat(location_list, dim=0)

        # 分别处理每张图片
        num_targets = 0
        training_targets = {}
        for gt_instance in self.gt_instances:
            # 这里因为通常情况下是不会在CPU上训练的，所以先将其默认放置在GPU上
            bboxes = gt_instance.gt_boxes.tensor
            bboxes = torch.as_tensor(bboxes).to(self.device)
            labels_per_im = gt_instance.gt_classes
            labels_per_im = torch.as_tensor(labels_per_im).to(self.device)

            # 异常处理，当标签中没有边框信息时，需要进行赋值处理
            if bboxes.numel() == 0:
                # print('进来了')
                # 边框类别赋值为self.num_classes，该类别不存在，真实的类别是从0到self.num_classes-1
                labels.append(
                    torch.as_tensor(labels_per_im.new_zeros(locations.size(0)) + self.num_classes).to(self.device))
                # 边框赋值为全零
                reg_targets.append(torch.as_tensor(locations.new_zeros((locations.size(0), 4))).to(self.device))
                # 每个特征映射位置对应的gt边框的编号为-1，该编号也不存在
                target_inds.append(torch.as_tensor(labels_per_im.new_zeros(locations.size(0)) - 1).to(self.device))
                continue

            # area = gt_instance.gt_boxes.area()
            area = (bboxes[:, 3] - bboxes[:, 1]) * (bboxes[:, 2] - bboxes[:, 0])

            # 计算所有特征点到所有边框边界的距离
            reg_targets_per_im = self.feature_points_to_gt_border_distance(locations, bboxes)

            # 确定出所有特征点与图片边框的对应关系
            is_in_boxes = reg_targets_per_im.min(dim=2)[0] > 0

            # 施加尺寸限制
            max_reg_targets_per_im = reg_targets_per_im.max(dim=2)[0]
            size_limit_range = self.get_size_limit(location_list, self.sizes_of_interest)
            is_cared_in_the_level = \
                (max_reg_targets_per_im >= size_limit_range[:, [0]]) & \
                (max_reg_targets_per_im <= size_limit_range[:, [1]])

            locations_to_gt_area = area[None].repeat(len(locations), 1)[:]

            locations_to_gt_area[is_in_boxes == 0] = INF
            locations_to_gt_area[is_cared_in_the_level == 0] = INF
            # 面积约束，以使得每个特征点只能被分配给一个gt框
            locations_to_gt_area = locations_to_gt_area
            locations_to_min_area, locations_to_gt_inds = locations_to_gt_area.min(dim=1)
            # 根据约束结果获取到每个特征点的回归目标
            reg_targets_per_im = reg_targets_per_im[range(len(locations)),
                                                    locations_to_gt_inds.to(self.device)]  # box标签
            # 获取每个特征点对应的gt索引，如果多张图片的索引都从零开始会照成干扰，所以边框索引依次递加
            target_ind_per_im = locations_to_gt_inds + num_targets  # 边框索引，需要依次来获得类别标签
            num_targets += len(gt_instance)
            # 获取各特征映射对应的类别标签
            labels_per_im = torch.as_tensor(gt_instance.gt_classes).to(self.device)
            labels_per_im = labels_per_im[locations_to_gt_inds]
            labels_per_im[locations_to_min_area == INF] = self.num_classes  # box类别标签

            labels.append(labels_per_im)
            reg_targets.append(reg_targets_per_im)
            target_inds.append(target_ind_per_im)
        training_targets["labels"] = labels
        training_targets["reg_targets"] = reg_targets
        training_targets["target_inds"] = target_inds
        training_targets["locations"] = [locations.clone() for _ in range(len(self.gt_instances))]
        training_targets["im_inds"] = [
            locations.new_ones(locations.size(0), dtype=torch.long) * i for i in range(len(self.gt_instances))
        ]
        # 此时的张量是按照图片进行分离的，为了便于后续能够一起计算多张图片对应的特征映射，需要将同级特征映射进行合并处理
        training_targets = {
            k: self.merge_same_level_info(v, num_loc_list) for k, v in training_targets.items()
        }
        training_targets["fpn_levels"] = [
            loc.new_ones(len(loc), dtype=torch.long) * level
            for level, loc in enumerate(training_targets["locations"])
        ]
        # 在这里将回归目标归一化到当前特征尺寸上，即不是相对于原始图片尺寸
        reg_targets = training_targets["reg_targets"]
        for level in range(len(reg_targets)):
            reg_targets[level] = reg_targets[level] / float(self.strides[level])
        # 将计算得到的标签信息打包到Instance对象中
        instances = self.data_to_instance(training_targets)

        return instances

    @staticmethod
    def merge_same_level_info(training_targets, num_loc_list):
        """
        将多张图片对应的同级别信息进行合并，便于统一loss计算
        :param training_targets:
        :param num_loc_list: 多个数字组成的列表，表示多级别特征中的特征点数量
        :return:
        """
        for im_i in range(len(training_targets)):
            training_targets[im_i] = torch.split(
                training_targets[im_i], num_loc_list, dim=0
            )

        targets_level_first = []
        for targets_per_level in zip(*training_targets):
            targets_level_first.append(
                torch.cat(targets_per_level, dim=0)
            )
        return targets_level_first

    @staticmethod
    def data_to_instance(training_targets):
        instances = Instances((0, 0))
        instances.labels = cat([
            # Reshape: (N, 1, Hi, Wi) -> (N*Hi*Wi,)
            x.reshape(-1) for x in training_targets["labels"]
        ], dim=0)
        instances.gt_inds = cat([
            # Reshape: (N, 1, Hi, Wi) -> (N*Hi*Wi,)
            x.reshape(-1) for x in training_targets["target_inds"]
        ], dim=0)
        instances.im_inds = cat([
            x.reshape(-1) for x in training_targets["im_inds"]
        ], dim=0)
        instances.reg_targets = cat([
            # Reshape: (N, Hi, Wi, 4) -> (N*Hi*Wi, 4)
            x.reshape(-1, 4) for x in training_targets["reg_targets"]
        ], dim=0, )
        instances.locations = cat([
            x.reshape(-1, 2) for x in training_targets["locations"]
        ], dim=0)
        instances.fpn_levels = cat([
            x.reshape(-1) for x in training_targets["fpn_levels"]
        ], dim=0)

        return instances
