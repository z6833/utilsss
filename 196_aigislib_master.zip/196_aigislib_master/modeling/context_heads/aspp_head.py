import torch
import torch.nn as nn
import torch.nn.functional as F
from ..builder import HEADS
from typing import List, Tuple

from detectron2.config import configurable


@HEADS.register()
class AsppHead(nn.Module):
    """ 扩张卷积空间金子塔模块 """
    @configurable
    def __init__(self,
                 in_channels: List[int],
                 in_features: List,
                 out_channels: int,
                 dilations: Tuple = (6, 12, 18)):
        super(AsppHead, self).__init__()
        self.in_channels = in_channels[-1]
        self.in_features = in_features
        self.out_channels = out_channels
        self.conv1 = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Conv2d(in_channels[-1], out_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
        self.stages = nn.ModuleList([self._make_stage(in_channels[-1], out_channels, dilation) for dilation in dilations])

        self.bottleneck = nn.Sequential(
            nn.Conv2d(out_channels * len(dilations) + out_channels, out_channels, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.HEADS.IN_CHANNELS,
            in_features=cfg.MODEL.HEADS.IN_FEATURE_IDX,
            out_channels=cfg.MODEL.HEADS.OUT_CHANNELS,
            dilations=cfg.MODEL.HEADS.ASPP_DILATIONS,
        )
        return ret

    def _make_stage(self, in_channels, out_channels, dilation):
        conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=dilation,
                         dilation=dilation, bias=False)
        bn = nn.BatchNorm2d(out_channels)
        relu = nn.ReLU(inplace=True)
        return nn.Sequential(conv, bn, relu)

    def forward(self, inputs):
        # 获取当前模块想要的输入张量
        # 只适用语义分割中的aspp模块
        # inputs_list = []
        # for i in self.in_features:
        #     inputs_list.append(inputs[i])
        # x = inputs_list[-1]
        # h, w = x.size()[2:]
        # print("2:",inputs.size())
        if isinstance(inputs, (list, tuple)):
            inputs = inputs[-1]
        x=inputs
        h, w = x.size(2), x.size(3)

        # 获取全局信息，并进行上采样以获得与输入相同的输入大小
        feat1 = self.conv1(x)
        feat1 = F.interpolate(feat1, size=(h, w), mode='bilinear', align_corners=True)
        feats = [feat1]
        # 使用并行的扩张卷积对输入进行处理
        for layer in self.stages:
            feats.append(layer(x))
        # 拼接多尺度特征，并使用卷积进行降维，以及融合特征
        out_cat = torch.cat(feats, dim=1)
        out = self.bottleneck(out_cat)
        # print(out.shape)
        return out
