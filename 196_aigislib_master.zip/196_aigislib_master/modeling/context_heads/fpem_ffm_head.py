"""
车志忠：文字检测
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from ..builder import HEADS


@HEADS.register()
class FPEM_FFM_Head(nn.Module):
    def __init__(self, cfg, **kwargs):
        """
        PANnet
        :param backbone_out_channels: 基础网络输出的维度
        """
        super().__init__()
        fpem_repeat = cfg.MODEL.HEADS.REPEAT  # kwargs.get('fpem_repeat', 2)
        conv_out = 128
        # self.input_feature = [0, 1, 2, 3]
        self.device = torch.device(cfg.MODEL.DEVICE)
        self.input_max_size = cfg.MODEL.HEADS.IN_MAX_SIZE
        self.out_size = cfg.MODEL.HEADS.OUT_SIZE
        self.up_ratio = self.out_size / self.input_max_size
        output_channel = cfg.MODEL.HEADS.OUT_CHANNELS
        self.input_channel = cfg.MODEL.HEADS.IN_CHANNELS
        # reduce layers
        self.reduce_list = []
        for i in self.input_channel:
            self.reduce_list.append(
                nn.Sequential(
                    nn.Conv2d(in_channels=i, out_channels=conv_out, kernel_size=1),
                    nn.BatchNorm2d(conv_out),
                    nn.ReLU()
                ).to(self.device)
            )
        self.fpems = nn.ModuleList()
        for i in range(fpem_repeat):
            self.fpems.append(
                FPEM(in_channels=conv_out,
                     feature_num=len(self.reduce_list),
                     device=self.device)
            )
        self.out_conv = nn.Conv2d(
            in_channels=conv_out * len(self.input_channel),
            out_channels=output_channel,
            kernel_size=1).to(self.device)

    def forward(self, x):
        # c2, c3, c4, c5 = x
        middle_res = []
        for num, part in enumerate(x):
            middle_res.append(self.reduce_list[num](part))

        # FPEM
        for i, fpem in enumerate(self.fpems):
            if i == 0:
                first_res = fpem(middle_res)
            else:
                second_res = []
                for f, s in zip(first_res, fpem(middle_res)):
                    second_res.append(f+s)
                first_res = second_res

        # FFM
        ffm_list = []
        for num, ffm in enumerate(first_res):
            if num == 0:
                ffm_list.append(ffm)
                continue
            ffm_list.append(F.interpolate(ffm, ffm_list[0].size()[-2:], mode='bilinear'))
        Fy = torch.cat(ffm_list, dim=1)
        Fy = F.interpolate(Fy,
                           size=(int(Fy.size()[2] * self.up_ratio),
                                 int(Fy.size()[3] * self.up_ratio)),
                           mode='bilinear',
                           align_corners=False)
        y = self.out_conv(Fy)
        return y


class FPEM(nn.Module):
    def __init__(self, in_channels=128, feature_num=4, device=None):
        super().__init__()
        self.up_add = []
        self.down_add = []
        if feature_num == 1:
            self.up_add.append(SeparableConv2d(in_channels, in_channels, 1, device=device))
            self.down_add.append(SeparableConv2d(in_channels, in_channels, 2, device=device))
        else:
            for i in range(feature_num-1):
                self.up_add.append(SeparableConv2d(in_channels, in_channels, 1, device=device))
                self.down_add.append(SeparableConv2d(in_channels, in_channels, 2, device=device))

    def forward(self, input_feature_list):
        # up阶段
        middle_up_add = [input_feature_list[-1]]
        middle_down_add = []
        reversed_feature = [feature for feature in reversed(input_feature_list)]
        for num, input_feature in enumerate(reversed_feature):
            if num == 0:
                continue
            middle_up_add.append(
                self.up_add[num-1](self._upsample_add(reversed_feature[num-1], input_feature))
            )
        reversed_middle_up_add = [feature for feature in reversed(middle_up_add)]
        for num, feature in enumerate(reversed_middle_up_add):
            if num == 0:
                middle_down_add.append(reversed_middle_up_add[0])
                continue
            middle_down_add.append(
                self.down_add[num-1](self._upsample_add(feature, reversed_middle_up_add[num-1]))
            )

        return middle_down_add  # c2, c3, c4, c5

    def _upsample_add(self, x, y):
        return F.interpolate(x, size=y.size()[2:], mode='bilinear') + y


class SeparableConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, device=None):
        super(SeparableConv2d, self).__init__()

        self.depthwise_conv = nn.Conv2d(in_channels=in_channels,
                                        out_channels=in_channels,
                                        kernel_size=3,
                                        padding=1,
                                        stride=stride,
                                        groups=in_channels).to(device)
        self.pointwise_conv = nn.Conv2d(in_channels=in_channels,
                                        out_channels=out_channels,
                                        kernel_size=1).to(device)
        self.bn = nn.BatchNorm2d(out_channels).to(device)
        self.relu = nn.ReLU().to(device)

    def forward(self, x):
        x = self.depthwise_conv(x)
        x = self.pointwise_conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x
