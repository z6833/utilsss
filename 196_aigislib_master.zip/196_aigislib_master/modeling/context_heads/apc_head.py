import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple, Union
from detectron2.config import configurable
from ..builder import HEADS


class ACM(nn.Module):
    """ 自适应上下文模块(adaptive context Module) """
    def __init__(self, in_channels, channels, scale: int = 1):
        super(ACM, self).__init__()
        self.channels = channels
        self.scale = scale
        # 分支1
        self.input_reduction_conv = nn.Sequential(
            nn.Conv2d(in_channels, channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )
        self.gap = nn.AdaptiveAvgPool2d((1, 1))
        self.global_info = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )

        self.gla = nn.Sequential(
            nn.Conv2d(channels, scale * scale, kernel_size=1, stride=1, padding=0)
        )

        # 分支2
        self.pooled_reduction_conv = nn.Sequential(
            nn.Conv2d(in_channels, channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )

        self.residual_conv = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )
        self.fusion_conv = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, inputs):
        # print(inputs.size())
        batch, channel, height, width = inputs.size()
        # 计算第一个分支
        feat = self.input_reduction_conv(inputs)     # (B, 256, h, w)
        global_feat = self.gap(feat)                 # (B, 256, 1, 1)
        global_feat = self.global_info(global_feat)

        gla = feat + global_feat    # (B, 256, h, w)
        gla = self.gla(gla)         # (B, scale* scale, h, w)
        gla = gla.permute(0, 2, 3, 1).contiguous()     # (B, h, w, s*s)
        gla = gla.view(batch, -1, self.scale**2)       # (B, hw, s*s)

        # 计算第二个分支F.adaptive_avg_pool2d(x, self.pool_scale)
        pool_feat = nn.AdaptiveAvgPool2d((self.scale, self.scale))(inputs)  # (B, C, scale, scale)
        pool_feat = self.pooled_reduction_conv(pool_feat)                   # (B, 256, scale, scale)
        pool_feat = pool_feat.view(batch, -1, self.scale * self.scale)
        pool_feat = pool_feat.permute(0, 2, 1).contiguous()      # (B, s*s, 256)

        # matrix product
        affinity_matrix = torch.sigmoid(gla)
        matrix_out = torch.matmul(affinity_matrix, pool_feat)    # (B, hw, 256)
        matrix_out = matrix_out.permute(0, 2, 1).contiguous()    # (B, c, hw)
        matrix_out = matrix_out.view(batch, self.channels, height, width)
        matrix_out = self.residual_conv(matrix_out)
        out = F.relu(matrix_out + feat)
        out = self.fusion_conv(out)
        
        return out


@HEADS.register()
class APCHead(nn.Module):
    """ adaptive pyramid context head
    https://openaccess.thecvf.com/content_CVPR_2019/papers/He_Adaptive_Pyramid_Context_Network_for_Semantic_Segmentation_CVPR_2019_paper.pdf
    """
    @configurable
    def __init__(self,
                 in_channels: Union[List[int], int],
                 in_features: List,
                 out_channels: int,
                 pool_scale: Union[List, Tuple] = (1, 2, 3, 6)):
        super(APCHead, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.in_features = in_features
        self.pool_scales = pool_scale
        acm_modules = []
        for scale in self.pool_scales:
            acm_modules.append(
                ACM(
                    self.in_channels[-1],
                    self.out_channels,
                    scale
                )
            )
        self.acm_modules = nn.ModuleList(acm_modules)
        self.bottleneck = nn.Sequential(
            nn.Conv2d(
                self.in_channels[-1] + len(pool_scale) * self.out_channels,
                self.out_channels,
                kernel_size=3,
                stride=1,
                padding=1
            )
        )

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.HEADS.IN_CHANNELS,
            out_channels=cfg.MODEL.HEADS.OUT_CHANNELS,
            in_features=cfg.MODEL.HEADS.IN_FEATURE_IDX,
            pool_scale=cfg.MODEL.HEADS.POOL_SCALES
        )
        return ret

    def forward(self, inputs):
        """
        Args:
            inputs (List)
        """
        # input = [inputs[i] for i in self.in_features]      # 通过in_feature获取想要的特征层
        if isinstance(inputs, (list, tuple)):
            inputs = inputs[-1]
        result = [inputs]

        # 这里acm_modules是一个多分支的并行模块。分别对输入进行处理
        for acm in self.acm_modules:
            features = acm(inputs)
            result.append(features)
        # 拼接多尺度处理结果
        out = torch.cat(result, dim=1)
        # 对通道维度缩放到指定的输出尺度
        out = self.bottleneck(out)
        return out
