from .aspp_head import AsppHead
from .psp_head import PPMHead
from .apc_head import APCHead
from .fpem_ffm_head import FPEM_FFM_Head
from .craft_head import CRAFT_Head
from .fcos_head import FCOSHead, add_fcos_head_config


add_fcos_head_config()
