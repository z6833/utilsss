
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from abc import ABCMeta, abstractmethod
from collections.abc import Iterable
from typing import List, Optional, Union


class BaseHead(nn.Module, metaclass=ABCMeta):
    """ Base class for BaseHead """
    def __init__(self,
                 in_channels: Union[List, int],
                 in_features_idx: Union[List, int],
                 input_transform: Optional[str] = None,
                 ):
        """

        :param in_channels: 输入通道
        :param in_features_idx:
        :param input_transform:
        """
        super(BaseHead, self).__init__()
        self._init_inputs(in_channels, in_features_idx, input_transform)

    def _init_inputs(self, in_channels, in_features_idx, input_transform):
        """ 检测输入通道数是否与输入特征索引一致，通过input_transform来指定 """
        if input_transform is not None:
            assert input_transform in ["resize_cat", "multi_select"]
        self.input_transform = input_transform
        self.in_features_idx = in_features_idx

        if input_transform is not None:
            # 对多个输入进行处理
            assert isinstance(in_channels, Iterable), "in channels must be Iterable!"
            assert isinstance(in_features_idx, Iterable), "input features index must be Iterable!"

            if self.input_transform == "resize_cat":
                self.in_channels = sum(in_channels)
            else:
                self.in_channels = in_channels
        else:
            # 对单个输入进行处理
            assert isinstance(in_channels, int), "in channels is solo."
            assert isinstance(in_features_idx, int), "input channels is solo."
            self.in_channels = in_channels

    def transform_input(self, inputs):
        """
        对输入特征进行变换
        """
        if self.input_transform == "resize_cat":
            # 对输入特征进行concat
            inputs = [inputs[i] for i in self.in_features_idx]
            for i in range(1, len(inputs)):
                inputs[i] = F.interpolate(
                    inputs[i], size=inputs[0].shape[2:], mode="bilinear", align_corners=True)
            return torch.cat(inputs, dim=1)
        elif self.input_transform == "multi_select":
            # 从输入的特征图列表中选择多个相应索引的特征图
            return [inputs[i] for i in self.in_features_idx]
        else:
            # 只选择对应的索引的特征图
            return inputs[self.in_features_idx]

    @abstractmethod
    def forward(self, inputs):
        pass


class BoxBaseHead(nn.Module):
    def __init__(self, num_share_con, num_cls_con, num_reg_con, in_channel, num_classes, prior_prob):
        """
        头结构的公共部分，即都会有两个分支：分类分支和回归分支
        """
        super().__init__()
        head_configs = {"cls": num_cls_con,
                        "bbox": num_reg_con,
                        "share": num_share_con}
        for head in head_configs:
            tower = []
            num_con = head_configs[head]
            for i in range(num_con):
                tower.append(nn.Conv2d(in_channel, in_channel, kernel_size=3, stride=1, padding=1, bias=True))
                tower.append(nn.BatchNorm2d(in_channel))
                tower.append(nn.ReLU())
            self.add_module('{}_tower'.format(head), nn.Sequential(*tower))

        self.cls_logits = nn.Conv2d(in_channel, num_classes, kernel_size=3, stride=1, padding=1)
        self.bbox_pred = nn.Conv2d(in_channel, 4, kernel_size=3, stride=1, padding=1)

        for modules in [self.cls_tower, self.bbox_tower, self.share_tower, self.cls_logits, self.bbox_pred]:
            for module in modules.modules():
                if isinstance(module, nn.Conv2d):
                    torch.nn.init.normal_(module.weight, std=0.01)
                    torch.nn.init.constant_(module.bias, 0)

        # initialize the bias for focal loss
        bias_value = -math.log((1 - prior_prob) / prior_prob)
        torch.nn.init.constant_(self.cls_logits.bias, bias_value)

    def base_forward(self, input_data):
        """
        该头结构基类可以处理多级特征映射，以单级特征映射来说，有如下结构：
                             单级特征映射
                                 |
                  ###########多层共享卷积###########
                        |                  |
                  多层分类共享卷积      多层回归共享卷积
                        |                  |
                    分类输出卷积         回归输出卷积
        :param input_data: TensorPackage对象，包含了tensor以及tensor的大小、通道数属性
        :return:
        """
        tensor_list = input_data.tensor
        logits = []
        bbox_reg = []
        reg_share = []
        cls_share = []
        for feature in tensor_list:
            feature = self.share_tower(feature)    # 多层共享卷积
            cls_tower = self.cls_tower(feature)    # 多层分类共享卷积
            bbox_tower = self.bbox_tower(feature)  # 多层回归共享卷积
            reg_share.append(bbox_tower)
            cls_share.append(cls_tower)

            logits.append(self.cls_logits(cls_tower))
            reg = self.bbox_pred(bbox_tower)
            bbox_reg.append(F.relu(reg))
        return cls_share, reg_share, logits, bbox_reg


class BaseMatch(nn.Module):
    def __init__(self, logits_pred, reg_pred, gt_instances):
        """
        特征点匹配基类，将特征映射中的每个特征点与gt边框进行匹配
        :param logits_pred: 分类特征映射
        :param reg_pred: 回归特征映射
        :param gt_instances: groundtrue，其中包含各个标签属性
        """
        super().__init__()
        self.logits_pred = logits_pred
        # 根据回归特征映射获取每一级特征映射的步长（当前特征映射大小相对于输入图片而言）
        self.strides = []
        self.reg_pred = reg_pred
        self.num_classes = logits_pred[0].size()[-3]
        self.gt_instances = gt_instances  # 包含多个instance对象的列表

    def match_gt_and_tensor_by_location(self, locations, gt_instances):
        """
        通过位置信息将gt边框和多级特征映射的每一个特征映射进行匹配
        :param locations: 多行两列的一个矩阵，包含了多级特征映射中所有的位置信息
        :param gt_instances: 包含多个instance对象的列表，单个instance对象中包含了对应的图片的所有标注信息
        :return:
        """
        labels = []
        reg_targets = []
        target_inds = []

        # 提取出所有位置的横坐标和纵坐标信息
        xs, ys = locations[:, 0], locations[:, 1]
        # 开始依次处理每张图片（一次送入网络中的图片，可能是1张，也可能是多张）
        for im_i in range(len(gt_instances)):
            targets_per_im = gt_instances[im_i]        # 取出单张图片的标签
            bboxes = targets_per_im.gt_boxes.tensor    # 取出标签中的所有边框信息（一张图片可能有1个或多个边框）
            labels_per_im = targets_per_im.gt_classes  # 取出标签中边框对应的类型信息

            # 异常处理，当标签中没有边框信息时，需要进行赋值处理
            if bboxes.numel() == 0:
                # 边框类别赋值为self.num_classes，该类别不存在，真实的类别是从0到self.num_classes-1
                labels.append(labels_per_im.new_zeros(locations.size(0)) + self.num_classes)
                # 边框赋值为全零
                reg_targets.append(locations.new_zeros((locations.size(0), 4)))
                # 每个特征映射位置对应的gt边框的编号为-1，该编号也不存在
                target_inds.append(labels_per_im.new_zeros(locations.size(0)) - 1)
                continue

            # 计算出每个特征位置到每个gt边框的左边界、上边界、右边界、下边界的距离
            left = xs[:, None] - bboxes[:, 0][None]
            top = ys[:, None] - bboxes[:, 1][None]
            right = bboxes[:, 2][None] - xs[:, None]
            bottom = bboxes[:, 3][None] - ys[:, None]
            reg_targets_per_im = torch.stack([left, top, right, bottom], dim=2)  # 输出
            reg_targets.append(reg_targets_per_im)

        return reg_targets

    @staticmethod
    def feature_points_to_gt_border_distance(locations, bboxes):
        """
        计算单张图片中所有特征点到所有gt边框四个边界的距离
        :param locations: 多行两列的一个矩阵，包含了多级特征映射中所有的位置信息
        :param bboxes: 多行4列的二维矩阵，包含了单张图片的所有边框信息
        :return:
        """
        # 提取出所有位置的横坐标和纵坐标信息
        xs, ys = locations[:, 0], locations[:, 1]

        # 计算出每个特征位置到每个gt边框的左边界、上边界、右边界、下边界的距离
        left = xs[:, None] - bboxes[:, 0][None]
        top = ys[:, None] - bboxes[:, 1][None]
        right = bboxes[:, 2][None] - xs[:, None]
        bottom = bboxes[:, 3][None] - ys[:, None]
        reg_target_per_im = torch.stack([left, top, right, bottom], dim=2)  # 输出

        return reg_target_per_im
