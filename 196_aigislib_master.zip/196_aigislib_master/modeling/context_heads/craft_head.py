"""
车志忠
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from ..builder import HEADS


class double_conv(nn.Module):
    def __init__(self, in_ch, mid_ch, out_ch):
        super(double_conv, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, mid_ch, kernel_size=1),
            nn.BatchNorm2d(mid_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_ch, out_ch, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = self.conv(x)
        return x


@HEADS.register()
class CRAFT_Head(nn.Module):
    def __init__(self, cfg, **kwargs):
        super(CRAFT_Head, self).__init__()
        # self.input_feature = [0]
        # self.input_channel = [256]
        self.input_max_size = cfg.MODEL.HEADS.IN_MAX_SIZE
        self.out_size = cfg.MODEL.HEADS.OUT_SIZE
        self.up_ratio = self.out_size / self.input_max_size
        self.device = torch.device(cfg.MODEL.DEVICE)
        output_channel = cfg.MODEL.HEADS.OUT_CHANNELS
        self.input_channel = cfg.MODEL.HEADS.IN_CHANNELS
        self.upconv = []
        rever_input_channel = [channel_num for channel_num in reversed(self.input_channel)]
        for num, i in enumerate(rever_input_channel):
            if num == 0:
                if len(rever_input_channel) == 1:
                    self.upconv.append(
                        double_conv(i, 512 // (2 ** num), i).to(self.device)
                    )
                    self.middle_channel = i
                    break
                continue
            self.upconv.append(
                double_conv(i+rever_input_channel[num-1], 512//(2**num), i).to(self.device)
            )
            if num == len(rever_input_channel) - 1:
                self.middle_channel = i
        self.conv_cls = nn.Sequential(
            nn.Conv2d(self.middle_channel, 32, kernel_size=3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(32, 32, kernel_size=3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(32, 16, kernel_size=3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(16, 16, kernel_size=1), nn.ReLU(inplace=True),
            nn.Conv2d(16, output_channel, kernel_size=1),
        ).to(self.device)

    def forward(self, x):
        """ Base network """
        sources = [i for i in reversed(x)]
        """ U network """
        if len(sources) == 1:
            y = self.upconv[0](sources[0])
            y = F.interpolate(y,
                              size=(int(y.size()[2] * self.up_ratio),
                                    int(y.size()[3] * self.up_ratio)),
                              mode='bilinear',
                              align_corners=False)
        else:
            for num in range(1, len(sources)):
                y = F.interpolate(sources[num-1],
                                  size=sources[num].size()[2:],
                                  mode='bilinear',
                                  align_corners=False)
                y = torch.cat([y, sources[num]], dim=1)
                y = self.upconv[num-1](y)
            y = F.interpolate(y,
                              size=(int(y.size()[2] * self.up_ratio),
                                    int(y.size()[3] * self.up_ratio)),
                              mode='bilinear',
                              align_corners=False)

        y = self.conv_cls(y)

        return y  # .permute(0, 2, 3, 1)
