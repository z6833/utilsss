
from collections import namedtuple


__all__ = ["TensorPackage"]


TensorPackage = namedtuple('TensorPackage', ['tensor', 'size', 'channel', 'stride', 'multi_tensor'])
