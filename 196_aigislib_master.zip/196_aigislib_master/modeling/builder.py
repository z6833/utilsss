from detectron2.utils.registry import Registry

COMPARATOR = Registry('COMPARATOR')
HEADS = Registry("HEADS")
NECKS = Registry("NECKS")
DECODERS = Registry("DECODERS")
LOSSES = Registry("LOSSES")
EVALUATIONS = Registry("EVALUATIONS")


HEADS.__doc__ = """
Registry for heads, which is for extract difference feature

"""
NECKS.__doc__ = """
Registry for neck, which is for extract difference feature

"""
DECODERS.__doc__ = """
Registry for decoders, which is for extract difference feature

"""
EVALUATIONS.__doc__ = """
Registry for heads, which is for extract difference feature

"""


def build_heads(cfg):
    """
        构建context head
    """
    head_name = cfg.MODEL.HEADS.NAME
    if not head_name:
        return None
    head = HEADS.get(head_name)(cfg)
    return head


def build_necks(cfg):
    """
        构建neck
    """
    neck_name = cfg.MODEL.NECKS.NAME
    if not neck_name:
        return None
    neck = NECKS.get(neck_name)(cfg)
    return neck


def build_decoders(cfg):
    """
        构建decode head
    """
    decoder_name = cfg.MODEL.DECODERS.NAME
    if not decoder_name:
        return None
    decoder = DECODERS.get(decoder_name)(cfg)
    return decoder


def build_losses(cfg):
    """
        构建loss函数
    """
    loss_type = cfg.MODEL.LOSS.LOSS_TYPE
    loss = LOSSES.get(loss_type)(cfg)
    return loss


def build_evaluations(cfg):
    """
        构建评估函数
    """
    evaluation_type = cfg.EVALUATIONS.NAME
    evaluation = EVALUATIONS.get(evaluation_type)(cfg)
    return evaluation
