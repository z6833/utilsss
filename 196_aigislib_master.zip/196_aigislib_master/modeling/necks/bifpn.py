import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List

from detectron2.config import configurable
from collections import Iterable
from ..builder import NECKS


def split_name(name):
    """ 分离字符串中的字母和数字 """
    for i, c in enumerate(name):
        if not c.isalpha():
            return name[:i], name[i:]
    raise ValueError("name is not contain digital.")


def __init_weight(model, conv_init, **kwargs):
    """ 模型权重初始化函数"""
    for m in model.modules():
        if isinstance(m, nn.Conv2d):
            m.weight = conv_init(m.weight)
        elif isinstance(m, nn.BatchNorm2d):
            nn.init.constant_(m.weight, 1)
            nn.init.constant_(m.bias, 0)


def init_weight(model_list, conv_init, **kwargs):
    if isinstance(model_list, list):
        for layer in model_list:
            __init_weight(layer, conv_init, **kwargs)
    else:
        __init_weight(model_list, conv_init, **kwargs)


class Conv2dStaticSamePadding(nn.Module):
    """
    卷积采用相同填充
    """

    def __init__(self, in_channels, out_channels, kernel_size, stride=1, groups=1, bias=True):
        super(Conv2dStaticSamePadding, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride,
                              groups=groups, bias=bias)
        self.kernel_size = self.conv.kernel_size
        self.stride = self.conv.stride

        if isinstance(self.kernel_size, int):
            self.kernel_size = [self.kernel_size] * 2
        elif len(self.kernel_size) == 1:
            self.kernel_size = [self.kernel_size[0]] * 2

        if isinstance(self.stride, int):
            self.stride = [self.stride] * 2
        elif len(self.stride) == 1:
            self.stride = [self.stride[0]] * 2

        init_weight(self, nn.init.kaiming_normal_, mode='fan_in', nonlinearity='relu')

    def forward(self, x):
        h, w = x.shape[-2:]

        extra_h = (math.ceil(w / self.stride[1]) - 1) * self.stride[1] - w + self.kernel_size[1]
        extra_w = (math.ceil(h / self.stride[0]) - 1) * self.stride[0] - h + self.kernel_size[0]

        # 左右填充大小
        left = extra_h // 2
        right = extra_h - left
        top = extra_w // 2
        bottom = extra_w - top

        x = F.pad(x, [left, right, top, bottom])
        x = self.conv(x)

        # print(x.shape)

        return x


class SeparableConvBlock(nn.Module):
    """
    使用深度分离卷积
    细节：深度级卷积不使用bias, 仅在点级卷积时使用偏差
    """

    def __init__(self, in_channels, out_channels=None, norm=True, activation=False):
        super(SeparableConvBlock, self).__init__()
        if out_channels is None:
            out_channels = in_channels

        self.depthwise_conv = Conv2dStaticSamePadding(in_channels, out_channels,
                                                      kernel_size=3, stride=1, groups=1, bias=False)
        self.pointwise_conv = Conv2dStaticSamePadding(in_channels, out_channels,
                                                      kernel_size=1, stride=1, groups=1, bias=True)
        self.norm = norm
        if self.norm:
            self.bn = nn.BatchNorm2d(num_features=out_channels, momentum=0.01)
        self.activation = activation
        if self.activation:
            # self.act = Swish()          # 使用swish激活函数
            # self.act = H_Swish()        # 使用h_swish
            self.act = nn.ReLU(inplace=True)

        init_weight(self, nn.init.kaiming_normal_, mode='fan_in', nonlinearity='relu')

    def forward(self, x):
        out = self.depthwise_conv(x)
        if self.norm:
            out = self.bn(out)
        out = self.pointwise_conv(out)
        if self.activation:
            out = self.act(out)

        return out


class SingleBiFPN(nn.Module):
    """ 构建单个双向特征金子塔网络 """

    def __init__(self,
                 in_channels_list: List[int],
                 out_channels: int,
                 epsilon: float = 1e-6):
        super(SingleBiFPN, self).__init__()
        self.in_channels_list = in_channels_list

        if len(self.in_channels_list) == 4:
            fpn_channels = [i for i in in_channels_list]
        else:
            raise NotImplementedError

        out_channels = out_channels
        self.epsilon = epsilon
        self.p5_down_channels = nn.Sequential(
            Conv2dStaticSamePadding(fpn_channels[-1], out_channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
        self.p4_down_channels = nn.Sequential(
            Conv2dStaticSamePadding(fpn_channels[-2], out_channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
        self.p3_down_channels = nn.Sequential(
            Conv2dStaticSamePadding(fpn_channels[1], out_channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
        self.p2_down_channels = nn.Sequential(
            Conv2dStaticSamePadding(fpn_channels[0], out_channels, kernel_size=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

        # top-bottom path: 使用深度分离卷积
        self.conv4_up = SeparableConvBlock(out_channels, activation=True)
        self.conv3_up = SeparableConvBlock(out_channels, activation=True)
        self.conv2_up = SeparableConvBlock(out_channels, activation=True)
        # bottom-top path： 使用深度分离卷积
        self.conv3_down = SeparableConvBlock(out_channels, activation=True)
        self.conv4_down = SeparableConvBlock(out_channels, activation=True)
        self.conv5_down = SeparableConvBlock(out_channels, activation=True)
        # bottomj-top path: 下采样
        self.p3_down = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.p4_down = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.p5_down = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)
        # bottom-top path: 0611
        # self.p3_down = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=2, padding=1)
        # self.p4_down = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=2, padding=1)
        # self.p5_down = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1)

        # 带权融合: top-bottom
        self.p4_w1 = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.p4_w1_relu = nn.ReLU()
        self.p3_w1 = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.p3_w1_relu = nn.ReLU()
        self.p2_w1 = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.p2_w1_relu = nn.ReLU()
        # 带权融合：bottom-top
        self.p3_w2 = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
        self.p3_w2_relu = nn.ReLU()
        self.p4_w2 = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
        self.p4_w2_relu = nn.ReLU()
        self.p5_w2 = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.p5_w2_relu = nn.ReLU()

    def _upSampling(self, x, up_size):
        """ 双线性上采样 """
        out = F.interpolate(x, size=up_size, mode='bilinear', align_corners=True)
        return out

    def forward(self, feats):
        """
        Args:
            feats: list[Tensor]
        :return:
        """
        # tuple-->list
        feats = [_ for _ in feats]
        # print(feats[0].shape,feats[1].shape,feats[2].shape,feats[3].shape)
        feat5 = self.p5_down_channels(feats[3])
        feat4 = self.p4_down_channels(feats[2])
        feat3 = self.p3_down_channels(feats[1])
        feat2 = self.p2_down_channels(feats[0])

        # top-->bottom
        p4_w1 = self.p4_w1_relu(self.p4_w1)
        weight = p4_w1 / (torch.sum(p4_w1, dim=0) + self.epsilon)
        p4_up = self.conv4_up(F.relu(self._upSampling(feat5, feat4.shape[-2:]) * weight[0] + feat4 * weight[1]))

        p3_w1 = self.p3_w1_relu(self.p3_w1)
        weight = p3_w1 / (torch.sum(p3_w1, dim=0) + self.epsilon)
        p3_up = self.conv3_up(F.relu(self._upSampling(p4_up, feat3.shape[-2:]) * weight[0] + feat3 * weight[1]))

        p2_w1 = self.p2_w1_relu(self.p2_w1)
        weight = p2_w1 / (torch.sum(p2_w1, dim=0) + self.epsilon)
        p2_out = self.conv2_up(F.relu(self._upSampling(p3_up, feat2.shape[-2:]) * weight[0] + feat2 * weight[1]))

        # bottom-top
        p3_w2 = self.p3_w2_relu(self.p3_w2)
        weight = p3_w2 / (torch.sum(p3_w2, dim=0) + self.epsilon)
        p3_out = self.conv3_down(F.relu(feat3 * weight[0] + p3_up * weight[1] + self.p3_down(p2_out) * weight[2]))

        p4_w2 = self.p4_w2_relu(self.p4_w2)
        weight = p4_w2 / (torch.sum(p4_w2, dim=0) + self.epsilon)
        p4_out = self.conv4_down(F.relu(feat4 * weight[0] + p4_up * weight[1] + self.p4_down(p3_out) * weight[2]))

        p5_w2 = self.p5_w2_relu(self.p5_w2)
        weight = p5_w2 / (torch.sum(p5_w2, dim=0) + self.epsilon)
        p5_out = self.conv5_down(F.relu(feat5 * weight[0] + self.p5_down(p4_out) * weight[1]))

        return tuple([p2_out, p3_out, p4_out, p5_out])


@NECKS.register()
class BiFPN(nn.Module):
    """
    双向特征金字塔网络
    Args:
            in_channels_list: List(int)
    """
    @configurable
    def __init__(
            self,
            in_channels: List[int],
            out_channels: int,
            num_repeat: int = 1,
            device: str = 'cuda'
    ):
        """
        Args:
            in_channels (List(int)): input channels of BiFPN
            out_channels (int): output channels of BiFPN
            num_repeat (int): repeat num of BiFPN
        """
        super(BiFPN, self).__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_repeats = num_repeat

        self.device = torch.device(device)

        assert len(self.in_channels) == 4, "BiFPN is supported 4 inputs."
        self.out_feature_channels = [self.out_channels for _ in range(len(self.in_channels))]
        # 构建BiFPN
        self.repeated_BiFPN = nn.ModuleList()
        for i in range(self.num_repeats):
            if i == 0:
                next_feature_channels = self.in_channels
            else:
                next_feature_channels = self.out_feature_channels
            self.repeated_BiFPN.append(SingleBiFPN(next_feature_channels, self.out_channels).to(self.device))

        # share conv
        self.share_conv = nn.Sequential(
            nn.Conv2d(self.out_channels, self.out_channels, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(self.out_channels),
            nn.ReLU(inplace=True)
        ).to(self.device)

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.NECKS.IN_CHANNELS,
            out_channels=cfg.MODEL.NECKS.OUT_CHANNELS,
            num_repeat=cfg.MODEL.NECKS.NUM_REPEAT,
            device=cfg.MODEL.DEVICE
        )
        return ret

    def forward(self, inputs):
        """
        Args:
            inputs: List(Tensor)
        Returns:
            out: List(Tensor)
        """
        # c2, c3, c4, c5
        feats = inputs
        # print(feats[0].shape,feats[1].shape,feats[2].shape,feats[3].shape)
        if not isinstance(inputs, Iterable):
            raise ValueError("inputs is not Iterable.")
        assert len(feats) == len(self.in_channels), "num of inputs feature is not equie input feature."
        # 根据BIFPN的个数，可以重复使用BIFPN来计算特征
        for module in self.repeated_BiFPN:
            feats = module(feats)  # p2, p3, p4, p5
        # 对BIFPN的输出特征使用共享卷积进行处理
        bifpn_out = [self.share_conv(feat) for feat in feats]
        return tuple(bifpn_out)
