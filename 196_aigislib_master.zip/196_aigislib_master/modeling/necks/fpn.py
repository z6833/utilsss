
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Optional
import fvcore.nn.weight_init as weight_init

from detectron2.config import configurable
from detectron2.layers import Conv2d
from detectron2.config import CfgNode as CN
from detectron2.config.defaults import _C

from ..builder import NECKS
from ..utils.data_structrue import TensorPackage


@NECKS.register()
class FPN(nn.Module):
    """ 构建特征金字塔网络 """
    @configurable
    def __init__(self,
                 in_channels: List[int],
                 out_channels: int,
                 start_level: int = 0,
                 end_level: int = -1,
                 add_extra_convs: Optional[str] = None,
                 num_out_features: Optional[int] = None,
                 device: str = 'cuda'
                 ):
        """
        Args:
            in_channels(List[int]): 存放多尺度特征的输入通道数；
            out_channels(int): 作用在每个尺度上的输出通道数
            num_outs(int): 输出的尺度数目
            start_level(int): 开始进行FPN层的索引
            end_level(int): 结束FPN层的索引
            add_extra_convs(Optional): 是否需要添加额外的卷积层
            num_out_features(Optional): 最终输出的特征通道数
        """
        super(FPN, self).__init__()
        assert isinstance(in_channels, list), "input channels is not multiply."
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_in = len(self.in_channels)
        # FPN开始层以及结束层
        self.start_level = start_level
        self.end_level = end_level
        self.add_extra_convs = add_extra_convs
        self.num_out_features = num_out_features
        self.device = torch.device(device)

        # 计算输入和输出个数
        if end_level == -1:
            self.backbone_end_level = self.num_in
        else:
            self.backbone_end_level = end_level
            assert end_level <= self.num_in, "the index of end level is greater than number of the input!"

        # 验证额外层的类型，以及判断是在那个加入额外卷积层
        assert isinstance(self.add_extra_convs, (str, bool)), "add extra convs type must be string."
        if isinstance(self.add_extra_convs, str):
            assert self.add_extra_convs in ("on_input", "on_lateral", "on_output")

        # 构建横向连接和多尺度输出
        lateral_conv_list = []
        fpn_conv_list = []
        for i in range(self.start_level, self.backbone_end_level):
            lateral_conv = nn.Sequential(
                nn.Conv2d(in_channels[i], out_channels, kernel_size=1, stride=1, padding=0),
                nn.BatchNorm2d(out_channels),
                nn.ReLU()
            ).to(self.device)
            lateral_conv_list.append(lateral_conv)

            fpn_conv = nn.Sequential(
                nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1),
                nn.BatchNorm2d(out_channels),
                nn.ReLU()
            ).to(self.device)
            fpn_conv_list.append(fpn_conv)

        self.lateral_conv_list = nn.ModuleList(lateral_conv_list)
        self.fpn_conv_list = nn.ModuleList(fpn_conv_list)

        # 添加额外卷积层，用于FCOS, retinanet
        extra_levels = num_out_features - self.backbone_end_level + start_level
        if self.add_extra_convs and extra_levels > 0:
            for i in range(extra_levels):
                if i == 0 and self.add_extra_convs == "on_input":
                    in_channels = self.in_channels[self.backbone_end_level - 1]
                else:
                    in_channels = self.out_channels
                extra_convs = Conv2d(in_channels,
                                     self.out_channels,
                                     kernel_size=3,
                                     stride=2,
                                     padding=1,
                                     )
                self.fpn_conv_list.append(extra_convs)

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.NECKS.IN_CHANNELS,
            out_channels=cfg.MODEL.NECKS.OUT_CHANNELS,
            start_level=cfg.MODEL.NECKS.START_LEVEL,
            end_level=cfg.MODEL.NECKS.END_LEVEL,
            add_extra_convs=cfg.MODEL.NECKS.ADD_EXTRA_CONVS,
            num_out_features=cfg.MODEL.NECKS.NUM_OUT_FEATURES,
            device=cfg.MODEL.DEVICE
        )
        return ret

    def forward(self, inputs):
        """
        Args:
            inputs: List[tensor], (c2, c3, c4, c5)
            return: Tuple[tensor]
        """
        assert len(inputs) == len(self.in_channels), "The number of inputs and in_channels must be match."

        # 1.lateral
        lateral_feat = []
        for i in range(self.start_level, self.backbone_end_level):
            feat = self.lateral_conv_list[i](inputs[i + self.start_level])
            lateral_feat.append(feat)

        # 2.top-down path
        used_backbone_levels = len(lateral_feat)
        for i in range(used_backbone_levels-1, 0, -1):
            prev_shape = lateral_feat[i-1].size()[2:]
            lateral_feat[i-1] += F.interpolate(lateral_feat[i], size=prev_shape,
                                               mode='bilinear', align_corners=True)

        # 3.fpn out
        outs = []
        for i in range(0, used_backbone_levels):
            outs.append(self.fpn_conv_list[i](lateral_feat[i]))

        # extra convs level
        if self.num_out_features > len(outs):
            if self.add_extra_convs == "on_input":
                extra_inputs = inputs[-1]
            elif self.add_extra_convs == "on_lateral":
                extra_inputs = lateral_feat[-1]
            elif self.add_extra_convs == "on_output":
                extra_inputs = outs[-1]
            else:
                raise NotImplementedError
            # 处理额外层的输入
            outs.append(self.fpn_conv_list[used_backbone_levels](extra_inputs))
            for i in range(used_backbone_levels + 1, self.num_out_features):
                outs.append(self.fpn_conv_list[i](outs[-1]))

        return tuple(outs)


@NECKS.register()
class FPNNeck(nn.Module):
    """
    输入为一个多级特征映射，输出为一个融合了尺度间信息的多级特征映射
    """
    @configurable
    def __init__(self, device, in_channels, out_channel, middle_channel=256):
        """
        :param device: 设备类型
        :param in_channels: 输入张量的通道数
        :param out_channel: 输出张量的通道数
        :param middle_channel: 中间层的张量通道数
        """
        super(FPNNeck, self).__init__()
        self.device = device
        self.lateral_cons = []
        self.output_cons = []
        self.out_channel = out_channel
        for idx in range(len(in_channels)-1, -1, -1):
            lateral_con = nn.Conv2d(in_channels[idx], middle_channel, kernel_size=1).to(device)
            output_con = nn.Conv2d(middle_channel, out_channel, kernel_size=3, stride=1, padding=1).to(device)
            weight_init.c2_xavier_fill(lateral_con)
            weight_init.c2_xavier_fill(output_con)
            self.lateral_cons.append(lateral_con)
            self.output_cons.append(output_con)
        self.lateral_cons = nn.Sequential(*self.lateral_cons)
        self.output_cons = nn.Sequential(*self.output_cons)

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            device=cfg.MODEL.DEVICE,
            in_channels=cfg.MODEL.FPNNeck.IN_CHANNELS,    # 有一系列正整数组成的列表
            out_channel=cfg.MODEL.FPNNeck.OUT_CHANNEL,  # 默认情况下，neck结构输出的多级特征映射具有相同的通道数，所以可以是单个整数
            middle_channel=cfg.MODEL.FPNNeck.MIDDLE_CHANNEL,  # FPN特征结构的所有中间特征映射都将具有相同的通道数，默认为256
        )
        return ret

    @staticmethod
    def up_sample_add(small_tensor, large_tensor):
        """
        将两个张量进行合并
        :param small_tensor: 小尺寸张量
        :param large_tensor: 大尺寸张量
        :return:
        """
        _, _, h, w = large_tensor.size()
        return F.upsample(small_tensor, size=(h, w), mode='bilinear') + large_tensor

    @staticmethod
    def from_small_to_large(size_list):
        """
        判断特征列表中的特征是否是按照尺寸从小到大的顺序排放
        :param size_list:
        :return:
        """
        if len(size_list) == 1:
            return True
        last_size = None
        for ind, size in enumerate(size_list):
            if ind == 0:
                last_size = size
                continue
            if size[0] >= last_size[0]:
                pass
            else:
                return False
        return True

    def forward(self, input_data):
        result_list = []
        # 获取输入数据和相关属性
        tensor_list = input_data.tensor
        size_list = input_data.size
        stride_list = input_data.stride
        # 判断当前张量列表中的张量是否为从小到大
        is_small_to_large = self.from_small_to_large(size_list)
        # 将张量列表中的张量处理为从小到大的排列顺序
        if not is_small_to_large:
            tensor_list = [tensor for tensor in reversed(tensor_list)]
            size_list = [size for size in reversed(size_list)]
            stride_list = [stride for stride in reversed(stride_list)]
        last_middle_tensor = None
        for ind, (tensor, size) in enumerate(zip(tensor_list, size_list)):
            if ind == 0:
                last_middle_tensor = self.lateral_cons[0](tensor)
                result_list.append(self.output_cons[0](last_middle_tensor))
                continue
            last_middle_tensor = self.up_sample_add(last_middle_tensor, self.lateral_cons[ind](tensor))
            result_list.append(self.output_cons[ind](last_middle_tensor))

        # 输出的张量需要和输入的顺序保持相同
        if not is_small_to_large:
            result_list = [res for res in reversed(result_list)]
            size_list = [size for size in reversed(size_list)]
            stride_list = [stride for stride in reversed(stride_list)]
        channel_list = [res_tensor.size()[1] for res_tensor in result_list]
        res = TensorPackage(tensor=result_list, size=size_list, channel=channel_list,
                            stride=stride_list, multi_tensor=None)

        return res


def add_fpn_neck_config():
    """
    Add config for FPN.
    """
    _C.MODEL.FPNNeck = CN()
    _C.MODEL.FPNNeck.IN_CHANNELS = []
    _C.MODEL.FPNNeck.OUT_CHANNEL = 256
    _C.MODEL.FPNNeck.MIDDLE_CHANNEL = 256
