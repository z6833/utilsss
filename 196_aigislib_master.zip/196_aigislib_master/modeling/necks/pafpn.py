import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Optional
from detectron2.config import configurable

from ..builder import NECKS
from .fpn import FPN


@NECKS.register()
class PAFPN(FPN):
    """ Path aggregation FPN """
    @configurable
    def __init__(self,
                 in_channels: List[int],
                 out_channels: int,
                 start_level: int = 0,
                 end_level: int = -1,
                 add_extra_convs: Optional[str] = None,
                 num_out_features: Optional[int] = None,
                 device: str = "cuda",
                 ):
        super(PAFPN, self).__init__(
            in_channels,
            out_channels,
            start_level,
            end_level,
            add_extra_convs,
            num_out_features,
            device
        )
        # PAFPN Bottom-Up
        down_conv = nn.ModuleList()
        pafpn_conv = nn.ModuleList()
        for i in range(self.start_level+1, self.backbone_end_level):
            if i == self.backbone_end_level - 1:
                stride = 1
            else:
                stride = 2
            down_conv.append(
                nn.Sequential(
                    nn.Conv2d(self.out_channels, self.out_channels, kernel_size=3, stride=stride, padding=1),
                    nn.BatchNorm2d(self.out_channels),
                    nn.ReLU()
                ).to(self.device)
            )
            pafpn_conv.append(
                nn.Sequential(
                    nn.Conv2d(self.out_channels, self.out_channels, kernel_size=3, stride=1, padding=1),
                    nn.BatchNorm2d(self.out_channels),
                    nn.ReLU()
                ).to(self.device)
            )
        self.down_conv = down_conv
        self.pafpn_conv = pafpn_conv

        self.fpn_bottleneck = nn.Sequential(
            nn.Conv2d(len(self.in_channels) * self.out_channels, self.out_channels, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(self.out_channels),
            nn.ReLU()
        )

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.NECKS.IN_CHANNELS,
            out_channels=cfg.MODEL.NECKS.OUT_CHANNELS,
            start_level=cfg.MODEL.NECKS.START_LEVEL,
            end_level=cfg.MODEL.NECKS.END_LEVEL,
            add_extra_convs=cfg.MODEL.NECKS.ADD_EXTRA_CONVS,
            num_out_features=cfg.MODEL.NECKS.NUM_OUT_FEATURES,
            device=cfg.MODEL.DEVICE,
        )
        return ret

    def forward(self, inputs):
        """
        Args:
            inputs: List[int], c2, c3, c4, c5
            return: tuple[int]
        """
        assert len(inputs) == len(self.in_channels), "The number of inputs and in_channels must be match."

        # 1.lateral
        lateral_feat = []
        for i in range(self.start_level, self.backbone_end_level):
            feat = self.lateral_conv_list[i](inputs[i + self.start_level])
            lateral_feat.append(feat)       # p2, p3, p4, p5

        # 2.top-down path
        used_backbone_levels = len(lateral_feat)
        for i in range(used_backbone_levels - 1, 0, -1):
            lateral_feat[i - 1] = self._upsample_add(lateral_feat[i], lateral_feat[i - 1])

        # 3.fpn out
        fpn_out = []
        for i in range(0, used_backbone_levels):
            fpn_out.append(self.fpn_conv_list[i](lateral_feat[i]))  # (p2, p3, p4, p5)

        # 4.bottom-top
        for i in range(0, used_backbone_levels-1):
            fpn_out[i+1] += self.down_conv[i](fpn_out[i])

        # 5.pafpn out
        pafpn_out = [fpn_out[0]]
        for i in range(1, used_backbone_levels):
            pafpn_out.append(self.pafpn_conv[i-1](fpn_out[i]))

        return pafpn_out

    def _upsample_add(self, x, y):
        return F.interpolate(x, size=y.size()[2:], mode='bilinear', align_corners=True) + y
