import torch
import torch.nn as nn
from functools import partial
import math
from typing import List, Optional

from ..builder import NECKS
from detectron2.config import configurable


@NECKS.register()
class VIT_MLA(nn.Module):
    """ 构建MLA neck """

    @configurable
    def __init__(self, in_channels:List[int],
                 out_channels: int,
                 mla_index=[5, 11, 17, 23],
                 embed_dim=1024,
                 norm_layer=partial(nn.LayerNorm, eps=1e-6)):
        super(VIT_MLA, self).__init__()
        self.in_channels = in_channels[-1]
        self.out_channels = out_channels
        self.mla_index = mla_index
        self.embed_dim = embed_dim
        self.norm_layer = norm_layer

        self.mla_p2_1x1 = nn.Sequential(nn.Conv2d(
            self.in_channels, out_channels, 1, bias=False), nn.BatchNorm2d(out_channels), nn.ReLU())
        self.mla_p3_1x1 = nn.Sequential(nn.Conv2d(
            self.in_channels, out_channels, 1, bias=False), nn.BatchNorm2d(out_channels), nn.ReLU())
        self.mla_p4_1x1 = nn.Sequential(nn.Conv2d(
            self.in_channels, out_channels, 1, bias=False), nn.BatchNorm2d(out_channels), nn.ReLU())
        self.mla_p5_1x1 = nn.Sequential(nn.Conv2d(
            self.in_channels, out_channels, 1, bias=False), nn.BatchNorm2d(out_channels), nn.ReLU())
        self.mla_p2 = nn.Sequential(nn.Conv2d(out_channels, out_channels, 3, padding=1,
                                    bias=False), nn.BatchNorm2d(out_channels), nn.ReLU())
        self.mla_p3 = nn.Sequential(nn.Conv2d(out_channels, out_channels, 3, padding=1,
                                    bias=False), nn.BatchNorm2d(out_channels), nn.ReLU())
        self.mla_p4 = nn.Sequential(nn.Conv2d(out_channels, out_channels, 3, padding=1,
                                    bias=False), nn.BatchNorm2d(out_channels), nn.ReLU())
        self.mla_p5 = nn.Sequential(nn.Conv2d(out_channels, out_channels, 3, padding=1,
                                    bias=False), nn.BatchNorm2d(out_channels), nn.ReLU())

        self.norm_0 = self.norm_layer(self.embed_dim)
        self.norm_1 = self.norm_layer(self.embed_dim)
        self.norm_2 = self.norm_layer(self.embed_dim)
        self.norm_3 = self.norm_layer(self.embed_dim)

    def to_2D(self, x):
        n, hw, c = x.shape
        h = w = int(math.sqrt(hw))
        x = x.transpose(1, 2).reshape(n, c, h, w)
        return x

    def vit_neck(self, res2, res3, res4, res5):
        res2 = self.to_2D(res2)
        res3 = self.to_2D(res3)
        res4 = self.to_2D(res4)
        res5 = self.to_2D(res5)

        mla_p5_1x1 = self.mla_p5_1x1(res5)
        mla_p4_1x1 = self.mla_p4_1x1(res4)
        mla_p3_1x1 = self.mla_p3_1x1(res3)
        mla_p2_1x1 = self.mla_p2_1x1(res2)

        mla_p4_plus = mla_p5_1x1 + mla_p4_1x1
        mla_p3_plus = mla_p4_plus + mla_p3_1x1
        mla_p2_plus = mla_p3_plus + mla_p2_1x1

        mla_p5 = self.mla_p5(mla_p5_1x1)
        mla_p4 = self.mla_p4(mla_p4_plus)
        mla_p3 = self.mla_p3(mla_p3_plus)
        mla_p2 = self.mla_p2(mla_p2_plus)

        return mla_p5, mla_p5, mla_p5, mla_p5

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.NECKS.IN_CHANNELS,
            out_channels=cfg.MODEL.NECKS.OUT_CHANNELS,
            mla_index=cfg.MODEL.NECKS.MLA_INDEX,
            embed_dim=cfg.MODEL.NECKS.EMBED_DIM,
            norm_layer=partial(nn.LayerNorm, eps=1e-6),
        )
        return ret

    def forward(self, inputs):
        c6 = self.norm_0(inputs[self.mla_index[0]])
        c12 = self.norm_1(inputs[self.mla_index[1]])
        c18 = self.norm_2(inputs[self.mla_index[2]])
        c24 = self.norm_3(inputs[self.mla_index[3]])

        p6, p12, p18, p24 = self.vit_neck(c6, c12, c18, c24)

        return (p6, p12, p18, p24)