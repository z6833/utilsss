
import torch
from torch import nn
from detectron2.modeling import META_ARCH_REGISTRY
from detectron2.config import configurable
from detectron2.structures import ImageList
from detectron2.modeling.backbone import build_backbone
from detectron2.modeling.postprocessing import detector_postprocess

from aigislib.modeling.builder import build_necks
from aigislib.modeling.builder import build_heads
from ...utils.data_structrue import TensorPackage


__all__ = ["AnchorFreeDetector"]


@META_ARCH_REGISTRY.register()
class AnchorFreeDetector(nn.Module):
    """
    anchor free目标检测网络的元结构
    """
    @configurable
    def __init__(self,
                 backbone,
                 neck,
                 head,
                 pixel_mean,
                 pixel_std,
                 device):
        super().__init__()
        self.backbone = backbone
        self.neck = neck
        self.head = head
        self.device = device
        self.register_buffer("pixel_mean", torch.tensor(pixel_mean).view(-1, 1, 1), False)
        self.register_buffer("pixel_std", torch.tensor(pixel_std).view(-1, 1, 1), False)
        assert (
                self.pixel_mean.shape == self.pixel_std.shape
        ), f"{self.pixel_mean} and {self.pixel_std} have different shapes!"

    @classmethod
    def from_config(cls, cfg):
        device = cfg.MODEL.DEVICE
        return {
            "backbone":       build_backbone(cfg).to(device),
            "neck":           build_necks(cfg).to(device),
            "head":           build_heads(cfg).to(device),
            "pixel_mean":   cfg.MODEL.PIXEL_MEAN,
            "pixel_std":    cfg.MODEL.PIXEL_STD,
            "device": device,
        }

    def forward(self, batch_input):
        """
        边框检测的主入口
        :param batch_input: a list, DataMapper的输出,
            在list中每个元素是一个dict,包含：
                "image": Tensor(B,C,H,W)
                "bbox": ground truth box
        :return:
        """
        # 提取出所有的图片和对应标签并放在一起
        images = [x['image'].to(self.device) for x in batch_input]
        image_sizes = [x['image'].size()[1:] for x in batch_input]
        src_sizes = [(x['height'], x['width']) for x in batch_input]

        # 对图片进行归一化处理
        images = [self.preprocess(x) for x in images]
        images = ImageList.from_tensors(images).tensor
        # 送入backbone中进行特征提取，获得一个特征张量的字典
        backbone_feature = self.backbone(images)
        # 通过配置文件提取出backbone中待处理的特征张量，并用TensorPackage进行打包
        tensor_list = []
        size = []
        channel = []
        strides = []
        output_shape = self.backbone.output_shape()
        for key in backbone_feature:
            current_feature = backbone_feature[key]
            _, c, h, w = current_feature.size()
            size.append([h, w])
            channel.append(c)
            strides.append(output_shape[key].stride)
            tensor_list.append(current_feature)
        tensor_package_obj = TensorPackage(tensor=tensor_list, size=size, channel=channel,
                                           stride=strides, multi_tensor=None)
        # 获取多级特征中各个特征点的坐标位置，推理和损失计算都会用到
        location_list = self.compute_locations(tensor_list, strides)
        # 将打包好的TensorPackage对象送入neck结构中进行多级特征融合，同样得到一个TensorPackage对象
        tensor_package_obj = self.neck(tensor_package_obj)
        # 将从neck结构获得的TensorPackage对象送入头结构中，获得分类张量、回归张量
        tensor_package_obj = self.head(tensor_package_obj)
        # 如果为训练阶段，则将分类张量和回归张量送入self.loss()进行损失计算
        if self.training:
            gt_instances = [x['instances'] for x in batch_input]
            loss_dict = self.loss(tensor_package_obj, location_list, gt_instances)
            return loss_dict
        # 如果为推理阶段，则将分类张量和回归张量送入self.inference()进行推理映射
        else:
            res_dict = self.head.inference(tensor_package_obj, location_list, image_sizes)
            # 调整输出结果的尺寸
            new_instance_list = []
            for index, instance_obj in enumerate(res_dict['instances']):
                new_instance_list.append(
                    {'instances': detector_postprocess(instance_obj, src_sizes[index][0], src_sizes[index][1])}
                )
            return new_instance_list

    def preprocess(self, image):
        image = image - self.pixel_mean
        image = image / self.pixel_std
        return image

    def loss(self, tensor_package_obj, location_list, gt_instances):
        loss_dict = {}
        for obj in [self.backbone, self.neck, self.head]:
            if hasattr(obj, 'loss'):
                loss_dict.update(obj.loss(tensor_package_obj, location_list, gt_instances))
        return loss_dict

    def compute_locations(self, features, strides):
        """
        根据回归特征映射获取所有特征点的位置信息
        :param features: 多级特征映射组成的列表，来自backbone的输出
        :param strides: 多级特征映射对应的步长序列
        :return:
        """
        locations = []
        for level, feature in enumerate(features):
            h, w = feature.size()[-2:]
            # 计算出单级特征映射的每个位置，并以多行两列的形式展示
            locations_per_level = self.get_each_locations(h, w, strides[level])
            locations.append(locations_per_level)

        return locations

    def get_each_locations(self, h, w, stride):
        """
        计算单级特征映射的所有位置信息
        :param h: 当前特征映射的行数
        :param w: 当前特征映射的列数
        :param stride: 当前特征映射的步长
        :return: 多行两列的torch矩阵，即当前特征映射的所有横纵坐标
        """
        shifts_x = torch.arange(
            0, w * stride, step=stride,
            dtype=torch.float32, device=self.device
        )
        shifts_y = torch.arange(
            0, h * stride, step=stride,
            dtype=torch.float32, device=self.device
        )
        shift_y, shift_x = torch.meshgrid(shifts_y, shifts_x)
        shift_x = shift_x.reshape(-1)
        shift_y = shift_y.reshape(-1)
        locations = torch.stack((shift_x, shift_y), dim=1) + stride // 2
        return locations
