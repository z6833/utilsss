
import torch
import torch.nn as nn
from typing import List

from detectron2.utils.registry import Registry


comparator_registry = Registry('COMPARATOR')
comparator_registry.__doc__ = """
Registry for comparator
"""


def build_comparator(cfg):
    name = cfg.MODEL.COMPARATOR.NAME
    return comparator_registry.get(name)(cfg)


@comparator_registry.register()
class Comparator(nn.Module):
    """ 使用cat方式提取变化特征 """
    def __init__(self, cfg):
        super(Comparator, self).__init__()
        # 获取比较器方式
        self.comparator_mode = cfg.MODEL.COMPARATOR.MODE
        self.in_channels_list = cfg.MODEL.COMPARATOR.IN_CHANNELS_LIST
        self.out_channels = cfg.MODEL.COMPARATOR.OUT_CHANNELS

        self.cmp_conv = nn.ModuleList()
        if self.comparator_mode == "cat":
            for in_channel in self.in_channels_list:
                conv = nn.Sequential(
                    nn.Conv2d(in_channel * 2, in_channel, kernel_size=3, stride=1, padding=1),
                    nn.ReLU(inplace=True)
                )
                self.cmp_conv.append(conv)

        elif self.comparator_mode == "att":
            for in_channel in self.in_channels_list:
                attention = ChangeAttention(in_channel, in_channel)
                self.cmp_conv.append(attention)

    def forward(self, featsA: List[torch.Tensor], featsB: List[torch.Tensor]):
        assert len(featsA) == len(featsB), "the two feature map is not match."

        out = []
        if self.comparator_mode == "cat":
            # 拼接特征，然后1*1卷积获取变化特征
            # print(featsA[3].shape,featsB[3].shape)
            for i in range(len(featsA)):
                feat = torch.cat([featsA[i], featsB[i]], dim=1)
                feat = self.cmp_conv[i](feat)
                out.append(feat)
        elif self.comparator_mode == "att":
            # 使用注意力模块
            for i in range(len(featsA)):
                feat = self.cmp_conv[i](featsA[i], featsB[i])
                out.append(feat)
        return tuple(out)


class ChangeAttention(nn.Module):
    """ 变化特征注意力模块 """
    def __init__(self, in_channels, out_channels):
        super(ChangeAttention, self).__init__()
        self.gate_a = nn.Sequential(
            nn.Conv2d(in_channels*2, 1, kernel_size=1, bias=True),
            # nn.Conv2d(in_channels*2, 1, kernel_size=3, stride=1, padding=1, bias=True),
            nn.ReLU(inplace=True)
        )
        self.gate_b = nn.Sequential(
            nn.Conv2d(in_channels*2, 1, kernel_size=1, bias=True),
            #nn.Conv2d(in_channels*2, 1, kernel_size=3, stride=1, padding=1, bias=True),  # 改为3*3卷积
            nn.ReLU(inplace=True)
        )
        self.softmax = nn.Softmax(dim=1)
        # 去除混叠影响
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, featA, featB):
        cat_feat = torch.cat([featA, featB], dim=1)
        attention_vector_A = self.gate_a(cat_feat)
        attention_vector_B = self.gate_b(cat_feat)

        attention_vector = torch.cat([attention_vector_A, attention_vector_B], dim=1)
        attention_vector = self.softmax(attention_vector)
        attention_vector_A, attention_vector_B = attention_vector[:, 0:1, :, :], attention_vector[:, 1:2, :, :]
        merge = attention_vector_A * featA + attention_vector_B * featB

        out = self.conv(merge)
        return out
