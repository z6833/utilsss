import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List

from detectron2.config import configurable
from detectron2.structures import ImageList
from detectron2.modeling.meta_arch.build import META_ARCH_REGISTRY
from detectron2.modeling.backbone.build import build_backbone
from detectron2.layers import Conv2d

from aigislib.modeling.builder import build_heads
from .comparator import build_comparator
from aigislib.modeling.builder import build_necks
from aigislib.modeling.builder import build_decoders
from aigislib.modeling.builder import build_losses


@META_ARCH_REGISTRY.register()
class SiameseChangeDetector(nn.Module):
    """
    SiamseFPN for change detection
    """
    @configurable
    def __init__(self,
                 backbone: nn.Module,
                 context_head: nn.Module,
                 comparator: nn.Module,
                 neck: nn.Module,
                 decoder_head: nn.Module,
                 cls_criterion: nn.Module,
                 loss_weight: float,
                 num_classes: int,
                 device: str,
                 pixel_mean: List[float],
                 pixel_std: List[float]
                 ):
        super(SiameseChangeDetector, self).__init__()
        # 定义模型结构
        self.backbone = backbone
        self.context_head = context_head
        self.comparator = comparator

        self.neck = None
        if neck:
            self.neck = neck
            out_channels = self.neck.out_channels

        else:
            out_channels = self.context_head.out_channels
        # decoders
        self.decoder = decoder_head
        out_channels = self.decoder.out_channels
        # classify
        # self.classify = nn.Sequential(
        #     nn.Conv2d(out_channels, out_channels // 2, kernel_size=3, stride=1, padding=1),
        #     nn.ReLU(inplace=True),
        #     nn.Conv2d(out_channels // 2, num_classes, kernel_size=1)
        # )
        self.classify = Conv2d(
            out_channels, num_classes, kernel_size=1, stride=1, padding=0)
        nn.init.normal_(self.classify.weight, 0, 0.001)
        nn.init.constant_(self.classify.bias, 0)
        # 定义损失函数
        self.cls_criterion = cls_criterion
        self.cls_criterion = nn.CrossEntropyLoss(reduction='mean')
        self.loss_weight = loss_weight
        # 将模型feed到对应的设备
        self.device = torch.device(device)
        self.register_buffer("pixel_mean", torch.tensor(pixel_mean).view(-1, 1, 1), False)
        self.register_buffer("pixel_std", torch.tensor(pixel_std).view(-1, 1, 1), False)

    @classmethod
    def from_config(cls, cfg):
        # 获取变化检测所需的参数
        device = cfg.MODEL.DEVICE
        backbone = build_backbone(cfg)
        # backbone = build_cd_resnet_backbone(cfg)
        comparator = build_comparator(cfg)
        # 是否有CONTEXT HEADS部分
        if not cfg.MODEL.HEADS.NAME:
            context_head = None
        else:
            context_head = build_heads(cfg)
        # 是否存在NECKS部分
        if not cfg.MODEL.NECKS.NAME:
            neck = None
        else:
            neck = build_necks(cfg)
        decoder_head = build_decoders(cfg)

        # 定义损失函数
        cls_criterion = build_losses(cfg)
        ret = dict(
            backbone=backbone,
            context_head=context_head,
            comparator=comparator,
            neck=neck,
            decoder_head=decoder_head,
            cls_criterion=cls_criterion,
            loss_weight=cfg.MODEL.LOSS.LOSS_WEIGHT,
            num_classes=cfg.MODEL.DECODERS.NUM_CLASSES,
            device=device,
            pixel_mean=cfg.MODEL.PIXEL_MEAN,
            pixel_std=cfg.MODEL.PIXEL_STD,
        )
        return ret

    def forward(self, batch_input):
        """
        Args:
            input: a list, DataMapper的输出
            在list中每个元素是一个dict,包含：
            "image": (Tensor(B,C,H,W), ), 包含前时相（inpA）、后时相(inpB)
            "change_detection_file_name": ground truth

        """
        imageA = [x['pre_image'].to(self.device) for x in batch_input]
        imageA = [(x - self.pixel_mean) / self.pixel_std for x in imageA]
        imageA = ImageList.from_tensors(imageA).tensor

        imageB = [y['post_image'].to(self.device) for y in batch_input]
        imageB = [(y - self.pixel_mean) / self.pixel_std for y in imageB]
        imageB = ImageList.from_tensors(imageB).tensor
        assert imageA.dim() == 4 and imageA.dim() == imageB.dim(), "input image dim is wrong."
        assert imageA.size()[2:] == imageB.size()[2:], "inputA is not match inputB."

        # 添加真值标签
        if "change_detection" in batch_input[0]:
            targets = [x['change_detection'].to(self.device) for x in batch_input]
            targets = ImageList.from_tensors(targets).tensor
        else:
            targets = None
        # 孪生的骨干网络
        h, w = imageA.shape[2:]
        branchA = self.backbone(imageA)
        branchB = self.backbone(imageB)

        # 是否使用context head
        if self.context_head:
            branchA[-1] = self.context_head(branchA[-1])
            branchB[-1] = self.context_head(branchB[-1])
        # 提取变化特征
        compared_feat = self.comparator(branchA, branchB)
        # Neck
        if self.neck:
            neck_feat = self.neck(compared_feat)
        else:
            neck_feat = compared_feat

        # classify
        gate_feat = self.decoder(neck_feat)
        preds = self.classify(gate_feat)
        preds = F.interpolate(preds, size=(h, w), mode='bilinear', align_corners=True)

        if self.training:
            losses = self.losses(preds, targets)
            return losses
        processed_results = []
        for pred in preds:
            processed_results.append({"change_detection": pred})
        return processed_results

    def losses(self, preds, targets):
        assert preds.size()[2:] == targets.size()[1:], "predicts dim {} not equie to targets {}.".format(preds.size(),
                                                                                                         targets.size())
        loss = self.cls_criterion(preds, targets)
        losses = dict(
            loss_change_detection=loss * self.loss_weight
        )
        return losses
