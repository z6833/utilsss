import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List
from detectron2.config import configurable
from detectron2.modeling.meta_arch import META_ARCH_REGISTRY
from detectron2.modeling.backbone.build import build_backbone
from detectron2.structures import ImageList
from detectron2.layers import Conv2d

from aigislib.modeling.builder import build_heads, build_necks, build_decoders, build_losses


@META_ARCH_REGISTRY.register()
class EncoderDecoderSeg(nn.Module):
    @configurable
    def __init__(self,
                 backbone: nn.Module,
                 context_head: nn.Module,
                 neck: nn.Module,
                 decoder_head: nn.Module,
                 cls_criterion: nn.Module,
                 name:str,
                 loss_weight: float,
                 num_classes: int,
                 device: str,
                 pixel_mean: List[float],
                 pixel_std: List[float]
                 ):
        super(EncoderDecoderSeg, self).__init__()
        self.name = name
        self.num_classes = num_classes
        self.device = device
        self.backbone = backbone

        # context_head
        self.context_head=None
        if context_head is not None:
            self.context_head = context_head
            self.out_channels = self.context_head.out_channels
        # neck
        self.neck = None
        if neck is not None:
            self.neck = neck
            self.out_channels = self.neck.out_channels
        # decoder
        self.decoder = None
        if decoder_head is not None:
            self.decoder = decoder_head
            self.out_channels = self.decoder.out_channels

        # classify
        # self.classify = nn.Sequential(
        #     # nn.Conv2d(out_channels, out_channels//2, kernel_size=3, stride=1, padding=1),
        #     # nn.ReLU(inplace=True),
        #     nn.Conv2d(out_channels//2, self.num_classes, kernel_size=1)
        # )
        self.cls = nn.Conv2d(4 * self.out_channels, self.num_classes, 3, padding=1)
        self.classify = Conv2d(
            self.out_channels, self.num_classes, kernel_size=1, stride=1, padding=0)
        nn.init.normal_(self.classify.weight, 0, 0.001)
        nn.init.constant_(self.classify.bias, 0)

        self.cls_criterion = cls_criterion
        self.cls_criterion = nn.CrossEntropyLoss(reduction='mean')
        self.loss_weight = loss_weight
        self.register_buffer("pixel_mean", torch.tensor(pixel_mean).view(-1, 1, 1), False)
        self.register_buffer("pixel_std", torch.tensor(pixel_std).view(-1, 1, 1), False)

    @classmethod
    def from_config(cls, cfg):
        """
        Args:
            cfg (CfgNode): cfgNode object
        """
        # 通过cfg构建语义分割各模块
        device = cfg.MODEL.DEVICE
        backbone = build_backbone(cfg)
        # 是否有CONTEXT HEADS部分
        if not cfg.MODEL.HEADS.NAME:
            context_head = None
        else:
            context_head = build_heads(cfg)
        # 是否存在NECKS部分
        if not cfg.MODEL.NECKS.NAME:
            neck = None
        else:
            neck = build_necks(cfg)
        # 是否有DECODERS HEADS部分
        if not cfg.MODEL.DECODERS.NAME:
            decoder_head = None
        else:
            decoder_head = build_decoders(cfg)
        # 定义损失函数
        cls_criterion = build_losses(cfg)
        ret = dict(
            backbone=backbone,
            context_head=context_head,
            neck=neck,
            decoder_head=decoder_head,
            cls_criterion=cls_criterion,
            name=cfg.MODEL.DECODERS.NAME,
            loss_weight=cfg.MODEL.LOSS.LOSS_WEIGHT,
            num_classes=cfg.MODEL.NUM_CLASSES,
            device=device,
            pixel_mean=cfg.MODEL.PIXEL_MEAN,
            pixel_std=cfg.MODEL.PIXEL_STD,
        )
        return ret

    def forward(self, batch_input):
        """
        Args:
            input: a list, DataMapper的输出
            在list中每个元素是一个dict,包含：
            "image": Tensor(B,C,H,W)
            "sem_seg": ground truth
        """
        images = [x['image'].to(self.device) for x in batch_input]
        images = [(x - self.pixel_mean) / self.pixel_std for x in images]
        images = ImageList.from_tensors(images).tensor
        gt_flag = 'sem_seg' in batch_input[0]
        # 处理标签
        if gt_flag:
            targets = [x['sem_seg'].to(self.device) for x in batch_input]
            # list[tensor] --> batch tensor
            targets = ImageList.from_tensors(targets).tensor
            targets[targets >= 1] = 1
        else:
            targets = None

        h, w = images.size()[2:]
        # 骨干网络计算
        features = self.backbone(images)
        # 是否使用context head
        if self.context_head:
            features[-1] = self.context_head(features[-1])
        # 判断是否有neck，并进行计算
        if self.neck:
            inter_features = self.neck(features)
        else:
            inter_features = features
        # 判断是否有decoder head，并进行计算
        # decoders，将head或者neck的输出进行融合，用于后续的分类层处理
        if self.decoder:
            decoder_features = self.decoder(inter_features)
        else:
            decoder_features = features[-1]
        if self.name=="VIT_MLAHead":
            preds = self.cls(decoder_features)
        else:
            preds= self.classify(decoder_features)
        preds = F.interpolate(preds, size=(h, w), mode='bilinear', align_corners=True)
        if self.training:
            losses = self.loss(preds, targets)
            return losses
        processed_results = []
        for pred in preds:
            processed_results.append({"sem_seg": pred})
        return processed_results

    def loss(self, preds, labels):
        """ 计算loss """
        assert preds.size()[2:] == labels.size()[1:], "predicts dim not equie to labels."
        loss = self.cls_criterion(preds, labels)
        losses = dict(
            loss_sem_seg=loss * self.loss_weight
        )
        return losses
