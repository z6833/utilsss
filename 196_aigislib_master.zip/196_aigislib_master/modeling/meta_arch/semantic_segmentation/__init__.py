from .segmentorED import EncoderDecoderSeg
