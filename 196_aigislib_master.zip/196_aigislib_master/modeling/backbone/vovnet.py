"""
VOVNetv2: https://github.com/youngwanLEE/vovnet-detectron2
代码实现基于v1
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

import fvcore.nn.weight_init as weight_init
from detectron2.layers import Conv2d, get_norm
from detectron2.modeling.backbone import Backbone


class VoVNet(Backbone):
    """
    VoVNet outpeferm Densenet
    """
    def __init__(self,
                 cfg):
        """
        Args:
            cfg: cfg.MODEL.VOVNET
        """
        super(VoVNet, self).__init__()
        stage_channels = cfg['STAGE_CHANNELS']
        concat_channels = cfg['CONCAT_CHANNELS']
        block_per_stage = cfg['BLOCK_PER_STAGE']
        layer_per_block = cfg['LAYER_PER_BLOCK']
        SE = cfg['eSe']
        norm = cfg['NORM']

        # stem module
        self.conv1 = Conv2d(
            3,
            64,
            kernel_size=3,
            stride=2,
            padding=1,
            bias=False,
            norm=get_norm(norm, 64),
        )
        self.conv2 = Conv2d(
            64,
            64,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=False,
            norm=get_norm(norm, 64)
        ),
        self.conv3 = Conv2d(
            64,
            128,
            kernel_size=3,
            stride=2,
            padding=1,
            bias=False,
            norm=get_norm(norm, 128)
        )

        inchannels_list = [128] + concat_channels[:-1]
        # OSA stages
        self.stage_name = []
        for i in range(4):
            name = f"stage{i+2}"
            self.stage_name.append(name)
            self.add_module(name,
                            OSAModule_stage(inchannels_list[i],
                                            stage_channels[i],
                                            concat_channels[i],
                                            block_per_stage[i],
                                            layer_per_block[i],
                                            i+2,
                                            SE=SE,
                                            dcn_config={}
                                            )
            )

        # init weight
        self._init_weight()

    def _init_weight(self):
        for module in self.modules():
            if isinstance(module, nn.Conv2d):
                weight_init.c2_xavier_fill(module)


    def forward(self, inputs):
        feats = self.conv1(inputs)
        feats = self.conv2(feats)
        feats = self.conv3(feats)

        out = []
        for name in self.stage_name:
            layer = getattr(self, name)
            feats = layer(feats)
            out.append(feats)

        return out


class OSAModule_stage(nn.Sequential):
    """ 搭建每个阶段的OSA module"""
    def __init__(self,
                 in_channels,
                 stage_channels,
                 concat_channels,
                 block_per_stage,
                 layer_per_block,
                 stage_num,
                 SE=False,
                 dcn_config={}
                 ):
        super(OSAModule_stage, self).__init__()
        if not stage_num == 2:
            self.add_module('Pooling', nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True))

        if block_per_stage != 1:
            SE = False

        module_name = f"OSA{stage_num}_1"
        self.add_module(module_name, OSAModule(in_channels,
                                               stage_channels,
                                               concat_channels,
                                               layer_per_block,
                                               module_name,
                                               SE=SE,
                                               dcn_config=dcn_config,
                                               ))
        for i in range(block_per_stage - 1):
            # last block
            if i != block_per_stage - 2:
                SE = False
            module_name = f"OSA{stage_num}_{i+2}"
            self.add_module(module_name,
                            OSAModule(concat_channels,
                                      stage_channels,
                                      concat_channels,
                                      layer_per_block,
                                      module_name,
                                      SE=SE,
                                      identity=True,
                                      dcn_config=dcn_config
                                      ))


class OSAModule(nn.Module):
    def __init__(self,
                 in_channels,
                 stage_channels,
                 concat_channels,
                 layer_per_block,
                 module_name,
                 SE=False,
                 identity=False,
                 dcn_config={}
                 ):
        super(OSAModule, self).__init__()
        self.identity = identity
        self.layers = nn.ModuleList()
        temp_channels = in_channels
        with_dcn = dcn_config.get('stage_with_dcn', False)

        for i in range(layer_per_block):
            if with_dcn:
                pass
            else:
                self.layers.append(
                    nn.Sequential(
                        Conv2d(
                            temp_channels,
                            stage_channels,
                            kernel_size=3,
                            stride=1,
                            padding=1,
                            bias=False,
                            norm=get_norm("BN", stage_channels),
                            activation=F.relu,
                        )
                    )
                )
                temp_channels = stage_channels

            # feature aggregation
            in_channels = in_channels + layer_per_block * stage_channels
            self.concat = nn.Sequential(
                Conv2d(
                    in_channels,
                    concat_channels,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                    bias=False,
                    norm=get_norm("BN", concat_channels),
                    activation=F.relu
                )
            )
        self.ese = EffictiveSE(concat_channels)

    def forward(self, inputs):
        # 用于恒等映射
        residual = inputs

        output = []
        output.append(inputs)
        for layer in self.layers:
            x = layer(x)
            output.append(x)

        y = torch.cat(output, dim=1)
        y = self.concat(y)
        y = self.ese(y)
        # 是否进行恒等映射
        if self.identity:
            y = y + residual

        return y


class HSigmoid(nn.Module):
    def __init__(self,
                 inplace):
        super(HSigmoid, self).__init__()
        self.inplace = inplace

    def forward(self, inputs):
        return F.relu6(inputs + 3, inplace=self.inplace) / 6


class EffictiveSE(nn.Module):
    def __init__(self,
                 in_channels: int):
        super(EffictiveSE, self).__init__()
        self.global_pooling = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Conv2d(in_channels, in_channels, kernel_size=1, stride=1)
        self.sigmoid = HSigmoid()

    def forward(self, inputs):
        feats = self.global_pooling(inputs)
        feats = self.fc(feats)
        feats = self.sigmoid(feats)
        out = feats * inputs
        return out
