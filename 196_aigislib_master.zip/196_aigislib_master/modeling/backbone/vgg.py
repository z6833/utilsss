import torch
import torch.nn.init as init
import torch.nn as nn
from typing import List, cast
import torch.nn.functional as F
from detectron2.modeling.backbone import BACKBONE_REGISTRY, Backbone
from detectron2.layers import ShapeSpec

__all__ = [
    "VGG",
    "build_vgg_backbone"
]


class VGG(Backbone):
    def __init__(self, cfg, features):
        super().__init__()
        base, extra, add = features
        self.L2Norm = L2Norm(512, 20)
        self._out_features = cfg.MODEL.VGG.OUTPUT_INDEX
        self.base = nn.Sequential(*base)
        self.extra = nn.Sequential(*extra)
        self.add = nn.Sequential(*add)
        self._out_feature_channels = {'vgg4_3': 512, 'add0': 1024, 'add1': 512, 'add2': 256, 'add3': 256, 'add4': 256}
        self._out_feature_stride = {'vgg4_3': 8, 'add0': 16, 'add1': 32, 'add2': 64, 'add3': 100, 'add4': 300}
        self._out_feature_size = {'vgg4_3': 38, 'add0': 19, 'add1': 10, 'add2': 5, 'add3': 3, 'add4': 1}
        self._initialize_weights()

    def forward(self, x):
        assert x.dim() == 4, f"VGG takes an input of shape (N, C, H, W). Got {x.shape} instead!"
        outputs = {}
        first_index = 0
        # apply vgg up to conv4_3 relu
        for k in range(len(self.base)):
            base_index = k + 1
            x = self.base[k](x)
            try:
                if isinstance(self.base[base_index], nn.MaxPool2d):
                    first_index += 1
                    if first_index == 4:
                        s = self.L2Norm(x)
                        outputs['vgg4_3'] = s
            except Exception as e:
                pass
        # s = self.L2Norm(x)
        # outputs['vgg4_3'] = s

        # apply vgg up to fc7
        for k in range(len(self.extra)):
            x = self.extra[k](x)
        outputs['add0'] = x

        # apply extra layers and cache source layer outputs
        add_index = 0
        for k, v in enumerate(self.add):
            x = F.relu(v(x), inplace=True)
            if k % 2 == 1:
                add_index += 1
                outputs['add%s' % add_index] = x
        return outputs

    def output_shape(self):
        return {
            name: ShapeSpec(
                channels=self._out_feature_channels[name],
                width=self._out_feature_size[name],
                height=self._out_feature_size[name],
                stride=self._out_feature_stride[name]
            )
            for name in self._out_features}

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)


class L2Norm(nn.Module):
    def __init__(self, n_channels, scale):
        super(L2Norm, self).__init__()
        self.n_channels = n_channels
        self.gamma = scale or None
        self.eps = 1e-10
        self.weight = nn.Parameter(torch.Tensor(self.n_channels))
        self.reset_parameters()

    def reset_parameters(self):
        init.constant_(self.weight, self.gamma)

    def forward(self, x):
        norm = x.pow(2).sum(dim=1, keepdim=True).sqrt()+self.eps
        # x /= norm
        x = torch.div(x, norm)
        out = self.weight.unsqueeze(0).unsqueeze(2).unsqueeze(3).expand_as(x) * x
        return out


def make_layers(cfg, vgg_cfg):
    layers: List[nn.Module] = []
    if cfg.INPUT.FORMAT:
        in_channels = 3
    else:
        in_channels = 1
    specify_cfg = vgg_cfg["%s" % cfg.MODEL.VGG.DEPTH]
    cfg_len = len(specify_cfg)
    max_pooling_index = 0
    for num, v in enumerate(specify_cfg):
        if num == cfg_len - 1 and cfg.MODEL.VGG.DROP_LAST_MAX_POOLING:
            # 去除最后一个最大池化操作
            continue
        if v == "M":
            if max_pooling_index == 2 and cfg.MODEL.VGG.CEIL_MODE:
                # 第三个最大池化是否改用ceil模式的最大池化
                layers += [nn.MaxPool2d(kernel_size=2, stride=2, ceil_mode=True)]
            else:
                layers += [nn.MaxPool2d(kernel_size=2, stride=2)]
                max_pooling_index += 1
        else:
            v = cast(int, v)
            conv2d = nn.Conv2d(in_channels, v, kernel_size=3, padding=1)
            if cfg.MODEL.VGG.BATCH_NORM:
                layers += [conv2d, nn.BatchNorm2d(v), nn.ReLU(inplace=True)]
            else:
                layers += [conv2d, nn.ReLU(inplace=True)]
            in_channels = v
    return layers


def add_extras(cfg, i):
    # Extra layers added to VGG for feature scaling
    layers = []
    in_channels = i
    flag = False
    for k, v in enumerate(cfg):
        if in_channels != 'S':
            if v == 'S':
                layers += [nn.Conv2d(in_channels, cfg[k + 1],
                           kernel_size=(1, 3)[flag], stride=2, padding=1)]
            else:
                layers += [nn.Conv2d(in_channels, v, kernel_size=(1, 3)[flag])]
            flag = not flag
        in_channels = v
    return layers


def _vgg(cfg, vgg_cfg):
    # model = VGG(make_layers(cfg, vgg_cfg), **kwargs)
    base_nn = make_layers(cfg, vgg_cfg)

    add_nn = [
        nn.MaxPool2d(kernel_size=3, stride=1, padding=1),
        nn.Conv2d(512, 1024, kernel_size=3, padding=6, dilation=6),
        nn.ReLU(inplace=True),
        nn.Conv2d(1024, 1024, kernel_size=1),
        nn.ReLU(inplace=True)
    ]
    nn_list = [base_nn, add_nn, add_extras([256, 'S', 512, 128, 'S', 256, 128, 256, 128, 256], 1024)]
    return VGG(cfg, nn_list)


@BACKBONE_REGISTRY.register()
def build_vgg_backbone(cfg, input_shape=None):
    vgg_cfg = {
        "11": [64, "M", 128, "M", 256, 256, "M", 512, 512, "M", 512, 512, "M"],
        "13": [64, 64, "M", 128, 128, "M", 256, 256, "M", 512, 512, "M", 512, 512, "M"],
        "16": [64, 64, "M", 128, 128, "M", 256, 256, 256, "M", 512, 512, 512, "M", 512, 512, 512, "M"],
        "19": [64, 64, "M", 128, 128, "M", 256, 256, 256, 256, "M", 512, 512, 512, 512, "M", 512, 512, 512, 512, "M"],
    }
    return _vgg(cfg, vgg_cfg)


if __name__ == "__main__":
    pass
