import math
import torch
import torch.nn as nn
import torch.utils.model_zoo as model_zoo
from torch.autograd import Variable

from detectron2.modeling.backbone import BACKBONE_REGISTRY
from detectron2.modeling.backbone import Backbone
from detectron2.modeling.backbone.resnet import ResNet

model_urls = {
    'resnet50': 'https://download.pytorch.org/models/resnet50-19c8e357.pth',
    'resnet101': 'https://download.pytorch.org/models/resnet101-5d3b4d8f.pth',
    'resnet152': 'https://download.pytorch.org/models/resnet152-b121ed2d.pth',
    }

def conv3x3(in_planes, out_planes, stride=1):
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride, padding=1, bias=False)

def conv1x1(in_planes, out_planes, stride=1):
    """1x1 convolution"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=stride, bias=False)


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, in_planes, planes, stride=1, downsample=None):
        super(Bottleneck, self).__init__()
        self.conv1 = conv1x1(in_planes, planes)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = conv3x3(planes, planes, stride)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = conv1x1(planes, planes * self.expansion)
        self.bn3 = nn.BatchNorm2d(planes * self.expansion)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out


class ResNet(Backbone):
    def __init__(self, block, layers, strides_per_stage, res5_dilation=1,
                 return_idx=[0, 1, 2, 3], pretrained=False):
        super(ResNet, self).__init__()
        print("pretrained: ", pretrained)
        self.inplanes = 64
        self.strides_per_stage = strides_per_stage
        self.return_idx = return_idx

        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer1 = self._make_layer(block, 64, layers[0], stride=self.strides_per_stage[0])
        self.layer2 = self._make_layer(block, 128, layers[1], stride=self.strides_per_stage[1])
        self.layer3 = self._make_layer(block, 256, layers[2], stride=self.strides_per_stage[2])
        self.layer4 = self._make_layer(block, 512, layers[3], stride=self.strides_per_stage[3])
        # 加载预训练参数或者初始化
        if pretrained:
            self._load_pretrained_model()
        else:
            self._init_weights()

        # 对最后一层的歩长重新设置, siameseFPN:16; siameseFPNSum:32
        # for n, m in self.layer3.named_modules():
        #     if 'conv2' in n:
        #         m.dilation, m.padding, m.stride = (2, 2), (2, 2), (1, 1)
        #     elif 'downsample.0' in n:
        #         m.stride = (1, 1)
        for name, module in self.layer4.named_modules():
            if '0.conv2' in name:
                module.dilation, module.padding = (res5_dilation, res5_dilation), (res5_dilation, res5_dilation)
            elif '1.conv2' in name:
                module.dilation, module.padding = (res5_dilation, res5_dilation), (res5_dilation, res5_dilation)
            elif '2.conv2' in name:
                module.dilation, module.padding = (res5_dilation, res5_dilation), (res5_dilation, res5_dilation)
            # elif 'downsample.0' in name:
            #     module.stride = (1, 1)

    def _make_layer(self, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                conv1x1(self.inplanes, planes * block.expansion, stride), 
                nn.BatchNorm2d(planes * block.expansion),
            )
        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion
        for _ in range(1, blocks):
            layers.append(block(self.inplanes, planes))
        return nn.Sequential(*layers)

    def forward(self, x):
        out = []
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        out.append(x)        # 1/4
        x = self.layer2(x)
        out.append(x)        # 1/8
        x = self.layer3(x)
        out.append(x)        # 1/16
        x = self.layer4(x)
        out.append(x)        # 1/32
       # return {f"res{i+2}": out[i] for i in self.return_idx}
        return [out[i] for i in self.return_idx]

    def _init_weights(self):
       for m in self.modules():
           if isinstance(m, nn.Conv2d):
               n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
               m.weight.data.normal_(0, math.sqrt(2. / n))
           elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def _load_pretrained_model(self):
        #pretrained_dict = model_zoo.load_url(model_urls['resnet101'])
        print("pretrained url: ", model_urls['resnet50'])
        pretrained_dict = model_zoo.load_url(model_urls['resnet50'])
        print("pretrained model loaded")
        model_dict = {}
        state_dict = self.state_dict()
        for k, v in pretrained_dict.items():
            if k in state_dict:
                model_dict[k] = v
        state_dict.update(model_dict)
        self.load_state_dict(state_dict)


@BACKBONE_REGISTRY.register()
def build_cd_resnet_backbone(cfg, *args):
    """ 通过config配置文件来构建ResNet
    """
    pretrained = cfg.MODEL.RESNETS.PRETRAINED
    depth = cfg.MODEL.RESNETS.DEPTH
    out_features = cfg.MODEL.RESNETS.OUT_FEATURES
    feat_stride = cfg.MODEL.RESNETS.FEAT_STRIDE
    res5_dilation = cfg.MODEL.RESNETS.RES5_DILATION

    num_blocks_per_stage = {50: [3, 4, 6, 3], 101: [3, 4, 23, 3]}[depth]
    out_feature_channels = {"res2": 256, "res3": 512,
                            "res4": 1024, "res5": 2048}
    strides_per_stage = {16: [1, 2, 2, 1], 32: [1, 2, 2, 2]}[feat_stride]
    out_feature_strides = {16: {"res2": 4, "res3": 8, "res4": 16, "res5": 16},
                           32: {"res2": 4, "res3": 8, "res4": 16, "res5": 32}}[feat_stride]
    out_stage_idx = [{"res2": 0, "res3": 1, "res4": 2, "res5": 3}[f] for f in out_features]

    # 构建ResNet
    model = ResNet(Bottleneck, num_blocks_per_stage, strides_per_stage,
                   res5_dilation=res5_dilation, return_idx=out_stage_idx, pretrained=pretrained)
    return model


if __name__ == "__main__":
    import os, sys
    import pathlib

    path = pathlib.Path(__file__)
    root_path = path.parent.parent.parent.as_posix()
    cfg_path = os.path.join(root_path, 'config')
    sys.path.append(cfg_path)

    from aigislib.config import get_cfg
    model = build_cd_resnet_backbone(get_cfg())
    model.cuda()
    input = torch.rand(1, 3, 512, 512)
    input = Variable(input.cuda())
    low_level_features = model(input)
    # print(low_level_features.size())
