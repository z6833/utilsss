import torch
import torch.nn as nn
import torch.nn.functional as F
from detectron2.config import configurable
from aigislib.modeling.builder import DECODERS


@DECODERS.register()
class Multiply_Layer_Decorder(nn.Module):
    """ 基于FPN的多尺度输出 """

    @configurable
    def __init__(self,
                 in_channels: list,
                 out_channels: int
                 ):
        super(Multiply_Layer_Decorder, self).__init__()
        self.in_channels = in_channels[-1]
        self.out_channels = out_channels

        self.shared_conv = nn.Sequential(
            nn.Conv2d(self.in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            # nn.GroupNorm(32, fpn_dim),
            nn.ReLU(inplace=True)
        )
        self.semantic_conv = nn.Sequential(
            nn.Conv2d(out_channels, out_channels//2, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channels//2),
            # nn.GroupNorm(32, 128),
            nn.ReLU(inplace=True)

        )
        self.gate = nn.Sequential(
            nn.Conv2d(self.in_channels * 4, out_channels, kernel_size=1, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.DECODERS.IN_CHANNELS,
            out_channels=cfg.MODEL.DECODERS.OUT_CHANNELS,
        )
        return ret

    def forward(self, feats):
        """
            feats: list(Tensor), [p2, p3, p4, p5]
        """
        feats = [_ for _ in feats]
        # 多尺度输入特征上采样相同的尺度
        for i in range(1, len(feats)):
            feats[i] = F.interpolate(feats[i], size=feats[0].size()[2:], mode='bilinear', align_corners=True)

        # s5 = F.interpolate(self.shared_conv(feats[3]), scale_factor=2, mode='bilinear', align_corners=True)  # 256->256
        # s5 = F.interpolate(self.shared_conv(s5), scale_factor=2, mode='bilinear', align_corners=True)  # 256->256
        # s5 = F.interpolate(self.semantic_conv(s5), scale_factor=2, mode='bilinear', align_corners=True)  # 256->128        #
        # s4 = F.interpolate(self.shared_conv(feats[2]), scale_factor=2, mode='bilinear', align_corners=True)  # 256->256
        # s4 = F.interpolate(self.semantic_conv(s4), scale_factor=2, mode='bilinear', align_corners=True)  # 256->128        #
        # s3 = F.interpolate(self.semantic_conv(feats[1]), scale_factor=2, mode='bilinear', align_corners=True)  # 256->128        #
        # s2 = self.semantic_conv(feats[0])
        # 使用求和的方式
        # out = s2 + s3 + s4 + s5
        # feature gate
        out = torch.cat(feats, dim=1)
        out = self.gate(out)
        return out

