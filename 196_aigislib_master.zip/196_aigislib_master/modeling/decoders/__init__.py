from .fpn_head import FPN_Head
from .fcn_head import FCN_Head
from .uper_head import Uper_Head
from .deeplabv3plus_head import Deeplabv3PlusHead
from .decoder_heads import Multiply_Layer_Decorder
from .vit_up_head import VisionTransformerUpHead
from .vit_mla_head import VIT_MLAHead
from .segformer_head import SegFormerHead