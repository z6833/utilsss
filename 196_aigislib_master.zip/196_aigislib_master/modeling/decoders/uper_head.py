"""
UPernet:
https://zhuanlan.zhihu.com/p/48155978
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Optional, Union
from collections.abc import Iterable

from detectron2.config import configurable
from detectron2.layers import Conv2d, get_norm
from aigislib.modeling.builder import DECODERS
from aigislib.modeling.context_heads.psp_head import PPM


@DECODERS.register()
class Uper_Head(nn.Module):
    """ 使用upernet的头结构
    """
    @configurable
    def __init__(self,
                 in_channels: Union[List[int], int],
                 out_channels: int,
                 norm: str,
                 pool_scales: Optional[List[int]] = None,
                 dilation_scales: Optional[List[int]] = None,
                 ):
        super(Uper_Head, self).__init__()
        self.pool_scales = pool_scales
        self.dilation_scales = dilation_scales
        self.in_channels = in_channels
        self.out_channels = out_channels

        # psp module
        if pool_scales:
            self.ppm_module = PPM(self.pool_scales, self.in_channels[-1], self.out_channels)
            self.bottleneck = Conv2d(len(self.pool_scales) * self.out_channels,
                                     self.out_channels,
                                     kernel_size=3,
                                     stride=1,
                                     padding=1,
                                     norm=get_norm(norm, self.out_channels),
                                     activation=F.relu
                                     )
        # FPN module
        self.lateral_conv = nn.ModuleList()
        self.fpn_conv = nn.ModuleList()
        for i, channel in enumerate(self.in_channels):
            self.lateral_conv.append(
                Conv2d(
                    channel,
                    self.out_channels,
                    kernel_size=1,
                    stride=1,
                    norm=get_norm(norm, self.out_channels),
                    activation=F.relu
                )
            )
            # top layer has context module, do not lateral conv
            if i == len(self.in_channels) - 1 and self.pool_scales:
                del self.lateral_conv[i]

            self.fpn_conv.append(
                Conv2d(
                    self.out_channels,
                    self.out_channels,
                    kernel_size=3,
                    stride=1,
                    padding=1,
                    norm=get_norm(norm, self.out_channels),
                    activation=F.relu
                )
            )

        self.fpn_bottleneck = Conv2d(
            self.out_channels * len(self.in_channels),
            self.out_channels,
            kernel_size=1,
            stride=1,
            norm=get_norm(norm, self.out_channels),
            activation=F.relu
        )

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.DECODERS.IN_CHANNELS,
            out_channels=cfg.MODEL.DECODERS.OUT_CHANNELS,
            pool_scales=cfg.MODEL.DECODERS.POOL_SCALES,
            dilation_scales=cfg.MODEL.DECODERS.ASPP_DILATIONS,
            norm=cfg.MODEL.DECODERS.NORM
        )
        return ret

    def ppm_forward(self, inputs):
        """ ppm 前向计算"""
        x = inputs[-1]      # backbone top layer
        ppm_out = self.ppm_module(x)
        ppm_out = torch.cat(ppm_out, dim=1)
        out = self.bottleneck(ppm_out)
        return out

    def forward(self, inputs):
        """
        Args:
             inputs (List or Tuple): input[c2, c3, c4, c5]
        """
        assert isinstance(inputs, Iterable), "inputs is not Iterable."
        # 进行PPModule模块处理
        ppm_out = self.ppm_forward(inputs)

        # FPN模块处理
        lateral = []
        for num, lateral_conv in enumerate(self.lateral_conv):
            lateral.append(lateral_conv(inputs[num]))
        lateral.append(ppm_out)     # p2, p3, p4, p5

        # top-down path
        num_lateral = len(lateral)
        for i in range(num_lateral-1, 0, -1):
            previous_size = lateral[i-1].size()[2:]
            lateral[i-1] = self._upsample_add(lateral[i], lateral[i-1])

        # output
        fpn_out = []
        for i in range(0, num_lateral):
            fpn_out.append(self.fpn_conv[i](lateral[i]))    # p2, p3, p4, p5
        # add ppm out
        fpn_out = self._upsample_cat(fpn_out)
        output = self.fpn_bottleneck(fpn_out)

        return output

    def _upsample_add(self, x, y):
        return F.interpolate(x, size=y.size()[2:], mode='bilinear', align_corners=True) + y

    def _upsample_cat(self, feature_list):  # p2, p3, p4, p5
        res_list = [feature_list[0]]
        if len(feature_list) == 1:
            return res_list[0]
        h, w = feature_list[0].size()[2:]
        for num, feature in enumerate(feature_list):
            if num == 0:
                continue
            res_list.append(F.interpolate(feature, size=(h, w), mode='bilinear', align_corners=True))
        return torch.cat(res_list, dim=1)  # torch.cat([p2, p3, p4, p5], dim=1)
