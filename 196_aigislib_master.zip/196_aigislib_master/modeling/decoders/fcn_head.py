import torch
import torch.nn as nn
import torch.nn.functional as F
from collections.abc import Iterable
from typing import List, Union, Optional

from detectron2.config import configurable
from detectron2.layers import Conv2d, get_norm

from aigislib.modeling.builder import DECODERS
from aigislib.modeling.context_heads.basehead import BaseHead


class Identity(nn.Module):
    """ 恒等映射层 """
    def forward(self, inputs):
        return inputs


@DECODERS.register()
class FCN_Head(BaseHead):
    """
    FCN语义头结构
    """
    @configurable
    def __init__(self,
                 in_channels: Union[List[int], int],
                 out_channels: int,
                 in_feature_idx: List[int],
                 input_transform: Optional[str] = None,
                 norm: str = 'BN',
                 concat_input: bool = True,
                 conv_num: int = 1
                 ):
        self.out_channels = out_channels
        self.concat_input = concat_input
        self.conv_num = conv_num
        super(FCN_Head, self).__init__(in_channels, in_feature_idx, input_transform)
        self.out_channels = out_channels

        convs = []
        convs.append(
            Conv2d(
                self.in_channels, out_channels, kernel_size=3, stride=1, padding=1,
                norm=get_norm(norm, out_channels), activation=F.relu
            )
        )
        for i in range(1, conv_num):
            convs.append(
                Conv2d(
                    out_channels, out_channels, kernel_size=3, stride=1, padding=1,
                    norm=get_norm(norm, out_channels), activation=F.relu
                )
            )
        if conv_num == 0:
            self.convs = Identity()
        else:
            self.convs = nn.Sequential(*convs)

        if self.concat_input:
            self.bottleneck_conv = nn.Sequential(
                Conv2d(
                    in_channels+out_channels,
                    out_channels,
                    kernel_size=3,
                    stride=1,
                    padding=1,
                    norm=get_norm(norm, out_channels),
                    activation=F.relu
                )
            )

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.DECODERS.IN_CHANNELS,
            out_channels=cfg.MODEL.DECODERS.OUT_CHANNELS,
            in_feature_idx=cfg.MODEL.DECODERS.IN_FEATURE_IDX,
            input_transform=cfg.MODEL.DECODERS.INPUT_TRANSFORM,
            norm=cfg.MODEL.DECODERS.NORM,
            concat_input=cfg.MODEL.DECODERS.CONCAT_INPUT,
            conv_num=cfg.MODEL.DECODERS.CONV_NUM
        )
        return ret

    def forward(self, inputs):
        # print(inputs[0].shape,inputs[1].shape,inputs[2].shape,inputs[3].shape)
        assert isinstance(inputs, Iterable), "inputs must be Iterable."
        # 对输入进行变换
        input = self.transform_input(inputs)
        # 对输入进行卷积操作
        feat = self.convs(input)
        if self.concat_input:
            feat = torch.cat([input, feat], dim=1)
            feat = self.bottleneck_conv(feat)
        return feat

