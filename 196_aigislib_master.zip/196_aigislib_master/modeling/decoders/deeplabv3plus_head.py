import torch
import torch.nn as nn
import torch.nn.functional as F
from aigislib.modeling.builder import DECODERS
from typing import List

from detectron2.config import configurable
from detectron2.layers import ASPP, Conv2d, DepthwiseSeparableConv2d, get_norm


@DECODERS.register()
class Deeplabv3PlusHead(nn.Module):
    """ deeplabv3plus head """
    @configurable
    def __init__(self,
                 in_channels: List[int],
                 project_channels: int,
                 out_channels: int,
                 norm: str,
                 aspp_dilations: List[int],
                 aspp_dropout: float,
                 use_depthwise_separable_conv: bool
                 ):
        super(Deeplabv3PlusHead, self).__init__()
        aspp_channels = out_channels
        self.out_channels = out_channels

        self.aspp = ASPP(in_channels[-1],
                         aspp_channels,
                         aspp_dilations,
                         norm=norm,
                         activation=F.relu,
                         pool_kernel_size=None,
                         dropout=aspp_dropout,
                         use_depthwise_separable_conv=use_depthwise_separable_conv,
                         )
        if project_channels > 0:
            # 骨干网络中浅层特征进行处理
            self.project_conv = Conv2d(in_channels[0],
                                       project_channels,
                                       kernel_size=1,
                                       stride=1,
                                       padding=0,
                                       norm=get_norm(norm, project_channels),
                                       activation=F.relu
                                       )
        else:
            self.project_conv = None
        # fuse conv
        if use_depthwise_separable_conv:
            # 使用5*5 depthwiseconv 代替2 conv3*3,这样有相同的感受野
            self.fuse_conv = DepthwiseSeparableConv2d(
                project_channels + aspp_channels,
                out_channels,
                kernel_size=5,
                padding=2,
                norm1=get_norm(norm, out_channels),
                activation1=F.relu,
                norm2=get_norm(norm, out_channels),
                activation2=F.relu
            )
        else:
            self.fuse_conv = nn.Sequential(
                Conv2d(
                    project_channels + aspp_channels,
                    out_channels,
                    kernel_size=3,
                    padding=1,
                    norm=get_norm(norm, out_channels),
                    activation=F.relu
                ),
                Conv2d(
                    out_channels,
                    out_channels,
                    kernel_size=3,
                    padding=1,
                    norm=get_norm(norm, out_channels),
                    activation=F.relu
                )
            )

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.DECODERS.IN_CHANNELS,
            project_channels=cfg.MODEL.DECODERS.PROJECT_CHANNELS,
            out_channels=cfg.MODEL.DECODERS.OUT_CHANNELS,
            norm=cfg.MODEL.DECODERS.NORM,
            aspp_dilations=cfg.MODEL.DECODERS.ASPP_DILATIONS,
            aspp_dropout=cfg.MODEL.DECODERS.ASPP_DROPOUT,
            use_depthwise_separable_conv=cfg.MODEL.DECODERS.USE_DEPTHWISE_SEPARABLE_CONV,
        )

        return ret

    def forward(self, inputs):
        """
        Args:
            inputs List[tensor]: [layer1, layer4] in backbone
        """
        assert len(inputs) > 0
        # 进行aspp操作
        aspp_output = self.aspp(inputs[-1])
        output = F.interpolate(aspp_output, size=inputs[0].shape[2:], mode='bilinear', align_corners=True)

        # 将高层特征与浅层特征进行融合，并通过卷积处理
        if self.project_conv is not None:
            project_out = self.project_conv(inputs[0])
            output = torch.cat([project_out, output], dim=1)
        out = self.fuse_conv(output)

        return out

