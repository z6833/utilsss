from detectron2.config.config import configurable
import torch
import torch.nn as nn
import torch.nn.functional as F
from aigislib.modeling.builder import DECODERS
from typing import List, Tuple


class Interpolate(nn.Module):
    def __init__(self, size=None, scale_factor=None, mode='nearest', align_corners=False):
        super(Interpolate, self).__init__()
        self.interp = nn.functional.interpolate
        self.size = size
        self.mode = mode
        self.scale_factor = scale_factor
        self.align_corners = align_corners

    def forward(self, x):
        x = self.interp(x, size=self.size, scale_factor=self.scale_factor,
                        mode=self.mode, align_corners=self.align_corners)
        return x


def conv3x3(in_, out):
    return nn.Conv2d(in_, out, 3, padding=1)


class ConvRelu(nn.Module):
    def __init__(self, in_, out):
        super().__init__()
        self.conv = conv3x3(in_, out)
        self.activation = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.activation(x)
        return x


class DecoderBlockV2(nn.Module):
    def __init__(self, in_channels, middle_channels, out_channels, is_deconv=True):
        super(DecoderBlockV2, self).__init__()
        self.in_channels = in_channels

        if is_deconv:
            """
                Paramaters for Deconvolution were chosen to avoid artifacts, following
                link https://distill.pub/2016/deconv-checkerboard/
            """

            self.block = nn.Sequential(
                ConvRelu(in_channels, middle_channels),
                nn.ConvTranspose2d(middle_channels, out_channels, kernel_size=4, stride=2,
                                   padding=1),
                nn.ReLU(inplace=True)
            )
        else:
            self.block = nn.Sequential(
                Interpolate(scale_factor=2, mode='bilinear'),
                ConvRelu(in_channels, middle_channels),
                ConvRelu(middle_channels, out_channels),
            )

    def forward(self, x, down):
        if down is None:
            return self.block(x)

        diffY = down.size()[2] - x.size()[2]
        diffX = down.size()[3] - x.size()[3]

        x = F.pad(x, [diffX // 2, diffX - diffX // 2,
                      diffY // 2, diffY - diffY // 2])
        x = torch.cat([down, x], dim=1)
        return self.block(x)


class DoubleConv(nn.Module):
    """(convolution => [BN] => ReLU) * 2"""

    def __init__(self, in_channels, out_channels, mid_channels=None):
        super().__init__()
        if not mid_channels:
            mid_channels = out_channels
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.double_conv(x)


class Up(nn.Module):
    """Upscaling then double conv"""

    def __init__(self, in_channels, out_channels, bilinear=True):
        super().__init__()

        # if bilinear, use the normal convolutions to reduce the number of channels
        if bilinear:
            self.up = nn.Upsample(
                scale_factor=2, mode='bilinear', align_corners=True)
            self.conv = DoubleConv(in_channels, out_channels, in_channels // 2)
        else:
            self.up = nn.ConvTranspose2d(
                in_channels, in_channels // 2, kernel_size=2, stride=2)
            self.conv = DoubleConv(in_channels, out_channels)

    def forward(self, x1, x2):
        x1 = self.up(x1)
        # input is CHW
        diffY = x2.size()[2] - x1.size()[2]
        diffX = x2.size()[3] - x1.size()[3]

        x1 = F.pad(x1, [diffX // 2, diffX - diffX // 2,
                        diffY // 2, diffY - diffY // 2])
        # if you have padding issues, see
        # https://github.com/HaiyongJiang/U-Net-Pytorch-Unstructured-Buggy/commit/0e854509c2cea854e247a9c615f175f76fbb2e3a
        # https://github.com/xiaopeng-liao/Pytorch-UNet/commit/8ebac70e633bac59fc22bb5195e513d5832fb3bd
        x = torch.cat([x2, x1], dim=1)
        return self.conv(x)


@DECODERS.register()
class UNetHead(nn.Module):
    @configurable
    def __init__(self,
                 in_channels: List[int],
                 out_channels: int,
                 num_filters=32,
                 is_deconv=False):
        super(UNetHead, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_filters = num_filters
        self.is_deconv = is_deconv
        if len(in_channels) == 4:

            self.pool = nn.MaxPool2d(2, 2)
            self.relu = nn.ReLU(inplace=True)
            self.center = DecoderBlockV2(self.in_channels[-1], self.num_filters * 8 * 2,
                                         self.num_filters * 8, self.is_deconv)
            self.dec5 = DecoderBlockV2(self.in_channels[-1] + self.num_filters * 8,
                                       self.num_filters * 8 * 2, self.num_filters * 8, self.is_deconv)
            self.dec4 = DecoderBlockV2(self.in_channels[-2] + self.num_filters * 8,
                                       self.num_filters * 8 * 2, self.num_filters * 8, self.is_deconv)
            self.dec3 = DecoderBlockV2(self.in_channels[-3] + self.num_filters * 8,
                                       self.num_filters * 4 * 2, self.num_filters * 2, self.is_deconv)
            self.dec2 = DecoderBlockV2(self.in_channels[-4] + self.num_filters * 2,
                                       self.num_filters * 2 * 2, self.num_filters * 2 * 2, self.is_deconv)
            self.dec1 = DecoderBlockV2(
                self.num_filters * 2 * 2, self.num_filters * 2 * 2, self.num_filters, self.is_deconv)
            self.dec0 = ConvRelu(self.num_filters, self.out_channels)

        else:

            self.up1 = Up(1024, 512 // 2, not self.is_deconv)
            self.up2 = Up(512, 256 // 2, not self.is_deconv)
            self.up3 = Up(256, 128 // 2, not self.is_deconv)
            self.up4 = Up(128, self.out_channels, not self.is_deconv)

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.DECODERS.IN_CHANNELS,
            out_channels=cfg.MODEL.DECODERS.OUT_CHANNELS,
        )
        return ret

    def forward(self, inputs):
        if len(inputs) == 4:
            # for resnet backbone
            conv2, conv3, conv4, conv5 = inputs

            pool = self.pool(conv5)
            center = self.center(pool, None)

            dec5 = self.dec5(center, conv5)
            dec4 = self.dec4(dec5, conv4)
            dec3 = self.dec3(dec4, conv3)
            dec2 = self.dec2(dec3, conv2)
            dec1 = self.dec1(dec2, None)
            dec0 = self.dec0(dec1)
            return dec0

        else:
            # for unet backbone
            x1, x2, x3, x4, x5 = inputs
            x = self.up1(x5, x4)
            x = self.up2(x, x3)
            x = self.up3(x, x2)
            x = self.up4(x, x1)
            return x
