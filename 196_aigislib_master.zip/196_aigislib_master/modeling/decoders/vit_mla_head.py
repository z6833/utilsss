import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List

from detectron2.config import configurable
from aigislib.modeling.builder import DECODERS


class MLAHead(nn.Module):
    def __init__(self, mla_channels=256, mlahead_channels=128, norm_cfg=None):
        super(MLAHead, self).__init__()
        self.head2 = nn.Sequential(nn.Conv2d(mla_channels, mlahead_channels, 3, padding=1, bias=False),
                                   nn.BatchNorm2d(mlahead_channels), nn.ReLU(),
            nn.Conv2d(mlahead_channels, mlahead_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(mlahead_channels), nn.ReLU())
        self.head3 = nn.Sequential(nn.Conv2d(mla_channels, mlahead_channels, 3, padding=1, bias=False),
                                   nn.BatchNorm2d(mlahead_channels), nn.ReLU(),
            nn.Conv2d(mlahead_channels, mlahead_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(mlahead_channels), nn.ReLU())
        self.head4 = nn.Sequential(nn.Conv2d(mla_channels, mlahead_channels, 3, padding=1, bias=False),
                                   nn.BatchNorm2d(mlahead_channels), nn.ReLU(),
            nn.Conv2d(mlahead_channels, mlahead_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(mlahead_channels), nn.ReLU())
        self.head5 = nn.Sequential(nn.Conv2d(mla_channels, mlahead_channels, 3, padding=1, bias=False),
                                   nn.BatchNorm2d(mlahead_channels), nn.ReLU(),
            nn.Conv2d(mlahead_channels, mlahead_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(mlahead_channels), nn.ReLU())

    def forward(self, mla_p2, mla_p3, mla_p4, mla_p5):
        # head2 = self.head2(mla_p2)
        head2 = F.interpolate(self.head2(
            mla_p2), 4*mla_p2.shape[-1], mode='bilinear', align_corners=True)
        head3 = F.interpolate(self.head3(
            mla_p3), 4*mla_p3.shape[-1], mode='bilinear', align_corners=True)
        head4 = F.interpolate(self.head4(
            mla_p4), 4*mla_p4.shape[-1], mode='bilinear', align_corners=True)
        head5 = F.interpolate(self.head5(
            mla_p5), 4*mla_p5.shape[-1], mode='bilinear', align_corners=True)
        return torch.cat([head2, head3, head4, head5], dim=1)


@DECODERS.register()
class VIT_MLAHead(nn.Module):
    """ Vision Transformer with support for patch or hybrid CNN input stage
    """

    @configurable
    def __init__(self, in_channels:List[int], out_channels=128, img_size=768,
                 norm_layer=nn.BatchNorm2d, norm_cfg='BN', **kwargs):
        super(VIT_MLAHead, self).__init__()
        self.img_size = img_size
        self.norm_cfg = norm_cfg
        self.in_channels = in_channels[-1]
        self.BatchNorm = norm_layer
        self.out_channels = out_channels

        self.mlahead = MLAHead(mla_channels=self.in_channels,
                               mlahead_channels=self.out_channels, norm_cfg=self.norm_cfg)
        # self.cls = nn.Conv2d(4 * self.mlahead_channels,
        #                      self.num_classes, 3, padding=1)

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            img_size=cfg.MODEL.DECODERS.IMG_SIZE,
            in_channels=cfg.MODEL.DECODERS.IN_CHANNELS,
            out_channels=cfg.MODEL.DECODERS.OUT_CHANNELS,
            norm_layer=nn.BatchNorm2d,
            norm_cfg=cfg.MODEL.DECODERS.NORM,
            align_corners=cfg.MODEL.DECODERS.ALIGN_CORNERS,
        )
        return ret

    def forward(self, inputs):
        x = self.mlahead(inputs[0], inputs[1], inputs[2], inputs[3])
        # x = self.cls(x)
        # x = F.interpolate(x, size=self.img_size, mode='bilinear',
        #                   align_corners=self.align_corners)
        return x
