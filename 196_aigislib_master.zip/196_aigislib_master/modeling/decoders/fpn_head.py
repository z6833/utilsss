"""
此处FPN用于head,后面直接decoder.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Union

from detectron2.config import configurable
from detectron2.layers import Conv2d, get_norm
from aigislib.modeling.builder import DECODERS


@DECODERS.register()
class FPN_Head(nn.Module):
    """ feature pyramid module """
    @configurable
    def __init__(self,
                 in_channels: Union[List, int],
                 out_channels: int,
                 norm: str,
                 device: str
                 ):
        super(FPN_Head, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.device = torch.device(device)

        self.reduce_conv = nn.ModuleList()      # 横向连接卷积
        self.smooth_p = nn.ModuleList()         # 平滑处理
        for num, channel in enumerate(reversed(self.in_channels)):
            if num < len(self.in_channels)-1 or num == 0:
                self.smooth_p.append(
                    nn.Sequential(
                        Conv2d(
                            out_channels,
                            out_channels,
                            kernel_size=3,
                            stride=1,
                            padding=1,
                            norm=get_norm(norm, out_channels),
                            activation=F.relu
                        )
                    ).to(self.device)
                )
            self.reduce_conv.append(
                nn.Sequential(
                    nn.Conv2d(channel, out_channels, kernel_size=1, stride=1, padding=0),
                    nn.BatchNorm2d(out_channels),
                    nn.ReLU(inplace=True)
                ).to(self.device)
            )
        self.bottleneck_conv = nn.Sequential(
            nn.Conv2d(out_channels * len(self.in_channels), out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        ).to(self.device)

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            in_channels=cfg.MODEL.DECODERS.IN_CHANNELS,
            out_channels=cfg.MODEL.DECODERS.OUT_CHANNELS,
            norm=cfg.MODEL.DECODERS.NORM,
            device=cfg.MODEL.DEVICE,
        )
        return ret

    def forward(self, x):
        # c2, c3, c4, c5 = x
        # 对输入特征进行反转操作，方便后面进行处理
        input_feature = [feature for feature in reversed(x)]
        upsample_list = []
        # Top-down
        # 使用FPN,并自顶向下处理
        for num, feature in enumerate(input_feature):
            if num == 0:
                upsample_list.append(self.reduce_conv[0](feature))
                if len(input_feature) == 1:
                    break
            else:
                upsample_list.append(
                    self.smooth_p[num-1](
                        self._upsample_add(upsample_list[-1], self.reduce_conv[num](feature))
                    )
                )
        upsample_list = [feature for feature in reversed(upsample_list)]    # p2,p3,p4,p5
        # 将FPN输出的多尺度上采样到相同的尺度
        fpn_out = self._upsample_cat(upsample_list)  # p2, p3, p4, p5
        fpn_out = self.bottleneck_conv(fpn_out)
        return fpn_out

    def _upsample_add(self, x, y):
        return F.interpolate(x, size=y.size()[2:], mode='bilinear', align_corners=True) + y

    def _upsample_cat(self, feature_list):  # p2, p3, p4, p5
        res_list = [feature_list[0]]
        if len(feature_list) == 1:
            return res_list[0]
        h, w = feature_list[0].size()[2:]
        for num, feature in enumerate(feature_list):
            if num == 0:
                continue
            res_list.append(F.interpolate(feature, size=(h, w), mode='bilinear', align_corners=True))
        return torch.cat(res_list, dim=1)  # torch.cat([p2, p3, p4, p5], dim=1)
