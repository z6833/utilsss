import torch
import torch.nn as nn
import torch.nn.functional as F

from detectron2.config import configurable
from typing import Optional, List
from ..builder import LOSSES


@LOSSES.register()
class DiceLoss(nn.Module):
    """
    dice loss
    """
    @configurable
    def __init__(self,
                 smooth: float = 1.0,
                 loss_weight: float = 1.0,
                 class_weight: Optional[List] = None):
        super(DiceLoss, self).__init__()
        self.smooth = smooth
        self.loss_weight = loss_weight
        self.class_weight = class_weight

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            smooth=cfg.MODEL.LOSS.SMOOTH,
            loss_weight=cfg.MODEL.LOSS.LOSS_WEIGHT,
            class_weight=cfg.MODEL.LOSS.CLASS_WEIGHT,
        )
        return ret

    def forward(self, preds, targets):
        assert preds.shape[0] == targets.shape[0], "preds sample number not equire to targets sample number."
        num_classes = preds.shape[1]
        # 对targets进行one-hot
        targets = F.one_hot(targets, num_classes)       # (B,H,W,C)
        preds = F.softmax(preds, dim=1)                 # (B,C,H,W)

        total_dice_loss = 0.
        for i in range(num_classes):
            # 对每一个类别计算dice loss
            dice_loss = binary_dice_loss(preds[:, i], targets[..., i], smooth=self.smooth)
            total_dice_loss += dice_loss
        loss = self.loss_weight * total_dice_loss
        return loss


def binary_dice_loss(pred, target, smooth=1.0):
    assert pred.shape[0] == target.shape[0]
    pred = pred.view(pred.shape[0], -1)
    target = target.view(target.shape[0], -1)

    inter = 2 * torch.sum(torch.mul(pred, target), dim=1) + smooth
    union = torch.sum(pred, dim=1) + torch.sum(target, dim=1) + smooth
    dice_loss = 1 - inter / union
    return dice_loss
