import torch
import torch.nn as nn
import torch.nn.functional as F

from detectron2.config import configurable
from typing import Optional
from ..builder import LOSSES


def cross_entropy(pred: torch.Tensor,
                  label: torch.Tensor,
                  weight=None,
                  reduction: str = 'mean',
                  class_weight: Optional[torch.Tensor] = None):
    """ 计算多元交叉熵损失函数
    Args:
        pred (torch.Tensor): 网络的预测结果，shape(N, C)
        label (torch.Tensor): ground truth
        weight (torch.Tensor, None): 样本的损失权重
        class_weight (list[float]): 每个类的权重
    """
    # element_wise losses
    loss = F.cross_entropy(pred, label, weight=class_weight, reduction='mean')

    # weights：元素级的权重
    if weight is not None:
        weight = weight.float()
        loss = loss * weight
    return loss


@LOSSES.register()
class CrossEntropyLoss(nn.Module):
    @configurable
    def __init__(self,
                 loss_type: str = 'cross_entropy',
                 reduction: str = 'mean',
                 class_weight=None,
                 loss_weight: int = 1.0):
        super(CrossEntropyLoss, self).__init__()
        self.class_weight = class_weight
        self.loss_weight = loss_weight
        self.reduction = reduction
        if loss_type == 'CrossEntropyLoss':
            self.criterion = cross_entropy
        else:
            raise NotImplemented

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            loss_type=cfg.MODEL.LOSS.LOSS_TYPE,
            reduction=cfg.MODEL.LOSS.REDUCTION,
            class_weight=cfg.MODEL.LOSS.CLASS_WEIGHT,
            loss_weight=cfg.MODEL.LOSS.LOSS_WEIGHT
        )
        return ret

    def forward(self, cls_score, label):
        # class weight
        if self.class_weight is not None:
            class_weight = cls_score.new_tensor(self.class_weight)
        else:
            class_weight = None
        loss = self.loss_weight * self.criterion(
            cls_score,
            label,
            class_weight=class_weight,
            reduction=self.reduction
        )
        return loss



