import torch
import torch.nn as nn
import torch.nn.functional as F

from detectron2.config import configurable
from typing import Optional
from ..builder import LOSSES


@LOSSES.register()
class FocalLoss(nn.Module):
    """
    计算Focal loss
    """
    @configurable
    def __init__(self,
                 alpha: float = 0.25,
                 gamma: float = 2,
                 loss_weight: float = 1.0,
                 class_weight: Optional[str] = None,
                 reduction: bool = True):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.loss_weight = loss_weight
        self.class_weight = class_weight
        self.size_average = reduction

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            alpha=cfg.MODEL.LOSS.ALPHA,
            gamma=cfg.MODEL.LOSS.GAMMA,
            loss_weight=cfg.MODEL.LOSS.LOSS_WEIGHT,
            class_weight=cfg.MODEL.LOSS.CLASS_WEIGHT,
            reduction=cfg.MODEL.LOSS.REDUCTION,
        )
        return ret

    def forward(self, preds, targets):
        # 使用指数变换
        assert preds.shape == targets.shape, "preds shape is not match targets shape."

        ce_loss = F.cross_entropy(preds, targets, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss
        if self.size_average:
            return self.loss_weight * self.focal_loss.mean()
        else:
            return self.loss_weight * focal_loss.sum()