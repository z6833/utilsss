"""
Deeplabv3+中难易样本挖掘
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from detectron2.config import configurable
from typing import Optional
from ..builder import LOSSES


@LOSSES.register()
class Ohem(nn.Module):
    """ 在线样本难易挖掘 """
    @configurable
    def __init__(self,
                 ignore_label: int = -1,
                 top_k_percent_pixels: float = 1.0,
                 weight: Optional[float] = None
                 ):
        super(Ohem, self).__init__()
        self.top_k_percent_pixels = top_k_percent_pixels
        self.ignore_label = ignore_label
        self.criterion = nn.CrossEntropyLoss(
            weight=weight, ignore_index=ignore_label, reduction="none"
        )

    @classmethod
    def from_config(cls, cfg):
        ret = dict(
            top_k_percent_pixels=cfg.MODEL.LOSS.TOP_K_PERCENT_PIXELS,
            ignore_label=cfg.MODEL.LOSS.IGNORE_LABEL,
            weight=cfg.MODEL.LOSS.WEIGHT
        )
        return ret

    def forward(self, logits, labels, weights=None):
        if weights is None:
            pixel_losses = self.criterion(logits, labels).contiguous().view(-1)
        else:
            # 对每个像素点使用weights
            pixel_losses = self.criterion(logits, labels) * weights
            pixel_losses = pixel_losses.contiguous().view(-1)
        if self.top_k_percent_pixels == 1.0:
            return pixel_losses.mean()

        top_k_pixel = int(self.top_k_percent_pixels * pixel_losses.numel())
        pixel_losses, _ = torch.topk(pixel_losses, top_k_pixel)
        return pixel_losses.mean()






