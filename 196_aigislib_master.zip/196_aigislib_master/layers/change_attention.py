import torch
import torch.nn as nn


class ChangeAttention(nn.Module):
    def __init__(self, in_channels, out_channels):
        """ 此处添加了变化检测注意力模块 """
        super(ChangeAttention, self).__init__()
        self.gate_a = nn.Sequential(
            nn.Conv2d(in_channels*2, 1, kernel_size=1, bias=True),
            # nn.Conv2d(in_channels*2, 1, kernel_size=3, stride=1, padding=1, bias=True),
            nn.ReLU(inplace=True)
        )
        self.gate_b = nn.Sequential(
            nn.Conv2d(in_channels*2, 1, kernel_size=1, bias=True),
            #nn.Conv2d(in_channels*2, 1, kernel_size=3, stride=1, padding=1, bias=True),  # 改为3*3卷积
            nn.ReLU(inplace=True)
        )
        self.softmax = nn.Softmax(dim=1)
        # 去除混叠影响
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, featA, featB):
        cat_feat = torch.cat([featA, featB], dim=1)
        attention_vector_A = self.gate_a(cat_feat)
        attention_vector_B = self.gate_b(cat_feat)

        attention_vector = torch.cat([attention_vector_A, attention_vector_B], dim=1)
        attention_vector = self.softmax(attention_vector)
        attention_vector_A, attention_vector_B = attention_vector[:, 0:1, :, :], attention_vector[:, 1:2, :, :]
        merge = attention_vector_A * featA + attention_vector_B * featB

        out = self.conv(merge)

        return out