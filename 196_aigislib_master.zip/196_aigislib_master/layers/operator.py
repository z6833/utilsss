import warnings
import torch
import torch.nn as nn
import torch.nn.functional as F


class Cat(nn.Module):
    """ 用于拼接任意张量 """
    def __init__(self):
        super(Cat, self).__init__()

    def forward(self, *inps):
        """
        Args:
            inps (list): 张量的集合
        """
        size_set = set()
        size_set.add(inps[0].size()[2:])
        max_height = inps[0].size(2)
        max_wight = inps[0].size(3)
        for i in range(1, len(inps)):
            # 最大高度
            if inps[i].size(2) > max_height:
                max_height = inps[i].size(2)
            if inps[i].size(3) > max_wight:
                max_wight = inps[i].size(3)
        out = torch.cat(list(inps), dim=1)

        return out


class Upsample(nn.Module):
    """ 针对特征上采样 """
    def __init__(self,
                 size=None,
                 scale_factor=None,
                 mode="nearest",
                 align_corners=None):
        super(Upsample, self).__init__()
        self.size = size
        self.scale_factor = scale_factor
        self.mode = mode
        self.align_corners = align_corners

    def forward(self, inp):
        if self.size is None and self.scale_factor is None:
            warnings.warn("must be set upsample size or scale_factor.")
        elif isinstance(self.size, int):
            self.size = (self.size, self.size)

        return F.interpolate(inp, self.size, self.scale_factor, self.mode, self.align_corners)






